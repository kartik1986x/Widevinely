import os
import yaml
import struct
import json
import base64
import httpx

from Cryptodome.Cipher import AES
from Cryptodome.Util import Padding
from Cryptodome.Hash import HMAC, SHA256
from Cryptodome.Random import get_random_bytes

from pathlib import Path
from zlib import crc32
from crccheck.crc import Crc32Mpeg2
from unidecode import unidecode, UnidecodeError

from pywidevinely.utils import logger
from pywidevinely import Cdm, Device
from pywidevinely.utils.protos.license_protocol_pb2 import (
    ClientIdentificationRaw,
    ProtocolVersion,
    ProvisioningOptions,
    ProvisioningRequest,
    ProvisioningResponse,
    SignedProvisioningMessage,
)

log = logger.getLogger("keybox")


def read_be_int32(buff, offset):
    (val,) = struct.unpack(">L", buff[offset : offset + 4])
    return val


class Keybox:
    def __init__(self, data: bytes, verbose: bool = False):
        length = len(data)
        if length not in (128, 132):
            ValueError
            log.exit(f"\nInvalid keybox length: {length}. Should be 128 or 132 bytes.")

        if length == 128:  # QSEE style keybox
            if data[0x80:0x84] != b"LVL1" and verbose:
                log.warning_(
                    "\nQSEE style Keybox does not end in bytes 'LVL1', considered an L3 Keybox.\n"
                )
            data = data[0:0x80]

        if data[0x78:0x7C] != b"kbox":
            ValueError
            log.exit("\nInvalid Keybox magic.")

        body_crc = Crc32Mpeg2.calc(data[:0x7C])
        body_crc_expected = struct.unpack(">L", data[0x7C : 0x7C + 4])[0]
        if body_crc_expected != body_crc:
            ValueError
            log.exit(
                f"\nKeybox CRC is bad. \nExpected: 0x{body_crc_expected:08X}. \nComputed: 0x{body_crc:08X}"
            )

        self.stable_id = data[0x00:0x20]  # aka device ID
        self.device_aes_key = data[0x20:0x30]
        self.device_id = data[
            0x30:0x78
        ]  # device id sent to google, possibly flags + system_id + encrypted

        # known fields
        self.flags = read_be_int32(self.device_id, 0)
        self.system_id = read_be_int32(self.device_id, 4)

    def __str__(self) -> str:
        return f"{self.stable_id.decode('utf8').strip()} ({self.system_id})"

    def __repr__(self) -> str:
        return "{name}({items})".format(
            name=self.__class__.__name__,
            items=", ".join([f"{k}={repr(v)}" for k, v in self.__dict__.items()]),
        )

    @classmethod
    def load(cls, file: Path, verbose: bool = False):
        """Load Keybox from a file Path object."""
        if not isinstance(file, Path):
            TypeError
            log.exit("\nFile provided is not a Path object.")
        return cls(file.read_bytes(), verbose=verbose)

    def provision(
        keybox, config, output, proxy, response, skip_test, user_agent, verbose
    ):
        """
        Provision a Keybox and receive a Widevine-ready WVD file.

        The WVD file will be saved in the same directory as the
        provided keybox unless a different out_path is given.

        A config file must be provided. If a file is not provided
        it will search in the same directory of the keybox to a file
        with the same filename but .yml extension.

        This config file contains the unique device configuration values that cannot be retrieved from
        the keybox. Its recommended to keep the config yaml file for archival and look-back purposes.

        Example config:
        -  Warning: these values may not be correct or values used in up-to-date devices,
            and are definitely not correct for your specific device.
            If you make a Widevine license request to a demo player and disable service/privacy
            certificates (block the request maybe), then you will see the real original Client ID
            and the data it uses for client_info and capabilities.
            In fact, you could just use that (but swap out the token to the new provision token).

            wvd:
                security_level = 1
                device_type = ANDROID

            client_info:
                company_name = Motorola
                model_name = Nexus 6
                architecture_name = armeabi-v7a
                device_name = shamu
                product_name = shamu
                build_info = google/shamu/shamu:5.1.1/LMY48M/2167285:user/release-keys
                widevine_cdm_version = 5.1.12

            capabilities:
                session_token = 1
                max_hdcp_version = 'HDCP_V2_2'
                oem_crypto_api_version = 11

        You can get some of the client_info from the build.props file from the devices system image or an
        update file. Some data can also be retrieved from "DRM Info" apps like 'DRMInfo' or 'Kaltura Device Info'.

        Example corresponding props, name and the prop in the .prop file, in correct order:

            "company_name"      "ro.product.manufacturer"
            "model_name"        "ro.product.model"
            "architecture_name" "ro.product.cpu.abi"
            "device_name"       "ro.product.device"
            "product_name"      "ro.product.name"
            "build_info"        "ro.build.fingerprint"

        "device_id" from keybox/oemcrypto/tz - in verbose (default) mode,
        this will appear as "stable id" in the log (part of keybox[0:0x20]).

        "widevine_cdm_version", this is hardcoded in libwvdrm.so (usermode) a string like "v5.0.0-android" or
        "v4.1.0-android", either disassemble or try finding a string close to this in libwidevinecdm.so,
        libwvdrmengine.so or libwvhidl.so, depending on which library is used to handle widevine outside of trustzone.

        "oem_crypto_security_patch_level" is usually 0 and requires calling or disassembling liboemcrypto to get.

        HDCP 2.2 is often supported on most non-desktop/level 1 capable devices.
        """
        keybox_file = keybox
        if output:
            keybox_file = output / keybox_file.name

        log.info_("[title]PROVISIONING PROVIDED KEYBOX[/title]")

        if not os.path.isfile(keybox_file):
            log.exit("Keybox path provided does not exist, or is not a file.")

        config = config or Path(
            str(keybox_file).replace(
                keybox_file.name, keybox_file.name.replace(".bin", ".yml")
            )
        )
        if not os.path.isfile(config):
            log.exit("Could not find Keybox configuration file.")
        else:
            config = yaml.safe_load(config.read_text(encoding="utf8"))

        if not config:
            log.exit("Could not extract information from Keybox configuration file.")

        if not proxy and verbose:
            log.warning_("No proxy provided.\n")

        if verbose:
            log.info_(
                f"Keybox Configuration:\n{json.dumps(config, sort_keys=True, indent=4)}"
            )

        keybox = Keybox.load(keybox_file, verbose)

        if verbose:
            log.info_(f"\nKeybox loaded: {repr(keybox)}")
            log.info_(
                f"\nLikely a {'consumer' if keybox.flags & 2 == 2 else 'test'} device keybox"
            )

        client_id = ClientIdentificationRaw()
        client_id.Type = ClientIdentificationRaw.KEYBOX
        client_id.Token = keybox.device_id

        # defaults, but they appear to be set by real clients if you check the bit stream
        provisioning_options = ProvisioningOptions()
        provisioning_options.certificate_type = ProvisioningOptions.WIDEVINE_DRM
        provisioning_options.certificate_authority = ""

        provisioning_request = ProvisioningRequest()
        provisioning_request.client_id.CopyFrom(client_id)
        provisioning_request.nonce = get_random_bytes(4)
        provisioning_request.options.CopyFrom(provisioning_options)

        # some 7.x android versions might set this, but don't have examples to confirm it
        # provisioning_request.stable_id = keybox.stable_id

        provisioning_request_string = provisioning_request.SerializeToString()
        nonce = provisioning_request.nonce
        enc_key, mac_key_server, mac_key_client = Cdm.derive_keys(
            *(
                b"ENCRYPTION\000" + provisioning_request_string + b"\0\0\0\x80",
                b"AUTHENTICATION\0" + provisioning_request_string + b"\0\0\2\0",
            ),
            keybox.device_aes_key,
        )

        if verbose:
            log.info_(
                f"\nUnsigned provisioning request: {provisioning_request_string!r}"
            )
            log.info_(f"\nNonce: {nonce!r}")
            log.info_("\nGenerated keys:")
            log.info_(f" - enc_key: {enc_key}")
            log.info_(f" - mac_key_server: {mac_key_server}")
            log.info_(f" - mac_key_client: {mac_key_client}")

        signed_provisioning_message = SignedProvisioningMessage()
        signed_provisioning_message.message = provisioning_request_string
        signed_provisioning_message.signature = (
            HMAC.new(mac_key_client, digestmod=SHA256)
            .update(provisioning_request_string)
            .digest()
        )
        signed_provisioning_message.protocol_version = ProtocolVersion.VERSION_2_0

        signed_request = (
            base64.urlsafe_b64encode(signed_provisioning_message.SerializeToString())
            .rstrip(b"=")
            .decode()
        )
        if verbose:
            log.info_(
                f"\nUrl-safe base64 encoded Signed Provision Message: {signed_request}"
            )

        session = httpx.Client()

        if proxy:
            session.proxies = {"all://": proxy}

        if user_agent:
            session.headers.update({"User-Agent": user_agent})
        else:
            session.headers.pop("User-Agent")

        if not verbose:
            log.info_(
                f" - [content]COMPANY_NAME[/content] {config['client_info']['company_name'].upper()}"
            )
            log.info_(
                f" - [content]DEVICE_TYPE[/content]  {config['wvd']['device_type']}"
            )
            log.info_(
                f" - [content]MODULE_NAME[/content]  {config['client_info']['model_name']}"
            )
            log.info_(f" - [content]SYSTEM_ID[/content]    {keybox.system_id}")
            log.info_(
                f" - [content]SECURITY[/content]     L{config['wvd']['security_level']}"
            )
            log.info_(
                f" - [content]ARCHITECTURE[/content] {config['client_info']['architecture_name']}"
            )
            log.info_(
                f" - [content]BUILD_INFO[/content]   {config['client_info']['build_info']}"
            )

        provision_response = session.post(
            "https://www.googleapis.com/certificateprovisioning/v1/devicecertificates/create",
            params={
                "key": "AIzaSyB-5OLKTx2iU5mko18DfdwK5611JIjbUhE",
                "signedRequest": signed_request,
            },
        ).json()

        if response:
            with open(keybox_file.parent / "provision_response.log", "w+") as logfile:
                logfile.write(str(provision_response))

        if "error" in provision_response:
            log.exit(f"Provisioning failed: {provision_response['error']!r}.")
        elif (
            provision_response["kind"]
            != "certificateprovisioning#certificateProvisioningResponse"
        ):
            log.exit(
                f"\nProvisioning returned with an unexpected 'kind' field: {provision_response['kind']!r}."
            )

        signed_response = SignedProvisioningMessage()
        signed_response.ParseFromString(
            base64.urlsafe_b64decode(provision_response["signedResponse"])
        )

        response_signature_computed = (
            HMAC.new(mac_key_server, digestmod=SHA256)
            .update(signed_response.message)
            .digest()
        )

        if response_signature_computed != signed_response.signature:
            log.exit(
                f"\nProvisioning response signature is incorrect: {signed_response.signature!r}"
                f"\nExpected: {response_signature_computed!r}"
            )

        provisioning_response = ProvisioningResponse()
        provisioning_response.ParseFromString(signed_response.message)

        if verbose:
            log.info_(f"\nDecoded response: {provisioning_response}")

        if provisioning_response.nonce != nonce:
            raise log.exit(
                f"\nNonce does not match with response: {provisioning_response.nonce!r}"
                f"\nExpected: {nonce!r}"
            )

        ci = ClientIdentificationRaw()
        ci.Type = ClientIdentificationRaw.DEVICE_CERTIFICATE
        ci.Token = provisioning_response.device_certificate

        config["client_info"]["device_id"] = keybox.stable_id

        for name, value in config["client_info"].items():
            nv = ci.ClientInfo.add()
            nv.Name = name
            nv.Value = str(value)

        capabilities = ClientIdentificationRaw.ClientCapabilities()
        caps = config["capabilities"]
        if "client_token" in caps:
            capabilities.ClientToken = caps["client_token"]
        if "session_token" in caps:
            capabilities.SessionToken = caps["session_token"]
        if "video_resolution_constraints" in caps:
            capabilities.VideoResolutionConstraints = caps[
                "video_resolution_constraints"
            ]
        if "max_hdcp_version" in caps:
            max_hdcp_version = caps["max_hdcp_version"]
            if str(max_hdcp_version).isdigit():
                max_hdcp_version = int(max_hdcp_version)
            else:
                max_hdcp_version = (
                    ClientIdentificationRaw.ClientCapabilities.HdcpVersion.Value(
                        max_hdcp_version
                    )
                )
            capabilities.MaxHdcpVersion = max_hdcp_version
        if "oem_crypto_api_version" in caps:
            capabilities.OemCryptoApiVersion = int(caps["oem_crypto_api_version"])

        # Any of the following has not been seen in use:
        if "anti_rollback_usage_table" in caps:
            capabilities.AntiRollbackUsageTable = caps["anti_rollback_usage_table"]
        if "srm_version" in caps:
            capabilities.SrmVersion = int(caps["srm_version"])
        if "can_update_srm" in caps:
            capabilities.ClientToken = caps["can_update_srm"]

        # Possible to refactor this?
        if "supported_certificate_key_type" in caps:
            supported_certificate_key_type = caps["supported_certificate_key_type"]
            if str(supported_certificate_key_type).isdigit():
                supported_certificate_key_type = int(supported_certificate_key_type)
            else:
                supported_certificate_key_type = (
                    ClientIdentificationRaw.ClientCapabilities.CertificateKeyType.Value(
                        supported_certificate_key_type
                    )
                )
            capabilities.SupportedCertificateKeyType.append(
                supported_certificate_key_type
            )
        ci._ClientCapabilities.CopyFrom(capabilities)

        if verbose:
            log.info_(f"\nGenerated Device Certificate Client ID: \n{ci}")

        aes = AES.new(enc_key, AES.MODE_CBC, iv=provisioning_response.device_rsa_key_iv)
        device_rsa_key = Padding.unpad(
            aes.decrypt(provisioning_response.device_rsa_key), 0x10
        )

        device = Device(
            type_=Device.Types[config["wvd"]["device_type"].upper()],
            security_level=config["wvd"]["security_level"],
            flags=None,
            private_key=device_rsa_key,
            client_id=ci.SerializeToString(),
        )

        wvd_bin = device.dumps()

        if (
            config["client_info"]["model_name"]
            .lower()
            .startswith(config["client_info"]["model_name"].lower())
        ):
            wvd_name = config["client_info"]["model_name"]
        else:
            wvd_name = f"{config['client_info']['company_name']} {config['client_info']['model_name']}"

        wvd_name += f" {crc32(wvd_bin).to_bytes(4, 'big').hex()}"

        try:
            wvd_name = unidecode(wvd_name.strip().lower().replace(" ", "_")).upper()
        except UnidecodeError as e:
            log.exit(f"\nFailed to sanitize name: {e!r}.")

        wvd_name += f"_{keybox.system_id}_L{device.security_level}"

        device.dump(keybox_file.parent / wvd_name / f"{wvd_name}.wvd")

        with open(
            keybox_file.parent / wvd_name / "device_private_key", "wb+"
        ) as private_key:
            private_key.write(device.private_key.exportKey())

        with open(
            keybox_file.parent / wvd_name / "device_client_id_blob", "wb+"
        ) as client_id_blob:
            client_id_blob.write(device.client_id.SerializeToString())

        if not skip_test:
            drm_status = Cdm.test("", Cdm.from_device(device), silent=True)
            if drm_status == 200:
                log.info_(
                    " - [content]DRM_STATUS[/content]   00000 ([success]VALID[/success])"
                )
            else:
                log.info_(
                    f" - [content]DRM_STATUS[/content]   {drm_status} ([error]REVOKED[/error])"
                )
                log.exit("\nProvisioned Keybox but Cdm test was not succesfull.")

        log.success_(
            "\nSuccesfully provisioned Keybox and saved provisioned files.",
            debug=False,
        )
