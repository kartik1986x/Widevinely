#!/usr/bin/env python3
import argparse
import re
import sqlite3
import sys
import json

from json import JSONDecodeError
from widevinely.utils import logger
from widevinely.utils.AtomicSQL import AtomicSQL

log = logger.getLogger("vault")

"""
Add keys from files with JSON or TXT extension to Key Vault.
File should have atleast KID:KEY per-line when using a TXT file or atleast one KID:KEY per title for JSON files.
"""

parser = argparse.ArgumentParser(
    "Widevinely Key Vault batch adder",
    description="Simple script to add information from a JSON or TXT file to a Widevinely Key Vault",
)
parser.add_argument(
    "-s",
    "--service",
    help="Service to store keys from. (e.g. Amazon, Netflix, DisneyPlus)",
    required=True,
)
parser.add_argument("-i", "--input", help="File used to parse from", required=True)
parser.add_argument(
    "-o", "--output", help="Key Vault db used to parse to", required=True
)
parser.add_argument(
    "-d",
    "--dry-run",
    help="Execute, but never actually save/commit changes.",
    action="store_true",
    required=False,
)
args = parser.parse_args()

output_db = AtomicSQL()
output_db_id = output_db.load(sqlite3.connect(args.output))

# get all keys from input db
add_count = 0
existed_count = 0
usable_count = 0

if args.input == "-":
    input_ = sys.stdin.read()
else:
    if not args.input.endswith(".txt") and not args.input.endswith(".json"):
        log.exit("Only files with `.txt` or `.json` extension are allowed.")
    if not args.output.endswith(".db"):
        log.exit("Only Key Vaults with `.db` extension are allowed.")

content_keys = []
log.info_(f"\n[title]Collecting and saving keys for service {args.service}[/title]")
if args.dry_run:
    log.warning_("\n        -- Dry Run Activated -- ")
if ".txt" in args.input:
    try:
        with open(args.input, encoding="utf-8") as fd:
            for line in fd.read().splitlines(keepends=False):
                match = re.search(
                    r"^(?P<kid>[0-9a-fA-F]{32}):(?P<key>[0-9a-fA-F]{32})?$", line
                )
                if not match:
                    continue
                content_keys.append(
                    (match.group("kid").lower(), match.group("key").lower())
                )
    except FileNotFoundError:
        log.exit(f'"{args.input}" could not be found')

elif ".json" in args.input:
    try:
        with open(args.input) as fd:
            data = json.load(fd)
            for x in data:
                for key in data[x]["contentKey(s)"]:
                    match = re.search(
                        r"^(?P<kid>[0-9a-fA-F]{32}):(?P<key>[0-9a-fA-F]{32})?$", key
                    )
                    if not match:
                        continue
                    content_keys.append(
                        (match.group("kid").lower(), match.group("key").lower())
                    )
    except (FileNotFoundError, JSONDecodeError) as error:
        if isinstance(error, FileNotFoundError):
            log.exit(f"\n{args.input!r} could not be found")
        elif isinstance(error, JSONDecodeError):
            log.exit("\nJSON is empty or not correctly formatted...")

service_exists = (
    output_db.safe_execute(
        output_db_id,
        lambda db, cursor: cursor.execute(
            "SELECT count(name) FROM sqlite_master WHERE type='table' AND name=?",
            [args.service],
        ),
    ).fetchone()[0]
    == 1
)

if not service_exists:
    log.exit(
        f"\nService '{args.service}' does not exist in Key Vault.\nMake sure the service has been added to the Key Vault by doing a first request."
    )

total_keys = len(content_keys)
for key in content_keys:
    if key[0] == "0" * 32 or key[1] == "0" * 32:
        # Unusable key
        log.info_(f" - [red]{key[0]}:{key[1]}[/red] (Unusable)")
        continue
    if key[0] == "b770d5b4bb6b594daf985845aae9aa5f":
        # Amazon HDCP test key
        log.info_(f" - [red]{key[0]}:{key[1]}[/red] (Amazon HDCP test key)")
        continue
    usable_count += 1
    exists = output_db.safe_execute(
        output_db_id,
        lambda db, cursor: cursor.execute(
            "SELECT `key` FROM `{1}` WHERE `kid`={0}".format("?", args.service),
            [key[0]],
        ),
    ).fetchone()

    if exists:
        existed_count += 1
        log.info_(f" - [red]{key[0]}:{key[1]}[/red] (Usable, Already Exists)")
    else:
        add_count += 1
        log.info_(f" - [green]{key[0]}:{key[1]}[/green] (Usable)")
        output_db.safe_execute(
            output_db_id,
            lambda db, cursor: cursor.execute(
                f"""INSERT INTO `{args.service}` (kind, id, title, kid, key, type, resolution, range, profile)
                VALUES ('', '', '', '{key[0]}', '{key[1]}', '', '', '', '');"""
            ),
        )

if not args.dry_run:
    output_db.commit(output_db_id)
    if add_count:
        log.info_(f"Added {add_count}/{total_keys} usable keys to the Key Vault")
    if existed_count:
        log.info_(
            f"Skipped {existed_count}/{usable_count} usable keys because they already existed in the Key Vault"
        )
else:
    log.info_(f"Skipped {total_keys}/{total_keys} keys because dry run was activated")
