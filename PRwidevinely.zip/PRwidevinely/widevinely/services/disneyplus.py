from __future__ import annotations

import json
import re
import time
from datetime import datetime
from typing import Any

import click
import m3u8
from click import Context

from widevinely.objects import Credential, MenuTrack, Title, Tracks
from widevinely.services.BaseService import BaseService
from widevinely.utils.BamSDK import BamSdk
from widevinely.utils.collections import as_list
from widevinely.utils.io import get_ip_info
from widevinely.utils.globals import arguments
from widevinely.utils.globals import cdm as cdm_
from widevinely.utils import tmdb, logger
from widevinely.utils.exceptions import *

log = logger.getLogger("DSNP")


class DisneyPlus(BaseService):
    """
    Service code for Disney's Disney+ streaming service (https://disneyplus.com).

    \b
    Authorization: Credentials
    Security: UHD@L1 FHD@L1 HD@L3, HEAVILY monitors high-profit and newly released titles!!

    \b
    Tips: - Some titles offer a setting in its Details tab to prefer "Remastered" or Original format
          - You can specify which profile is used for its preferences and such in the config file
    """

    ALIASES = ["DSNP", "disneyplus", "disney+"]

    TITLE_RE = r"^(?:https?://(?:www\.)?disneyplus\.com(?:/[a-z0-9-]+)?(?:/[a-z0-9-]+)?(?P<type>/movies|/series)?/.+?/)?(?P<id>[a-zA-Z0-9-]+)"

    @staticmethod
    @click.command(name="DisneyPlus", short_help="disneyplus.com")
    @click.argument("title", type=str)
    @click.option(
        "-m", "--movie", is_flag=True, default=False, help="Title is a Movie."
    )
    @click.option(
        "-oar",
        "--original-aspect-ratio",
        is_flag=True,
        default=False,
        help="If available, download the video in Original Aspect Ratio.",
    )
    @click.option(
        "-imax",
        "--imax-enhanced",
        is_flag=True,
        default=False,
        help="If available, download the IMAX Enhanced video.",
    )
    @click.option(
        "-bumper",
        "--add-bumper",
        is_flag=True,
        default=False,
        help="Add intro bumper to the beginning of the video.",
    )
    @click.option(
        "-dub-card",
        "--add-dub-card",
        is_flag=True,
        default=False,
        help="Add dub_cards to the end of the video.",
    )
    @click.option(
        "-s",
        "--scenario",
        default="tv-drm-ctr",
        type=str,
        help="Capability profile that specifies compatible codecs, streams, bit-rates, resolutions and such.",
    )
    @click.pass_context
    def cli(ctx: Context, **kwargs: Any) -> DisneyPlus:
        return DisneyPlus(ctx, **kwargs)

    def __init__(
        self,
        ctx,
        title,
        movie,
        original_aspect_ratio,
        imax_enhanced,
        add_bumper,
        add_dub_card,
        scenario,
    ):
        global args, cdm
        args = arguments(service=ctx.params)
        cdm = cdm_().cdm

        self.title_ = title
        self.parse_title(ctx, title)
        self.movie = movie or "movies" in title
        self.ctx = ctx
        self.bumper = add_bumper
        self.dub_card = add_dub_card
        self.original_aspect_ratio = original_aspect_ratio
        self.imax_enhanced = imax_enhanced

        self.scenario = scenario
        if not self.scenario:
            self.scenario = "tv-drm-ctr"
        super().__init__(ctx)

        self.session = BaseService.get_session(self)

        self.region = None
        self.bamsdk = None
        self.device_token = None
        self.account_tokens = {}

        self.configure()

    def get_titles(self):
        title_type = "Video" if self.movie else "Series"
        meta = getattr(self.bamsdk.content, "getMeta")(
            regions=["EN", self.region], type=title_type, media_id=self.title
        )
        bundle_request = getattr(self.bamsdk.content, "getBundle")(
            region_=self.region,
            type=title_type,
            media_id=self.title,
        )

        dmc_bundle, self.portability_region = (
            bundle_request[0],
            bundle_request[1],
        )

        if dmc_bundle[0][title_type.lower()] is None:
            log.exit(
                " x Disney+ returned no information on this title.\n   It might not be available in the account's region."
            )

        title_name = [meta["title"][x] for x in meta["title"] if x == "en"][0]
        try:
            title_synopsis = [
                meta["description"][x]
                for x in meta["description"]
                if x == self.region.lower()
            ][0]
        except IndexError:
            title_synopsis = [
                meta["description"][x] for x in meta["description"] if x == "en"
            ][0]
        cast = meta["cast"]
        releaseYear = meta["releaseYear"]

        if self.movie:
            title = dmc_bundle[0]["video"]
            title["dmc_bundles"] = dmc_bundle
            tmdb_info = tmdb.info(
                content_name=title_name,
                content_year=title["releases"][0]["releaseYear"],
                type_="movie",
                cast=cast,
            )
            titles = Title(
                id_=self.title,
                type_=Title.Types.MOVIE,
                name=tmdb_info.get("name") or title_name,
                year=int(tmdb_info.get("year")[:4]) or releaseYear,
                synopsis=title_synopsis,
                original_lang=title["originalLanguage"],
                tmdb_id=tmdb_info.get("tmdb_id") or None,
                imdb_id=tmdb_info.get("imdb_id") or None,
                thumbnail=tmdb_info.get("thumbnail")
                or title["image"]["tile"]["1.78"]["video"]["default"]["url"]
                if title["image"]["tile"]["1.78"].get("video")
                else title["image"]["tile"]["1.78"]["program"]["default"]["url"],
                source=self.ALIASES[0],
                service_data=title,
            )
        else:
            seasons: dict[str, list] = {
                s["seasonId"]: [] for s in dmc_bundle[0]["seasons"]["seasons"]
            }
            total_episodes = 0
            season_dmc_bundles = [[], []]
            for season in dmc_bundle[0]["seasons"]["seasons"]:
                total_episodes += len(season["downloadableEpisodes"])
                sid = season["seasonId"]
                if args.dl.wanted and not any(
                    x
                    for x in args.dl.wanted
                    if x.startswith(f"{season['seasonSequenceNumber']}x")
                ):
                    continue
                page = 0
                while len(seasons[sid]) < season["episodes_meta"]["hits"]:
                    page += 1
                    assert self.device_token is not None
                    seasonEpisodes = self.bamsdk.content.getDmcEpisodes(
                        region_=self.region,
                        season_id=sid,
                        page=page,
                    )
                    season_dmc_bundles[0].extend(seasonEpisodes[0]["videos"])
                    season_dmc_bundles[1].extend(seasonEpisodes[1]["videos"])
                    seasons[sid].extend(seasonEpisodes[0]["videos"])

            episodes = [x for y in seasons.values() for x in y]

            if args.dl.latest_episodes:
                latest_release_date = int(
                    str(
                        datetime.timestamp(
                            datetime.strptime(
                                episodes[-1]["releases"][0]["releaseDate"], "%Y-%m-%d"
                            )
                        )
                    )[:10]
                )
                episodes = [
                    x
                    for x in episodes
                    if int(
                        str(
                            datetime.timestamp(
                                datetime.strptime(
                                    x["releases"][0]["releaseDate"], "%Y-%m-%d"
                                )
                            )
                        )[:10]
                    )
                    == latest_release_date
                ]
            elif args.dl.wanted:
                episodes = Tracks.get_wanted(
                    episodes,
                    season="seasonSequenceNumber",
                    episode="episodeSequenceNumber",
                )

            self.total_titles = (
                len(dmc_bundle[0]["seasons"]["seasons"]),
                total_episodes,
            )

            tmdb_info = tmdb.info(
                content_name=title_name, content_year=releaseYear, type_="tv", cast=cast
            )

            for episode in episodes:
                episode["dmc_bundles"] = season_dmc_bundles
                titles = [
                    Title(
                        id_=episode["contentId"],
                        type_=Title.Types.TV,
                        name=tmdb_info.get("name") or title_name,
                        year=int(tmdb_info.get("year")[:4]) or releaseYear,
                        season=episode["seasonSequenceNumber"],
                        episode=episode["episodeSequenceNumber"],
                        synopsis=title_synopsis,
                        episode_name=episode["text"]["title"]["full"]["program"][
                            "default"
                        ]["content"],
                        original_lang=episode["originalLanguage"],
                        tmdb_id=tmdb_info.get("tmdb_id") or None,
                        imdb_id=tmdb_info.get("imdb_id") or None,
                        tvdb_id=tmdb_info.get("tvdb_id") or None,
                        thumbnail=tmdb_info.get("thumbnail"),
                        source=self.ALIASES[0],
                        service_data=episode,
                    )
                    for episode in episodes
                ]

        self.scenario = self.prepare_scenario(self, titles, self.scenario)

        return titles

    def get_tracks(self, title):
        if (
            not any(
                x["activeAspectRatio"] == 1.9
                for x in title.service_data["mediaMetadata"].get("facets", [])
            )
            and self.imax_enhanced
        ):
            self.imax_enhanced = False
        if (
            not any(
                x["activeAspectRatio"] == 1.33
                for x in title.service_data["mediaMetadata"].get("facets", [])
            )
            and self.original_aspect_ratio
        ):
            self.original_aspect_ratio = False

        tracks = []
        for i in range(2):
            media_id = (
                title.service_data["dmc_bundles"][i]["video"]["mediaMetadata"][
                    "mediaId"
                ]
                if self.movie
                else [
                    x["mediaMetadata"]["mediaId"]
                    for x in title.service_data["dmc_bundles"][i]
                    if x["contentId"] == title.id
                ][0]
            )

            manifest_url = self.get_manifest_url(
                media_id=media_id,
                scenario=self.scenario,
            ).split("?")[0]

            m3u8_tracks = self.get_manifest_tracks(
                manifest_url,
                original_lang=title.original_lang,
            )

            # Some VideoTracks from the second run has a different KID
            # while quality and bitrate are the same, so better exclude.
            if i == 1:
                m3u8_tracks.videos.clear()

            tracks += m3u8_tracks

        tracks = Tracks(tracks)

        for track in tracks.videos:
            if (
                any(
                    x["activeAspectRatio"] == 1.9
                    for x in title.service_data["mediaMetadata"].get("facets", [])
                )
                and self.imax_enhanced
            ):
                track.imax_enhanced = True
            elif (
                any(
                    x["activeAspectRatio"] == 1.33
                    for x in title.service_data["mediaMetadata"].get("facets", [])
                )
                and self.original_aspect_ratio
            ):
                track.original_aspect_ratio = True

        if not any(
            x for x in tracks.audio if x.codec and x.codec.startswith("atmos")
        ) and not self.scenario.endswith(("-atmos", "~unlimited")):
            # log.info_(" + Attempting to get Atmos audio from H265 manifest")
            atmos_scenario = self.get_manifest_tracks(
                self.get_manifest_url(
                    media_id=title.service_data["mediaMetadata"]["mediaId"],
                    scenario="tv-drm-ctr-h265-atmos",
                ),
                original_lang=title.original_lang,
            )
            tracks.audio.extend(atmos_scenario.audio)
            tracks.subtitles.extend(atmos_scenario.subtitles)

        if cdm.security_level == 3 and not args.dl.cache:
            tracks.videos = [
                x
                for x in tracks.videos
                if x.height <= 720
                and not x.hdr10
                and not x.hlg
                and not x.dv
                and "avc" in x.codec
            ]

        return tracks

    def get_chapters(self, title):
        milestones = title.service_data.get("milestone")
        if not milestones:
            return []
        has_recap = any(x == "recap_start" for x in milestones)
        types = {
            "recap_start": "Recap",
            "recap_end": "Scene 1",
            "intro_start": "Intro",
            "intro_end": "Scene 2" if has_recap else "Scene 1",
            "up_next": "Credits",
            # FFEI seems to be the same as intro_start.
            #
            # Types with unknown purpose:
            # LFEI, FF0C, FFTC, LFTC, FFEC, LFEC
        }
        chapters = []
        for milestone in milestones:
            name = types.get(milestone)
            if not name:
                if milestone != "FFEI":
                    pass
                    # log.warning_(f" - Skipping unknown chapter type {milestone!r}")
                continue
            ms = int(milestones[milestone][0]["milestoneTime"][0]["startMillis"])
            chapters.append(
                MenuTrack(
                    number=len(chapters) + 1,
                    title=name,
                    timecode=datetime.utcfromtimestamp(ms / 1000).strftime(
                        "%H:%M:%S.%f"
                    )[:-3],
                )
            )
        return chapters

    def certificate(self, **_: Any) -> str:
        return self.config["certificate"]

    def license(self, challenge, track, **_):
        licensing = self.bamsdk.drm.widevineLicense(
            license=challenge,  # expects bytes
            access_token=self.account_tokens.get("accessToken")
            or self.account_tokens.get("access_token"),
        )

        if "capability" in str(licensing):
            if track.fallback_pssh:
                licensing = self.bamsdk.drm.widevineLicense(
                    license=cdm.get_license_challenge(
                        session_id=cdm.session_id,
                        pssh=track.fallback_pssh,
                        type_="STREAMING",
                    ),  # expects bytes
                    access_token=self.account_tokens.get("accessToken")
                    or self.account_tokens.get("access_token"),
                )

            if "capability" in str(licensing):
                raise CdmNotCapable(
                    non_whitelisted=True,
                    downgraded=bool(licensing == "capability-hd"),
                    capability="720p SDR"
                    if licensing == "capability-hd"
                    else "1080p SDR",
                )

        return licensing

    # Service specific functions

    def configure(self):
        self.session.headers.update(
            {
                "Accept-Language": "en-US,en;q=0.5",
                "User-Agent": self.config["bamsdk"]["user_agent"],
                "Origin": "https://www.disneyplus.com",
            }
        )

        self.region = self.session.ipinfo["country"].upper()
        self.config["location_x"], self.config["location_y"] = self.session.ipinfo[
            "loc"
        ].split(",")

        self.bamsdk = BamSdk(self.config["bamsdk"]["config"], self.session, self.region)
        self.session.headers.update(
            dict(
                **{
                    k.lower(): v.replace(
                        "{SDKPlatform}", self.config["bamsdk"]["platform"]
                    ).replace("{SDKVersion}", self.config["bamsdk"]["version"])
                    for k, v in self.bamsdk.commonHeaders.items()
                },
                **{"user-agent": self.config["bamsdk"]["user_agent"]},
            )
        )

        if self.original_aspect_ratio and self.imax_enhanced:
            if self.ctx.default_map.get(
                "original_aspect_ratio"
            ) and not self.ctx.default_map.get("imax_enhanced"):
                self.original_aspect_ratio = False
            elif self.ctx.default_map.get(
                "imax_enhanced"
            ) and not self.ctx.default_map.get("original_aspect_ratio"):
                self.imax_enhanced = False

        # log.info_(" + Capabilities:")
        for k, v in self.bamsdk.media.extras.items():
            pass
            # log.info_(f"   {k}: {v}")

        # log.info_("Logging into Disney+")
        self.device_token, self.account_tokens = self.login(self.credentials)

        session_info = self.bamsdk.session.getInfo(
            self.account_tokens.get("accessToken")
            or self.account_tokens.get("access_token")
        )
        # log.info_(f" + Account ID: {session_info['account']['id']}")
        # log.info_(f" + Profile ID: {session_info['profile']['id']}")
        # log.info_(f" + Subscribed: {session_info['isSubscriber']}")
        # log.info_(f" + Account Region: {session_info['home_location']['country_code']}")
        # log.info_(f" + Detected Location: {session_info['location']['country_code']}")
        # log.info_(f" + Supported Location: {session_info['inSupportedLocation']}")
        # log.info_(f" + Device: {session_info['device']['platform']}")

        try:
            if not session_info["isSubscriber"]:
                log.exit(" x Cannot continue, account is not subscribed to Disney+")
        except KeyError:
            log.exit(" x Cannot continue, we have problems with the connection")

        return self.account_tokens

    @staticmethod
    def prepare_scenario(self, titles, scenario) -> str:
        """Prepare Disney+'s scenario based on other arguments and settings."""
        if scenario.endswith("~unlimited"):
            # if unlimited scenario, nothing needs to be appended or changed.
            # the scenario will return basically all streams it can.
            return scenario
        if cdm.security_level == 1:
            if args.dl.video_codec == "H.265":
                scenario += "-h265"
            if (
                args.dl.range in ["HDR", "HDR10", "HDR+DV", "HDR10+DV"]
                and any(
                    "hdr" in x.service_data["mediaMetadata"]["features"]
                    for x in [titles]
                )
                if self.movie
                else args.dl.range in ["HDR", "HDR10", "HDR+DV", "HDR10+DV"]
                and any(
                    "hdr" in x.service_data["mediaMetadata"]["features"] for x in titles
                )
            ):
                if "-h265" not in scenario:
                    scenario += "-h265"
                scenario += "-hdr10"
            elif (
                args.dl.range == "DV"
                and any(
                    "dolby_vision" in x.service_data["mediaMetadata"]["features"]
                    for x in [titles]
                )
                if self.movie
                else args.dl.range == "DV"
                and any(
                    "dolby_vision" in x.service_data["mediaMetadata"]["features"]
                    for x in titles
                )
            ):
                if "-h265" not in scenario:
                    scenario += "-h265"
                scenario += "-dovi"
        return scenario

    def login(self, credential: Credential) -> tuple:
        """Log into Disney+ and retrieve various authorisation keys."""
        device_token = self.create_device_token(
            family=self.config["bamsdk"]["family"],
            profile=self.config["bamsdk"]["profile"],
            application=self.config["bamsdk"]["applicationRuntime"],
            api_key=self.config["device_api_key"],
        )
        account_tokens = self.get_account_token(
            credential=credential,
            device_family=self.config["bamsdk"]["family"],
            device_token=device_token,
        )
        return device_token, account_tokens

    def create_device_token(self, family, profile, application, api_key) -> str:
        """
        Create a Device Token for a specified device type.
        This tells the API's what is possible for your device.
        :param family: Device Family.
        :param profile: Device Profile.
        :param application: Device Runtime, the use case of the device.
        :param api_key: Device API Key.
        :returns: Device Exchange Token.
        """
        # create an initial assertion grant used to identify the kind of device profile-level.
        # TODO: cache this, it doesn't need to be obtained unless the values change
        device_grant = self.session.post(
            url="https://disney.api.edge.bamgrid.com/devices",  # Hardcoded since its gone in BAMSDK v4
            json={
                "deviceFamily": family,
                "applicationRuntime": application,
                "deviceProfile": profile,
                "attributes": {},
            },
            headers={"Authorization": f"Bearer {api_key}"},
        ).json()
        if "errors" in device_grant:
            log.exit(
                f"Failed to obtain the device assertion grant: {device_grant['errors']!r}"
            )
        # exchange the assertion grant for a usable device token.
        device_token = self.bamsdk.token.exchange(
            data={
                "grant_type": "urn:ietf:params:oauth:grant-type:token-exchange",
                "latitude": self.config["location_x"],
                "longitude": self.config["location_y"],
                "platform": family,
                "subject_token": device_grant["assertion"],
                "subject_token_type": self.bamsdk.token.subject_tokens["device"],
            },
            api_key=api_key,
        )
        if "error" in device_token:
            log.exit(
                f"Failed to exchange the assertion grant for a device token: '{device_token['error_description']} [{device_token['error']}]'"
            )

        return device_token["access_token"]

    def get_account_token(
        self, credential: Credential, device_family, device_token
    ) -> dict:
        """
        Get an Account Token using Account Credentials and a Device Token, using a Cache store.
        It also refreshes the token if needed.
        """
        if not credential:
            log.exit(" x No credentials provided, unable to log in.")

        if self.imax_enhanced:
            type = "_IMAX"
        elif self.original_aspect_ratio:
            type = "_OAR"
        else:
            type = ""

        tokens_cache_path = self.get_cache(
            f"{self.region}{type}_{credential.sha1}.json"
        )
        if tokens_cache_path.is_file():
            tokens = json.loads(tokens_cache_path.read_text(encoding="utf8"))
            expires = tokens.get("expiresIn") or tokens.get("expires_in")
            if tokens_cache_path.stat().st_ctime > (time.time() - expires):
                return tokens

            # Token expired, refreshing.
            tokens = self.graphql(
                tokens
            )  # Will also use the refresh token and will give us fresh tokens
        else:
            # first time
            # log.info_(" + Getting new tokens...")
            tokens = self.create_account_token(
                device_family=self.config["bamsdk"]["family"],
                email=credential.username,
                password=credential.password,
                device_token=device_token,
                api_key=self.config["device_api_key"],
            )
        tokens_cache_path.parent.mkdir(parents=True, exist_ok=True)
        tokens_cache_path.write_text(json.dumps(tokens, indent=3))
        return tokens

    def create_account_token(
        self, device_family, email, password, device_token, api_key
    ) -> dict:
        """
        Create an Account Token using Account Credentials and a Device Token.
        :param device_family: Device Family.
        :param email: Account Email.
        :param password: Account Password.
        :param device_token: Device Token.
        :param api_key: Device API Key.
        :returns: Account Exchange Tokens.
        """
        # log in to the account via bamsdk using the device token
        identity_token = self.session.post(
            url="https://disney.api.edge.bamgrid.com/idp/login",  # Hardcoded since its gone in BAMSDK v4
            json={"email": email, "password": password},
            headers={
                "Authorization": f"Bearer {device_token}",
            },
        ).json()
        if "errors" in identity_token:
            if (
                "Bad credentials sent for disney"
                in identity_token["errors"][0]["description"]
            ):
                log.exit("\n x The credentials seems to be invalid")
            log.exit(
                f"Failed to obtain the identity token: {identity_token['errors']!r}"
            )
        # create an initial assertion grant used to identify the account
        # this seems to tie the account to the device token
        account_grant = self.bamsdk.account.createAccountGrant(
            json={"id_token": identity_token["id_token"]}, access_token=device_token
        )
        # exchange the assertion grant for a usable account token.
        account_tokens = self.bamsdk.token.exchange(
            data={
                "grant_type": "urn:ietf:params:oauth:grant-type:token-exchange",
                "latitude": self.config["location_x"],
                "longitude": self.config["location_y"],
                "platform": device_family,
                "subject_token": account_grant["assertion"],
                "subject_token_type": self.bamsdk.token.subject_tokens["account"],
            },
            api_key=api_key,
        )
        # Get active profile
        self.profile = self.get_profile(account_tokens["access_token"])
        account_tokens = self.bamsdk.token.exchange(
            data={
                "grant_type": "urn:ietf:params:oauth:grant-type:token-exchange",
                "latitude": self.config["location_x"],
                "longitude": self.config["location_y"],
                "platform": device_family,
                "subject_token": self.profile["assertion"],
                "subject_token_type": self.bamsdk.token.subject_tokens["account"],
            },
            api_key=api_key,
        )
        account_tokens["activeProfile"] = self.profile["activeProfile"]
        if (
            not self.original_aspect_ratio
            and account_tokens["activeProfile"]["attributes"]["playbackSettings"][
                "prefer133"
            ]
            or not self.imax_enhanced
            and account_tokens["activeProfile"]["attributes"]["playbackSettings"][
                "preferImaxEnhancedVersion"
            ]
            or self.original_aspect_ratio
            and not account_tokens["activeProfile"]["attributes"]["playbackSettings"][
                "prefer133"
            ]
            or self.imax_enhanced
            and not account_tokens["activeProfile"]["attributes"]["playbackSettings"][
                "preferImaxEnhancedVersion"
            ]
        ):
            account_tokens = self.graphql(account_tokens)
        return account_tokens

    def get_profile(self, access_token) -> dict:
        profiles = self.bamsdk.account.getUserProfiles(access_token)
        res = self.bamsdk.account.setActiveUserProfile(
            profiles["activeProfile"]["profileId"], access_token
        )
        if "errors" in res:
            log.exit(f" - Failed! {res['errors'][0]['description']}")
        res["activeProfile"] = profiles["activeProfile"]
        return res

    def graphql(self, account_tokens):
        activeProfile = account_tokens["activeProfile"]
        access_token = account_tokens.get("accessToken") or account_tokens.get(
            "access_token"
        )
        refresh_token = account_tokens.get("refreshToken") or account_tokens.get(
            "refresh_token"
        )

        res = self.session.patch(
            url=f'https://disney.api.edge.bamgrid.com/accounts/me/profiles/{activeProfile["profileId"]}',
            json={
                "profileId": activeProfile["profileId"],
                "profileName": activeProfile["profileName"],
                "attributes": {
                    "avatar": {
                        "id": activeProfile["attributes"]["avatar"]["id"],
                        "userSelected": activeProfile["attributes"]["avatar"][
                            "userSelected"
                        ],
                    },
                    "isDefault": activeProfile["attributes"]["isDefault"],
                    "kidsModeEnabled": False,  # TODO: Will this give us limited content if set to True?
                    "parentalControls": {
                        "kidProofExitEnabled": False,  # Will give us limited content when set to True
                        "isPinProtected": activeProfile["attributes"][
                            "parentalControls"
                        ][
                            "isPinProtected"
                        ],  # Not sure if it has impact for us
                    },
                    "playbackSettings": {
                        "prefer133": self.original_aspect_ratio,
                        "preferImaxEnhancedVersion": self.imax_enhanced,
                    },
                },
                "metadata": {},
            },
            headers={
                "Authorization": access_token,
            },
        )

        res = self.session.post(
            url="https://disney.api.edge.bamgrid.com/graph/v1/device/graphql",
            json={
                "operationName": "refreshToken",
                "query": """mutation refreshToken($input: RefreshTokenInput!) {
                    refreshToken(refreshToken: $input) {
                        activeSession {
                            sessionId
                        }
                    }
                }""",
                "variables": {"input": {"refreshToken": refresh_token}},
            },
            headers={"Authorization": self.config["device_api_key"]},
        ).json()

        account_tokens = res["extensions"]["sdk"]["token"]
        activeProfile["attributes"]["playbackSettings"][
            "prefer133"
        ] = self.original_aspect_ratio
        activeProfile["attributes"]["playbackSettings"][
            "preferImaxEnhancedVersion"
        ] = self.imax_enhanced
        account_tokens["activeProfile"] = activeProfile

        return account_tokens

    def get_manifest_url(self, media_id, scenario) -> str:
        # log.info_(f"Retrieving manifest for {media_id} {scenario}")
        manifest = self.bamsdk.media.mediaPayload(
            media_id=media_id,
            scenario=scenario,
            region=self.region,
            tokens=self.account_tokens,
            dsnp_self=self,
        )
        return manifest["stream"]["complete"][0]["url"]

    def get_manifest_tracks(self, url, original_lang):
        tracks = Tracks.from_m3u8(
            m3u8.load(url.split("?")[0]), lang=original_lang, source=self.ALIASES[0]
        )
        for audio in tracks.audio:
            bitrate = re.search(
                r"(?<=r/composite_)\d+|\d+(?=_complete.m3u8)", as_list(audio.url)[0]
            )
            if not bitrate:
                log.exit(" - Unable to get bitrate for an audio track")
            audio.bitrate = int(bitrate.group()) * 1000
            if audio.bitrate == 1000000:
                # DSNP lies about the Atmos bitrate
                audio.bitrate = 768000
                # Sometimes labeled as 14/JOC which does not exist
                # 5lcsQ9JsJzEP has it, seems to be a typo.
                audio.channels = "16/JOC"
        for subtitle in tracks.subtitles:
            subtitle.codec = "vtt"
            subtitle.forced = subtitle.forced or subtitle.extra.name.endswith(
                "--forced--"
            )
            # sdh might not actually occur, either way DSNP CC == SDH :)
            subtitle.sdh = (
                "[cc]" in subtitle.extra.name.lower()
                or "[sdh]" in subtitle.extra.name.lower()
            )
        return tracks
