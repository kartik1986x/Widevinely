from __future__ import annotations

from typing import Any

import click
from click import Context
from langcodes import Language

from widevinely.objects import MenuTrack, Title, Tracks
from widevinely.utils import is_close_match
from widevinely.services.BaseService import BaseService
from widevinely.utils import tmdb, logger
from widevinely.utils.globals import arguments
from widevinely.utils.exceptions import *

log = logger.getLogger("VIAP")


class Viaplay(BaseService):
    """
    Service code for Scandinavian's Viaplay. streaming service (https://viaplay.com).

    Authorization: Credentials
    Security: UHD@-- FHD@L3, doesn't care about releases.

    """

    ALIASES = ["VIAP", "viaplay"]

    TITLE_RE = [
        r"^(?:https?://viaplay\.com(?:/[a-z0-9-]+)?/(?P<type>movies|series|sport|kids)/)?(?P<id>[a-z0-9-.]+)?"
    ]

    ZONES = (
        r"^(?:https?://viaplay\.com/(?P<region>nl|us)?(?:/)(?P<type>movies|series|sport|kids)/)?(?P<id>[a-z0-9-.]+)?",
        None,
        "nl",
    )

    @staticmethod
    @click.command(name="Viaplay", short_help="viaplay.com")
    @click.argument("title", type=str)
    @click.option(
        "-r",
        "--region",
        type=str,
        default="nl",
        help="Region where the title is available or you want to get from.",
    )
    @click.pass_context
    def cli(ctx: Context, **kwargs: Any) -> Viaplay:
        return Viaplay(ctx, **kwargs)

    def __init__(self, ctx, title, region):
        global args
        args = arguments()

        m = self.parse_title(ctx, title)
        self.movie = m.get("type") == "movies"
        self.sport = m.get("type") == "sport"
        self.kids = m.get("type") == "kids"
        self.region = region

        super().__init__(ctx)

        self.session = BaseService.get_session(self)

        self.configure()

        self.auth_token = self.auth["access_token"]
        self.region = self.auth["country"]
        self.profile_id = self.auth["profile_id"]

    def get_titles(self, seasons=[], episodes=[]):
        service_data = self.session.get(
            url=f"{self.config['endpoints']['content_url'].format(region=self.region)}{'movies' if self.movie else 'kids' if self.kids else 'sport' if self.sport else 'series'}/{self.title}",
            params={"profile_id": self.profile_id},
        ).json()
        try:
            metadata = service_data["_embedded"]["viaplay:blocks"][0]["_embedded"][
                "viaplay:product"
            ]
        except KeyError:
            metadata = service_data["_embedded"]["viaplay:blocks"][0]["_embedded"][
                "viaplay:article"
            ]

        cast = (
            metadata["content"]["people"].get("actors") or []
            if metadata["content"].get("people")
            else []
        )

        self.original_lang = (
            [
                x["languageCode"]
                for x in service_data["_embedded"]["viaplay:blocks"][0]["_embedded"][
                    "viaplay:product"
                ]["content"]["language"]["audio"]
                if x.get("default")
            ][0]
            if service_data["_embedded"]["viaplay:blocks"][0]["_embedded"].get(
                "viaplay:product"
            )
            and service_data["_embedded"]["viaplay:blocks"][0]["_embedded"][
                "viaplay:product"
            ]["content"].get("language")
            else "en"
        )

        if metadata["type"] == "movie":
            tmdb_info = tmdb.info(
                imdb_id=metadata["content"]["imdb"]["id"]
                if metadata["content"].get("imdb")
                else None,
                content_name=metadata["content"]["title"],
                content_year=metadata["content"]["production"]["year"],
                type_="movie",
                cast=cast,
            )
            titles = Title(
                id_=self.title,
                type_=Title.Types.MOVIE,
                name=tmdb_info.get("name") or metadata["content"]["title"],
                year=int(tmdb_info.get("year")[:4])
                or metadata["content"]["production"]["year"],
                synopsis=tmdb_info.get("synopsis") or metadata["content"]["synopsis"],
                original_lang=tmdb_info.get("original_language") or self.original_lang,
                tmdb_id=tmdb_info.get("tmdb_id") or None,
                imdb_id=tmdb_info.get("imdb_id") or None,
                thumbnail=tmdb_info.get("thumbnail")
                or metadata["content"]["images"]["boxart"]["template"].replace(
                    "{?width,height}", ""
                ),
                source=self.ALIASES[0],
                service_data=metadata,
            )
        elif metadata["type"] == "article":
            seasons += [
                info
                for info in service_data["_embedded"]["viaplay:blocks"]
                if info["type"] == "season-list"
            ]
            for season in seasons:
                season = self.session.get(
                    url=season["_links"]["self"]["href"],
                ).json()

                for episode in [
                    info
                    for info in season["_embedded"]["viaplay:products"]
                    if info["type"] == "episode"
                ]:
                    episodes.append(episode)

            self.total_titles = (
                len(
                    set(
                        [
                            x["content"]["series"]["season"]["seasonNumber"]
                            for x in episodes
                        ]
                    )
                ),
                len(episodes),
            )

            if args.dl.latest_episodes:
                episodes = [episodes[-1]]  # TODO: Need to find a better way than this
            elif args.dl.wanted:
                for episode in episodes:
                    episode["seasonNumber"] = episode["content"]["series"]["season"][
                        "seasonNumber"
                    ]
                    episode["episodeNumber"] = episode["content"]["series"][
                        "episodeNumber"
                    ]

                episodes = Tracks.get_wanted(
                    episodes,
                    season="seasonNumber",
                    episode="episodeNumber",
                )

            tmdb_info = tmdb.info(
                imdb_id=metadata["content"]["imdb"]["id"]
                if metadata["content"].get("imdb")
                else None,
                content_name=metadata["content"]["title"],
                content_year=metadata["content"]["production"]["year"],
                type_="tv",
                cast=cast,
            )

            episode_id_title = episode["content"].get("originalTitle") or episode[
                "content"
            ].get("title")
            for episode in episodes:
                titles = [
                    Title(
                        id_=f"{episode_id_title.lower().replace(' ', '-') or episode['content']['title'].lower().replace(' ', '-')}-s{episode['content']['series']['season']['seasonNumber']}e{episode['content']['series']['episodeNumber']}",
                        type_=Title.Types.TV,
                        name=tmdb_info.get("name") or metadata["content"]["title"],
                        year=int(tmdb_info.get("year")[:4])
                        or metadata["content"]["production"]["year"],
                        season=episode["content"]["series"]["season"]["seasonNumber"],
                        episode=episode["content"]["series"]["episodeNumber"],
                        episode_name=episode["_links"]["self"]["title"],
                        synopsis=tmdb_info.get("synopsis")
                        or metadata["content"]["synopsis"],
                        original_lang=tmdb_info.get("original_language")
                        or self.original_lang,
                        tmdb_id=tmdb_info.get("tmdb_id") or None,
                        imdb_id=tmdb_info.get("imdb_id") or None,
                        tvdb_id=tmdb_info.get("tvdb_id") or None,
                        thumbnail=episode["content"]["images"]["landscape"][
                            "template"
                        ].replace("{?width,height}", "")
                        or tmdb_info.get("thumbnail"),
                        source=self.ALIASES[0],
                        service_data=episode,
                    )
                    for episode in episodes
                ]
        return titles

    def get_tracks(self, title):
        params = {
            "deviceId": "a1bd2e3f-92f2-5rk9-k9f8-e03i0293r039",
            "profileId": self.profile_id,
            "userAgent": self.session.headers.get("User-Agent"),
            "deviceName": "android",
            "deviceType": "androidtv",
            "deviceKey": f"androiddash-{self.region}",
            "cse": True,
            "guid": title.service_data["system"]["guid"],
            "sectionPath": title.service_data["type"],
            "defaultAvailabilityContext": "svod",
        }

        manifest = self.session.get(
            url=f"{self.config['endpoints']['manifest_url']}stream/byguid",
            params=params,
        ).json()
        if "code" in manifest:
            if manifest["name"] == "MissingVideoError":
                log.exit(" x This title does not seem to be available (yet)")
            else:
                log.exit(f" x {manifest['message']}")

        self.license_url = manifest["_links"]["viaplay:widevineLicense"]["href"]

        if "viaplay:media" in manifest["_links"]:
            self.mpd_url = manifest["_links"]["viaplay:media"]["href"]
        elif "viaplay:fallbackMedia" in manifest["_links"]:
            self.mpd_url = manifest["_links"]["viaplay:fallbackMedia"][0]["href"]
        elif "viaplay:playlist" in manifest["_links"]:
            self.mpd_url = manifest["_links"]["viaplay:playlist"]["href"]
        elif "viaplay:encryptedPlaylist" in manifest["_links"]:
            self.mpd_url = manifest["_links"]["viaplay:encryptedPlaylist"]["href"]
        else:
            log.exit(" x Failed to retrieve stream url")

        tracks = Tracks.from_mpd(
            url=self.mpd_url.split("?filter")[0],
            session=self.session,
            lang=title.original_lang,
            source=self.ALIASES[0],
        )

        if (
            not any(a.is_original_lang for a in tracks.audio)
            and title.original_lang != self.original_lang
        ):
            title.original_lang = Language.get(self.original_lang)
            args.dl.alang[0] = self.original_lang
            for track in tracks:
                track.is_original_lang = bool(
                    track.language.language == self.original_lang
                )

        for audio in tracks.audio:
            if audio.codec in ["ac-3", "ec-3"]:
                audio.channels = "5.1"
            else:
                audio.channels = "2.0"

        for subtitle in tracks.subtitles:
            subtitle.codec = "vtt"
            subtitle.is_original_lang = is_close_match(
                subtitle.language, [title.original_lang]
            )

        return tracks

    def get_chapters(self, title: Title) -> list[MenuTrack]:
        return []

    def certificate(self, **kwargs: Any) -> bytes:
        return None

    def license(self, challenge: bytes, **_: Any) -> bytes:
        assert self.license_url is not None
        return self.session.post(
            url=self.license_url, data=challenge  # expects bytes
        ).content

    # Service specific functions

    def configure(self):
        self.session.headers.update(
            {"Origin": "https://viaplay.com", "Referer": "https://viaplay.com/"}
        )
        self.auth = self.auth()

    def auth(self) -> dict:
        # TODO: reduce the amount of login and cache it
        if not self.credentials:
            log.exit(" x No credentials provided, unable to log in.")

        params = {
            "deviceKey": "androiddash-nl",  # nl is just the default, response will contain the actual region
            "returnurl": self.config["endpoints"]["content_url"],
            "username": self.credentials.username,
            "persistent": "true",
        }
        payload = {
            "password": self.credentials.password,
        }

        login = self.session.post(
            self.config["endpoints"]["auth_url"] + "login/v1",
            params=params,
            data=payload,
            headers=self.session.headers,
        ).json()

        if "message" in str(login):
            if "IP address" in login["message"]:
                raise VPN_PROXY_DETECTED

        tokens = {
            "access_token": login["userData"]["accessToken"],
            "country": login["userData"]["accountCountry"].lower(),
            "profile_id": login["userData"]["userId"],
        }

        return tokens
