import sys
import uuid

import click

from widevinely.objects import Title, Tracks
from widevinely.services.BaseService import BaseService
from widevinely.utils.globals import arguments
from widevinely.utils import tmdb, logger

log = logger.getLogger("DSCP")


class DiscoveryPlus(BaseService):
    """
    Service code for Discovery+ (https://www.discoveryplus.com/).

    \b
    Authorization: Cookies
    Security: UHD@? FHD@L3
    """

    ALIASES = ["DSCP", "discoveryplus", "discovery+"]

    ZONES = (
        r"^(?:https?://(?:www\.)?discoveryplus\.com/(?P<region>nl|us)?(?:/)(?:show|video)/)?(?P<id>[a-z0-9-]+)",
        None,
        "us",
    )

    TITLE_RE = r"^(?:https?://(?:www\.)?discoveryplus\.com/(?:.+)?(?:show|video)/)?(?P<id>[a-z0-9-]+)"

    @staticmethod
    @click.command(name="DiscoveryPlus", short_help="discoveryplus.com")
    @click.argument("title", type=str, required=False)
    @click.option(
        "-r",
        "--region",
        type=str,
        default="nl",
        help="Region where the title is available or you want to get from.",
    )
    @click.pass_context
    def cli(ctx, **kwargs):
        return DiscoveryPlus(ctx, **kwargs)

    def __init__(self, ctx, title, region):
        global args
        args = arguments()

        super().__init__(ctx)
        self.parse_title(ctx, title)

        if region == "nl":
            self.region = "eu"
        elif region == "us":
            self.region = "us"

        self.session = BaseService.get_session(self)

        self.configure()

    def get_titles(self):
        res = self.session.get(
            self.config["endpoints"]["show"].format(
                region=self.region, title_id=self.title, season="", show_id=""
            )
        )
        if res.is_error:
            errors = res.json()["errors"]
            for error in errors:
                error_message = f"{error['detail']} [{error['code']}]"
                if error["code"] == "invalid.token":
                    error_message += ". Cookies may be expired or invalid or are from another region."
                    log.exit(
                        " x Your cookies may be expired or invalid or are from another region"
                    )
                # log.exit(f" - {error_message}")
            # sys.exit(1)
        res = res.json()

        page = next(x for x in res["included"] if x["type"] == "page")
        episodes = [x for x in res["included"] if x["type"] == "video"]

        show_info = next(
            x
            for x in res["included"]
            if x["attributes"].get("alias") == "generic-show-episodes"
        )
        generic_id = show_info["id"]
        show_id = show_info["attributes"]["component"]["mandatoryParams"]
        seasons = show_info["attributes"]["component"]["filters"][0]["options"]

        self.total_titles = (len(seasons), len(episodes))

        if len(seasons) > 1:
            for Season in seasons[1:]:
                season = self.session.get(
                    url=self.config["endpoints"]["season"].format(
                        generic_id=generic_id,
                        season=Season["parameter"],
                        show_id=show_id,
                    )
                ).json()
                season_ = [x for x in season["included"] if x["type"] == "video"]
                for ep in season_:
                    episodes.append(ep)

        if args.dl.latest_episodes:
            ...
        elif args.dl.wanted:
            episodes = [
                episode
                for episode in episodes
                if episode["attributes"]["videoType"] == "EPISODE"
            ]
            for episode in episodes:
                episode["seasonNumber"] = episode["attributes"]["seasonNumber"]
                episode["episodeNumber"] = episode["attributes"]["episodeNumber"]

            episodes = Tracks.get_wanted(
                episodes,
                season="seasonNumber",
                episode="episodeNumber",
            )

        for ep in episodes:
            if ep["attributes"]["videoType"] == "STANDALONE":
                tmdb_info = tmdb.info(
                    content_name=page["attributes"]["title"],
                    content_year=ep["attributes"]["airDate"][:4],
                    type_="movie",
                )

                movie_info = tmdb.movie(
                    page["attributes"]["title"], ep["attributes"]["airDate"][:4]
                )
                titles = [
                    Title(
                        id_=ep["id"],
                        type_=Title.Types.MOVIE,
                        name=tmdb_info.get("name") or page["attributes"]["title"],
                        year=int(tmdb_info.get("year")[:4])
                        or ep["attributes"]["airDate"][:4],
                        synopsis=tmdb_info.get("synopsis")
                        or page["attributes"]["description"]
                        if page["attributes"]["description"]
                        else None,
                        original_lang=movie_info["original_language"]
                        if movie_info["original_language"]
                        else "nl"
                        if self.region == "eu"
                        else "en",
                        tmdb_id=tmdb_info.get("tmdb_id") or None,
                        imdb_id=tmdb_info.get("imdb_id") or None,
                        thumbnail=tmdb_info.get("thumbnail")
                        or None,  # TODO: see if there's some thumbnail in the API
                        source=self.ALIASES[0],
                        service_data=ep,
                    )
                ]
            elif ep["attributes"]["videoType"] == "EPISODE":
                tmdb_info = tmdb.info(
                    content_name=page["attributes"]["title"], type_="tv"
                )

                titles = [
                    Title(
                        id_=ep["id"],
                        type_=Title.Types.TV,
                        name=tmdb_info.get("name") or page["attributes"]["title"],
                        year=int(tmdb_info.get("year")[:4])
                        if tmdb_info.get("year")
                        else None,  # TODO: Get year from show
                        season=ep["attributes"].get("seasonNumber"),
                        episode=ep["attributes"].get("episodeNumber"),
                        synopsis=tmdb_info.get("synopsis")
                        or page["attributes"]["description"]
                        if page["attributes"]["description"]
                        else None,
                        original_lang=tmdb_info.get("original_language") or "nl"
                        if self.region == "eu"
                        else "en",
                        tmdb_id=tmdb_info.get("tmdb_id") or None,
                        imdb_id=tmdb_info.get("imdb_id") or None,
                        tvdb_id=tmdb_info.get("tvdb_id") or None,
                        thumbnail=tmdb_info.get("thumbnail")
                        or None,  # TODO: see if there's some thumbnail in the API
                        source=self.ALIASES[0],
                        service_data=ep,
                    )
                    for ep in episodes
                    if ep["attributes"]["videoType"] == "EPISODE"
                ]

        return titles

    def get_tracks(self, title):
        res = self.session.post(
            self.config["endpoints"]["video_playback_info"].format(region=self.region),
            json={
                "deviceInfo": {
                    "adBlocker": False,
                    "drmSupported": True,
                    "hdrCapabilities": ["SDR"],
                    "hwDecodingCapabilities": [],
                    "player": {
                        "width": 3840,
                        "height": 2160,
                    },
                    "screen": {
                        "width": 3840,
                        "height": 2160,
                    },
                    "soundCapabilities": ["STEREO"],
                },
                "videoId": title.id,
                "wisteriaProperties": {
                    "advertiser": {
                        "adId": (
                            "|90805886454030367517733395486106519740|7|162946912055798e598aa6afa21334181500f4dd59d91",
                        ),
                        "firstPlay": 0,
                        "fwDid": "",
                        "fwIsLat": 1,
                        "fwNielsenAppId": "P5A0FD4DE-4AE6-4B22-811B-36B9BD091980",
                        "gpaln": "",
                        "interactiveCapabilities": ["brightline"],
                    },
                    "appBundle": "",
                    "device": {
                        "browser": {
                            "name": "chrome",
                            "version": "97.0.4692.99",
                        },
                        "language": "en",
                        "make": "",
                        "model": "",
                        "name": "Chrome",
                        "os": "Windows",
                        "osVersion": "10",
                        "type": "desktop",
                        "id": "5623aa854dfd48ba8d238067d11ebc55",
                        "player": {
                            "name": "Discovery Player Web",
                            "version": "27.15.1",
                        },
                    },
                    "gdpr": 0,
                    "siteId": "dplus_us",
                    "platform": "desktop",
                    "playbackId": str(uuid.uuid4()),
                    "product": "dplus_us",
                    "sessionId": str(uuid.uuid4()),
                    "streamProvider": {
                        "suspendBeaconing": 0,
                        "hlsVersion": 7,
                        "pingConfig": 0,
                        "version": "1.0.0",
                    },
                },
            },
        ).json()
        errors = res.get("errors", [])
        for error in errors:
            log.exit(f" - {error['detail']} [{error['code']}]")
        if errors:
            sys.exit(1)

        if res["data"]["attributes"]["streaming"][0]["protection"]["drmEnabled"]:
            self.license_url = res["data"]["attributes"]["streaming"][0]["protection"][
                "schemes"
            ]["widevine"]["licenseUrl"]
            self.drm_token = res["data"]["attributes"]["streaming"][0][
                "protection"
            ].get("drmToken")

        tracks = Tracks.from_mpd(
            url=res["data"]["attributes"]["streaming"][0]["url"],
            lang="nl" if self.region == "eu" else "en",  # TODO: Don't assume
            source=self.ALIASES[0],
            session=self.session,
        )

        for audio in tracks.audio:
            audio.language = title.original_lang
        
        for text in tracks.subtitles:
            text.codec = "vtt"

        return tracks

    def get_chapters(self, title):
        return []

    def certificate(self, **_):
        return self.config["certificate"]

    def license(self, *, challenge, **_):
        self.session.headers.update({"preauthorization": self.drm_token})
        r = self.session.post(self.license_url, data=challenge)
        return r.content

    # Service-specific functions

    def configure(self):
        self.session.headers.update(
            {
                "origin": "https://www.discoveryplus.com",
                "referer": "https://www.discoveryplus.com/",
                "x-disco-client": "WEB:UNKNOWN:dplus_us:1.30.1",
                "x-disco-params": "realm=dplay,siteLookupKey=dplus_nl,bid=dplus,hn=www.discoveryplus.com,hth=nl,features=ar",
            }
        )
