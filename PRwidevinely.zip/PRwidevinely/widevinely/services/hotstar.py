import base64
import hashlib
import hmac
import json
import os
import time

import click

from datetime import datetime

from widevinely.objects import Title, Tracks, VideoTrack
from widevinely.services.BaseService import BaseService
from widevinely.utils.exceptions import *
from widevinely.utils.globals import arguments
from widevinely.utils import tmdb, logger

log = logger.getLogger("Hotstar")


class Hotstar(BaseService):
    """
    Service code for Star India's Hotstar (aka Disney+ Hotstar) streaming service (https://hotstar.com).

    \b
    Authorization: Cookies
    Security:
        - L3: <= 2160p

    \b
    Tips: - The library of contents can be viewed without logging in at https://hotstar.com
          - The homepage hosts domestic programming; Disney+ content is at https://hotstar.com/in/disneyplus
    """

    ALIASES = ["HS", "hotstar"]
    TITLE_RE = r"^(?:https?://(?:www\.)?hotstar\.com/[a-z0-9/-]+/)(?P<id>\d+)"

    @staticmethod
    @click.command(name="Hotstar", short_help="hotstar.com")
    @click.argument("title", type=str, required=False)
    @click.option(
        "-m", "--movie", is_flag=True, default=False, help="Title is a movie."
    )
    @click.pass_context
    def cli(ctx, **kwargs):
        return Hotstar(ctx, **kwargs)

    def __init__(self, ctx, title, movie):
        global args
        args = arguments()
        super().__init__(ctx)

        self.parse_title(ctx, title)
        self.movie = movie or "movies" in title

        self.profile = ctx.obj.profile
        self.session = BaseService.get_session(self)

        self.configure()

    def get_titles(self):
        res = self.session.get(
            url=self.config["endpoints"]["title"].format(
                type="movie" if self.movie else "show"
            ),
            params={"contentId": self.title},
        )

        try:
            title_info = res.json()["body"]["results"]["item"]
        except json.JSONDecodeError:
            raise MetadataNotAvailable(reason=res.text)

        if title_info["assetType"] == "MOVIE":
            tmdb_info = tmdb.info(
                content_name=title_info["title"],
                content_year=title_info["year"],
                type_="movie",
                cast=title_info.get("actors") or [],
            )

            titles = Title(
                id_=self.title,
                type_=Title.Types.MOVIE,
                name=tmdb_info.get("name") or title_info["title"],
                year=int(tmdb_info.get("year")[:4]) or title_info["year"],
                synopsis=tmdb_info.get("synopsis") or title_info["description"],
                original_lang=tmdb_info.get("original_language")
                or title_info["originalLanguage"]["iso3code"],
                tmdb_id=tmdb_info.get("tmdb_id") or None,
                imdb_id=tmdb_info.get("imdb_id") or None,
                thumbnail=tmdb_info.get("thumbnail") or None,
                source=self.ALIASES[0],
                service_data=title_info,
            )
        else:
            res = self.session.get(
                url=self.config["endpoints"]["episodes"],
                params={
                    "eid": title_info["id"],
                    "etid": "2",
                    "tao": "0",
                    "tas": "1000",
                },
            )

            try:
                episodes = res.json()["body"]["results"]["assets"]["items"]
            except json.JSONDecodeError:
                raise MetadataNotAvailable(reason=res.text)

            self.total_titles = (
                len(set([x["seasonNo"] for x in episodes])),
                len(episodes),
            )

            if args.dl.latest_episodes:
                latest_release_date = episodes[-1]["startDate"]
                episodes = [
                    x for x in episodes if x["startDate"] == latest_release_date
                ]
            elif args.dl.wanted:
                episodes = Tracks.get_wanted(
                    episodes,
                    season="seasonNo",
                    episode="episodeNo",
                )

            releaseYear = datetime.fromtimestamp(episodes[0]["startDate"]).year
            tmdb_info = tmdb.info(
                content_name=title_info["title"],
                content_year=releaseYear,
                type_="tv",
                cast=[],
            )

            for episode in episodes:
                titles = [
                    Title(
                        id_=self.title,
                        type_=Title.Types.TV,
                        name=tmdb_info.get("name") or title_info["title"],
                        year=int(tmdb_info.get("year")[:4]) or releaseYear,
                        season=episode["seasonNo"],
                        episode=episode["episodeNo"],
                        episode_name=episode["title"],
                        synopsis=tmdb_info.get("synopsis") or episode["description"],
                        original_lang=tmdb_info.get("original_language")
                        or title_info["originalLanguage"]["iso3code"]
                        if title_info.get("originalLanguage")
                        else title_info["langObjs"][0]["iso3code"],
                        tmdb_id=tmdb_info.get("tmdb_id") or None,
                        imdb_id=tmdb_info.get("imdb_id") or None,
                        tvdb_id=tmdb_info.get("tvdb_id") or None,
                        thumbnail=tmdb_info.get("thumbnail") or None,
                        source=self.ALIASES[0],
                        service_data=episode,
                    )
                    for episode in episodes
                ]

        return titles

    def get_tracks(self, title):
        res = self.session.get(
            url=self.config["endpoints"]["manifest"].format(
                id=title.service_data["contentId"]
            ),
            params={
                "desired-config": "|".join(
                    [
                        "audio_channel:dolby51",
                        "encryption:widevine",
                        "ladder:tv",
                        "package:dash",
                        "resolution:4k",
                        "subs-tag:HotstarPremium",
                        "video_codec:vp9",
                    ]
                ),
                "device-id": self.device_id,
                "os-name": "Android",
                "os-version": 8,
            },
        )

        try:
            playback_sets = res.json()["data"]["playBackSets"]
        except json.JSONDecodeError:
            raise ManifestNotAvailable(reason=res.text)

        # transform tagsCombination into `tags` key-value dictionary for easier usage
        playback_sets = [
            dict(
                **x,
                tags=dict(
                    y.split(":") for y in x["tagsCombination"].lower().split(";")
                ),
            )
            for x in playback_sets
        ]

        if not self.acodec:
            if any(x["tags"].get("audio_codec") == "ec3" for x in playback_sets):
                self.acodec = "ec3"
            elif any(x["tags"].get("audio_codec") == "ac3" for x in playback_sets):
                self.acodec = "ac3"
            elif any(x["tags"].get("audio_codec") == "aac" for x in playback_sets):
                self.acodec = "aac"
            else:
                self.acodec = playback_sets[0]["tags"].get("audio_codec")

        filtered_playback_sets = [
            x
            for x in playback_sets
            if (
                x["tags"].get("encryption") in ["widevine", "plain"]
                and x["tags"].get("package") == "dash"
                and x["tags"].get("container") == "fmp4"
                and x["tags"].get("ladder") == "tv"
                and x["tags"].get("resolution") in self.quality
                and x["tags"].get("video_codec") in self.vcodec
                and x["tags"].get("dynamic_range") in self.range
                and x["tags"].get("audio_codec") in [self.acodec, None]
            )
        ]

        for set in filtered_playback_sets.copy():
            if set["tags"]["resolution"] == "4k":
                try:
                    del filtered_playback_sets[
                        filtered_playback_sets.index(
                            [
                                x
                                for x in filtered_playback_sets
                                if x["tagsCombination"]
                                == set["tagsCombination"].replace("4k", "fhd")
                            ][0]
                        )
                    ]
                except IndexError:
                    pass

            if set["tags"]["audio_channel"] == "atmos":
                try:
                    del filtered_playback_sets[
                        filtered_playback_sets.index(
                            [
                                x
                                for x in filtered_playback_sets
                                if x["tagsCombination"]
                                == set["tagsCombination"].replace("atmos", "dolby51")
                            ][0]
                            or None
                        )
                    ]
                except IndexError:
                    pass

                try:
                    del filtered_playback_sets[
                        filtered_playback_sets.index(
                            [
                                x
                                for x in filtered_playback_sets
                                if x["tagsCombination"]
                                == set["tagsCombination"].replace("atmos", "stereo")
                            ][0]
                            or None
                        )
                    ]
                except IndexError:
                    pass

        for set in filtered_playback_sets.copy():
            if set["tags"]["audio_channel"] == "dolby51":
                try:
                    del filtered_playback_sets[
                        filtered_playback_sets.index(
                            [
                                x
                                for x in filtered_playback_sets
                                if x["tagsCombination"]
                                == set["tagsCombination"].replace("dolby51", "stereo")
                            ][0]
                            or None
                        )
                    ]
                except IndexError:
                    pass

        tracks = []
        for playback_set in filtered_playback_sets:
            mpd_tracks = Tracks.from_mpd(
                url=playback_set["playbackUrl"].replace(
                    ".hotstar.com", ".akamaized.net"
                ),
                session=self.session,
                lang=title.original_lang,
                source=self.ALIASES[0],
            )

            for track in mpd_tracks:
                if set["tags"]["encryption"] == "widevine":
                    track.license_url = playback_set["licenceUrl"]

            tracks += mpd_tracks

        tracks = Tracks(tracks)
        for track in tracks:
            if isinstance(track, VideoTrack) and "hdr10" in track.url[0]:
                track.hdr10 = True
                track.variables["range"] = "HDR10"

        return tracks

    def get_chapters(self, title):
        return []

    def certificate(self, **_):
        return None  # will use common privacy cert

    def license(self, challenge, track, **_):
        return self.session.post(
            url=track.license_url, data=challenge  # expects bytes
        ).content

    # Service specific functions

    def configure(self):
        self.session.headers.update(
            {
                "User-Agent": "Hotstar;in.startv.hotstar/3.3.0 (Android/8.1.0)",
                "Origin": "https://www.hotstar.com",
                "Referer": "https://www.hotstar.com/in",
                "X-Country-Code": "IN",
                "X-HS-AppVersion": "3.3.0",
                "X-Platform-Code": "PCTV",
                "X-HS-Platform": "firetv",
            }
        )
        self.device_id = self.session.cookies.get("device_id")
        self.userUP = self.session.cookies.get("userUP")
        self.hotstar_auth, self.hdntl = self.get_akamai()
        self.session.cookies.set("hdntl", self.hdntl)
        self.session.headers.update(
            {
                "X-HS-UserToken": self.get_token(),
                "hotstarauth": self.hotstar_auth,
            }
        )

        self.vcodec = ["h264"]
        if "HDR" in args.dl.range or args.dl.list == "ALL" or args.dl.quality > 1080:
            self.vcodec += ["h265"]
        if "DV" in args.dl.range or args.dl.list == "ALL":
            self.vcodec += ["dvh265"]

        self.acodec = args.dl.audio_codec.lower().replace("eac3", "ec3")

        self.quality = (
            ["fhd", "4k"]
            if args.dl.list == "ALL" or "+" in args.dl.range
            else ["4k"]
            if args.dl.quality > 1080
            else ["fhd"]
        )

        self.range = ["sdr"]
        if "+" in args.dl.range or args.dl.list == "ALL":
            self.range += ["hdr10", "dv"]
        elif "SDR" not in args.dl.range:
            self.range += [args.dl.range.lower()]

    @staticmethod
    def get_akamai():
        enc_key = b"\x05\xfc\x1a\x01\xca\xc9\x4b\xc4\x12\xfc\x53\x12\x07\x75\xf9\xee"
        st = int(time.time())
        exp = st + 6000
        res = f"st={st}~exp={exp}~acl=/*"
        res += "~hmac=" + hmac.new(enc_key, res.encode(), hashlib.sha256).hexdigest()
        res2 = f"exp={exp}~acl=/*"
        res2 += (
            "~data=hdntl~hmac="
            + hmac.new(enc_key, res.encode(), hashlib.sha256).hexdigest()
        )
        return res, res2

    def get_token(self):
        token_cache_path = self.get_cache(
            "token_{profile}.json".format(profile=self.profile)
        )
        if os.path.isfile(token_cache_path):
            with open(token_cache_path, encoding="utf-8") as fd:
                token = json.load(fd)
            if token.get("exp", 0) > int(time.time()):
                # not expired, lets use
                return token["uid"]
            # expired, refresh
            return self.save_token(self.refresh(), token_cache_path)
        # get new token
        return self.save_token(self.refresh(), token_cache_path)

    @staticmethod
    def save_token(token, to):
        # Decode the JWT data component
        tokens = json.loads(
            base64.b64decode(token.split(".")[1] + "===").decode("utf-8")
        )
        tokens["uid"] = token
        tokens["sub"] = json.loads(tokens["sub"])

        os.makedirs(os.path.dirname(to), exist_ok=True)
        with open(to, "w", encoding="utf-8") as fd:
            json.dump(tokens, fd)

        return token

    def refresh(self):
        try:
            return self.session.get(
                url=self.config["endpoints"]["refresh_token"],
                headers={
                    "hotstarauth": self.hotstar_auth,
                    "x-hs-platform": "web",
                    "x-hs-device-id": self.device_id,
                    "x-hs-usertoken": self.userUP,
                },
            ).json()["user_identity"]
        except Exception:
            raise TokenNotObtained(access_token=True)
