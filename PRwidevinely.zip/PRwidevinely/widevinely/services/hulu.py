from __future__ import annotations

import hashlib
from typing import Any

import click
from click import Context

from widevinely.objects import MenuTrack, TextTrack, Title, Track, Tracks
from widevinely.services.BaseService import BaseService
from widevinely.utils import is_close_match
from widevinely.utils.pyhulu import Device, HuluClient
from widevinely.utils.exceptions import *
from widevinely.utils import tmdb, logger
from widevinely.utils.globals import arguments

log = logger.getLogger("HULU")


class Hulu(BaseService):
    """
    Service code for the Hulu streaming service (https://hulu.com).

    \b
    Authorization: Cookies
    Security: UHD@L3
    """

    ALIASES = ["HULU"]

    TITLE_RE = (
        r"^(?:https?://(?:www\.)?hulu\.com/(?P<type>movie|series)/)?(?:[a-z0-9-]+-)?"
        r"(?P<id>[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})"
    )

    @staticmethod
    @click.command(name="Hulu", short_help="hulu.com")
    @click.argument("title", type=str)
    @click.option(
        "-m", "--movie", is_flag=True, default=False, help="Title is a Movie."
    )
    @click.pass_context
    def cli(ctx: Context, **kwargs: Any) -> Hulu:
        return Hulu(ctx, **kwargs)

    def __init__(self, ctx: Context, title, movie: bool):
        global args
        args = arguments()

        self.url = title
        m = self.parse_title(ctx, title)
        self.movie = movie or m.get("type") == "movie"
        super().__init__(ctx)

        self.session = BaseService.get_session(self)

        self.device: Device
        self.playback_params: dict = {}
        self.hulu_h264_client: HuluClient
        self.license_url: str

        self.configure()

    def get_titles(self):
        titles = []

        if self.movie:
            r = self.session.get(
                self.config["endpoints"]["movie"].format(id=self.title)
            ).json()
            if "message" in r:
                if r["message"] == "Unable to authenticate user":
                    log.exit(
                        " x Unable to authenticate user, are you sure the credentials are correct?"
                    )
            title_data = r["details"]["vod_items"]["focus"]["entity"]
            cast = [x["display_text"] for x in r["details"]["credits"][0]["items"]]

            tmdb_info = tmdb.info(
                content_name=title_data["name"],
                content_year=int(title_data["premiere_date"][:4]),
                type_="movie",
                cast=cast,
            )

            titles = [
                Title(
                    id_=self.title,
                    type_=Title.Types.MOVIE,
                    name=tmdb_info.get("name") or title_data["name"],
                    year=int(tmdb_info.get("year")[:4])
                    or int(title_data["premiere_date"][:4]),
                    synopsis=tmdb_info.get("synopsis") or title_data["description"],
                    original_lang=tmdb_info.get("original_language") or "en",
                    tmdb_id=tmdb_info.get("tmdb_id") or None,
                    imdb_id=tmdb_info.get("imdb_id") or None,
                    thumbnail=tmdb_info.get("thumbnail")
                    or None,  # TODO: Try to add the thumbnail
                    source=self.ALIASES[0],
                    service_data=title_data,
                )
            ]
        else:
            r = self.session.get(
                self.config["endpoints"]["series"].format(id=self.title)
            ).json()
            if r.get("code", 200) != 200:
                if "Invalid uuid for param 'entity_id'" in r["message"]:
                    if len("-".join(self.title.split("-")[-5:])) != 36:
                        missing_chars = 36 - len("-".join(self.title.split("-")[-5:]))
                        TitleNotAvailable
                        log.exit(
                            f"Content id '{'-'.join(self.title.split('-')[-5:])}' should have 36 characters.\nYou're missing {missing_chars} character(s). Please make sure you provide the complete link."
                        )
                    else:
                        TitleNotAvailable
                        log.exit(
                            f"We were unable to retrieve this title from HULU...\nAre you sure '{'-'.join(self.title.split('-')[-5:])}' is the right content id?"
                        )
                TitleNotAvailable
                log.exit(
                    f"Failed to get titles for {self.title}: {r['message']} [{r['code']}]"
                )

            season_data = next(
                (x for x in r["components"] if x["name"] == "Episodes"), None
            )
            if not season_data:
                TitleNotAvailable
                log.exit(
                    f"We were unable to retrieve the episodes of '{r['name']}'\nIt's most likely you need a '{r['details']['entity']['primary_branding']['name']}' add-on at HULU"
                )

            episode_count = 0
            for season in season_data["items"]:
                episode_count += season["pagination"]["total_count"]

            self.total_titles = (len(season_data["items"]), episode_count)

            if args.dl.latest_episodes:
                episodes = []
                episodes.extend(
                    self.session.get(
                        self.config["endpoints"]["season"].format(
                            id=self.title,
                            season=season_data["items"][-1]["id"].rsplit("::", 1)[1],
                        )
                    ).json()["items"]
                )
                latest_release_date = episodes[-1]["premiere_date"][:10]
                episodes = [
                    x
                    for x in episodes
                    if x["premiere_date"][:10] == latest_release_date
                ]
            elif args.dl.wanted:
                episodes = Tracks.get_wanted(
                    episodes, season="season", episode="number"
                )
            else:
                episodes = []
                for season in season_data["items"]:
                    episodes.extend(
                        self.session.get(
                            self.config["endpoints"]["season"].format(
                                id=self.title, season=season["id"].rsplit("::", 1)[1]
                            )
                        ).json()["items"]
                    )

            cast = [x["display_text"] for x in r["details"]["credits"][0]["items"]]

            tmdb_info = tmdb.info(
                content_name=r["details"]["entity"]["name"],
                content_year=int(r["details"]["entity"]["premiere_date"][:4]),
                type_="tv",
                cast=cast,
            )

            original_language = self.hulu_h264_client.load_playlist(
                episodes[0]["bundle"]["eab_id"]
            )["video_metadata"]["language"]

            for episode in episodes:
                titles = [
                    Title(
                        id_=episode["id"],
                        type_=Title.Types.TV,
                        name=tmdb_info.get("name") or r["details"]["entity"]["name"],
                        year=int(tmdb_info.get("year")[:4])
                        or int(r["details"]["entity"]["premiere_date"][:4]),
                        season=episode.get("season"),
                        episode=episode.get("number"),
                        synopsis=tmdb_info.get("synopsis")
                        or r["details"]["entity"]["description"],
                        episode_name=episode.get("name"),
                        original_lang=tmdb_info.get("original_language")
                        or original_language,
                        tmdb_id=tmdb_info.get("tmdb_id") or None,
                        imdb_id=tmdb_info.get("imdb_id") or None,
                        tvdb_id=tmdb_info.get("tvdb_id") or None,
                        thumbnail=tmdb_info.get("thumbnail")
                        or None,  # TODO: Try to add the thumbnail
                        source=self.ALIASES[0],
                        service_data=episode,
                    )
                    for episode in episodes
                ]

        return titles

    def get_tracks(self, title: Title, HDR_available=False) -> Tracks:
        if args.dl.video_codec == "H.264" and args.dl.range == "SDR":
            playlist = self.hulu_h264_client.load_playlist(
                title.service_data["bundle"]["eab_id"]
            )
            self.license_url = playlist["wv_server"]
            tracks = Tracks.from_mpd(
                url=playlist["stream_url"],
                lang=title.original_lang,
                source=self.ALIASES[0],
                session=self.session,
            )
        else:
            playlist = self.hulu_h265_client.load_playlist(
                title.service_data["bundle"]["eab_id"]
            )
            self.license_url = playlist["wv_server"]
            tracks = Tracks.from_mpd(
                url=playlist["stream_url"],
                lang=title.original_lang,
                source=self.ALIASES[0],
                session=self.session,
            )

        video_pssh = next(x.pssh for x in tracks.videos if x.pssh)

        for track in tracks.videos:
            if track.hdr10:
                """MPD only says HDR10+, but Hulu HDR streams are always
                Dolby Vision Profile 8 with HDR10+ compatibility"""
                HDR_available = True

        if not HDR_available:
            if args.dl.video_codec == "H.265" and args.dl.range != "SDR":
                playlist = self.hulu_h264_client.load_playlist(
                    title.service_data["bundle"]["eab_id"]
                )
                self.license_url = playlist["wv_server"]
                tracks = Tracks.from_mpd(
                    url=playlist["stream_url"],
                    lang=title.original_lang,
                    source=self.ALIASES[0],
                    session=self.session,
                )
            args.dl.range = "SDR"

        for track in tracks.audio:
            if not track.pssh:
                track.pssh = video_pssh

        subtitle_tracks = []
        for sub_lang, sub_url in playlist["transcripts_urls"]["webvtt"].items():
            subtitle_tracks += [
                TextTrack(
                    id_=hashlib.md5(sub_url.encode()).hexdigest()[0:6],
                    source=self.ALIASES[0],
                    url=sub_url,
                    # metadata
                    codec="vtt",
                    language=sub_lang,
                    is_original_lang=title.original_lang
                    and is_close_match(sub_lang, [title.original_lang]),
                    forced=False,  # TODO: find out if sub is forced
                )
            ]

        tracks.add(subtitle_tracks)

        for subtitle in tracks.subtitles:
            if subtitle.language.language == "en":
                subtitle.sdh = True  # TODO: don't assume SDH
            title.tracks.subtitles.append(subtitle)

        return tracks

    def get_chapters(self, title: Title) -> list[MenuTrack]:
        return []

    def certificate(self, **_: Any):
        return None  # will use common privacy cert

    def license(self, challenge: bytes, track: Track, **_: Any) -> bytes:
        return self.session.post(
            url=self.license_url, data=challenge  # expects bytes
        ).content

    # Service specific functions

    def configure(self):
        self.device = Device(
            device_code=self.config["device"]["FireTV4K"]["code"],
            device_key=self.config["device"]["FireTV4K"]["key"],
        )
        self.session.headers.update(
            {
                "User-Agent": self.config["user_agent"],
            }
        )
        self.h264_playback_params = {
            "all_cdn": False,
            "region": "US",
            "language": "en",
            "interface_version": "1.9.0",
            "network_mode": "wifi",
            "play_intent": "resume",
            "playback": {
                "version": 2,
                "video": {
                    "codecs": {
                        "values": [
                            x
                            for x in self.config["codecs"]["video"]
                            if x["type"] == "H264"
                        ],
                        "selection_mode": self.config["codecs"]["video_selection"],
                    }
                },
                "audio": {
                    "codecs": {
                        "values": self.config["codecs"]["audio"],
                        "selection_mode": self.config["codecs"]["audio_selection"],
                    }
                },
                "drm": {
                    "values": self.config["drm"]["schemas"],
                    "selection_mode": self.config["drm"]["selection_mode"],
                    "hdcp": self.config["drm"]["hdcp"],
                },
                "manifest": {
                    "type": "DASH",
                    "https": True,
                    "multiple_cdns": False,
                    "patch_updates": True,
                    "hulu_types": True,
                    "live_dai": True,
                    "secondary_audio": True,
                    "live_fragment_delay": 3,
                },
                "segments": {
                    "values": [
                        {
                            "type": "FMP4",
                            "encryption": {"mode": "CENC", "type": "CENC"},
                            "https": True,
                        }
                    ],
                    "selection_mode": "ONE",
                },
            },
        }

        self.h265_playback_params = {
            "all_cdn": False,
            "region": "US",
            "language": "en",
            "interface_version": "1.9.0",
            "network_mode": "wifi",
            "play_intent": "resume",
            "playback": {
                "version": 2,
                "video": {
                    "dynamic_range": "HDR10PLUS",
                    "codecs": {
                        "values": [
                            x
                            for x in self.config["codecs"]["video"]
                            if x["type"] == "H265"
                        ],
                        "selection_mode": self.config["codecs"]["video_selection"],
                    },
                },
                "audio": {
                    "codecs": {
                        "values": self.config["codecs"]["audio"],
                        "selection_mode": self.config["codecs"]["audio_selection"],
                    }
                },
                "drm": {
                    "multi_key": True,
                    "values": self.config["drm"]["schemas"],
                    "selection_mode": self.config["drm"]["selection_mode"],
                    "hdcp": self.config["drm"]["hdcp"],
                },
                "manifest": {
                    "type": "DASH",
                    "https": True,
                    "multiple_cdns": False,
                    "patch_updates": True,
                    "hulu_types": True,
                    "live_dai": True,
                    "secondary_audio": True,
                    "live_fragment_delay": 3,
                },
                "segments": {
                    "values": [
                        {
                            "type": "FMP4",
                            "encryption": {"mode": "CENC", "type": "CENC"},
                            "https": True,
                        }
                    ],
                    "selection_mode": "ONE",
                },
            },
        }
        self.hulu_h264_client = HuluClient(
            device=self.device,
            session=self.session,
            version=self.config["device"].get("device_version"),
            **self.h264_playback_params,
        )

        self.hulu_h265_client = HuluClient(
            device=self.device,
            session=self.session,
            version=self.config["device"].get("device_version"),
            **self.h265_playback_params,
        )
