import re

from widevinely.services.amazon import Amazon
from widevinely.services.apple import Apple
from widevinely.services.disneyplus import DisneyPlus
from widevinely.services.discoveryplus import DiscoveryPlus
from widevinely.services.googleplay import GooglePlay
from widevinely.services.hbomax import HBOMax
from widevinely.services.hotstar import Hotstar
from widevinely.services.hulu import Hulu
from widevinely.services.moviesanywhere import MoviesAnywhere
from widevinely.services.pcoksky import PcokSky
from widevinely.services.netflix import Netflix
from widevinely.services.nlziet import NLziet
from widevinely.services.paramountplus import ParamountPlus
from widevinely.services.pathethuis import PatheThuis
from widevinely.services.rakutentv import RakutenTV
from widevinely.services.streamz import Streamz
from widevinely.services.viaplay import Viaplay
from widevinely.services.videoland import Videoland
from widevinely.services.vtmgo import VTMGO
from widevinely.services.zee5 import ZEE5

from widevinely.utils import logger

log = logger.getLogger("services")

SERVICES = {
    "Amazon": Amazon.AMZN_ALIASES,
    "AppleTVPlus": Apple.ATVP_ALIASES[:-1],
    "DisneyPlus": DisneyPlus.ALIASES,
    "DiscoveryPlus": DiscoveryPlus.ALIASES,
    "GooglePlay": GooglePlay.ALIASES,
    "HBOMax": HBOMax.ALIASES,
    "Hotstar": Hotstar.ALIASES,
    "Hulu": Hulu.ALIASES,
    "iTunes": Apple.iT_ALIASES,
    "MoviesAnywhere": MoviesAnywhere.ALIASES,
    "PeacockTV": PcokSky.PCOK_ALIASES[:-1],
    "PrimeVideo": Amazon.PRIME_ALIASES,
    "Netflix": Netflix.ALIASES,
    "NLziet": NLziet.ALIASES,
    "ParamountPlus": ParamountPlus.ALIASES,
    "PatheThuis": PatheThuis.ALIASES,
    "RakutenTV": RakutenTV.ALIASES,
    "SkyShowtime": PcokSky.SKYS_ALIASES,
    "Streamz": Streamz.ALIASES,
    "Viaplay": Viaplay.ALIASES,
    "Videoland": Videoland.ALIASES,
    "VTMGO": VTMGO.ALIASES,
    "ZEE5": ZEE5.ALIASES,
}

SERVICE_MAP = {
    "Amazon": Amazon.AMZN_ALIASES + Amazon.PRIME_ALIASES,
    "Apple": Apple.ATVP_ALIASES + Apple.iT_ALIASES,
    "DisneyPlus": DisneyPlus.ALIASES,
    "DiscoveryPlus": DiscoveryPlus.ALIASES,
    "GooglePlay": GooglePlay.ALIASES,
    "HBOMax": HBOMax.ALIASES,
    "Hotstar": Hotstar.ALIASES,
    "Hulu": Hulu.ALIASES,
    "MoviesAnywhere": MoviesAnywhere.ALIASES,
    "PcokSky": PcokSky.PCOK_ALIASES + PcokSky.SKYS_ALIASES,
    "Netflix": Netflix.ALIASES,
    "NLziet": NLziet.ALIASES,
    "ParamountPlus": ParamountPlus.ALIASES,
    "PatheThuis": PatheThuis.ALIASES,
    "RakutenTV": RakutenTV.ALIASES,
    "Streamz": Streamz.ALIASES,
    "Viaplay": Viaplay.ALIASES,
    "Videoland": Videoland.ALIASES,
    "VTMGO": VTMGO.ALIASES,
    "ZEE5": ZEE5.ALIASES,
}

ZONE_MAP = {
    "Amazon": Amazon.ZONES,
    "DiscoveryPlus": DiscoveryPlus.ZONES,
    "Viaplay": Viaplay.ZONES,
}


def get_service_key(service: str, title: str) -> str:
    """
    Get the Service Key name (e.g. DisneyPlus, not dsnp, disney+, etc.) from the SERVICE_MAP.
    And also get zones and regions from the service, where available.
    Input service can be of any case-sensitivity and can be either the key itself or an alias.
    """
    service = service.lower()
    zone = None
    region = None
    for key, aliases in SERVICE_MAP.items():
        if service in map(str.lower, aliases) or service == key.lower():
            service = key
    for key in ZONE_MAP.items():
        default_zone = key[1][1]
        default_region = key[1][2]
        if service == key[0]:
            if "http" in title:
                title = re.search(key[1][0], title)
                if title:
                    if "zone" in title.re.groupindex:
                        zone = title.group("zone")
                    if "region" in title.re.groupindex:
                        region = title.group("region")
            zone = default_zone if not zone else zone
            region = default_region if not region else region
            return service, zone, region

    if service:
        return service, zone, region
    ValueError
    log.exit(f"Failed to find a matching Service and Zones/Regions for '{service}'")
