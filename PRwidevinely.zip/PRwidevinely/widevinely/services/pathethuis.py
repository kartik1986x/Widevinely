from __future__ import annotations

from typing import Any

import click
from click import Context
from langcodes import Language

from widevinely.utils import tmdb, logger
from widevinely.utils.globals import arguments
from widevinely.objects import Title, Tracks, VideoTrack, AudioTrack, TextTrack
from widevinely.services.BaseService import BaseService
from widevinely.utils.exceptions import *

log = logger.getLogger("PATHE")


class PatheThuis(BaseService):
    """
    Service code for Nederland's Pathe-Thuis. streaming service (https://www.pathe-thuis.nl/).

    Authorization: Cookies
    Security: UHD@-- FHD@L3, doesn't care about releases.

    """

    ALIASES = ["PATHE", "pathethuis", "pathe"]

    TITLE_RE = [
        r"^(?:https?://(?:www\.)?pathe-thuis\.nl/film/)?(?P<id>[0-9]+)?/[a-z0-9-]+"
    ]

    @staticmethod
    @click.command(name="PatheThuis", short_help="pathe-thuis.nl")
    @click.argument("title", type=str)
    @click.pass_context
    def cli(ctx: Context, **kwargs: Any) -> PatheThuis:
        return PatheThuis(ctx, **kwargs)

    def __init__(self, ctx, title):
        global args
        args = arguments()

        self.parse_title(ctx, title)
        super().__init__(ctx)

        self.ticket_id = None

        self.session = BaseService.get_session(self)

        self.session.headers = {
            "X-Pathe-Device-Identifier": "web-1",
            "X-Pathe-Auth-Session-Token": self.cookies._cookies["www.pathe-thuis.nl"][
                "/"
            ]["authenticationToken"].value,
            "X-XSRF-TOKEN": self.cookies._cookies["www.pathe-thuis.nl"]["/"][
                "XSRF-TOKEN"
            ].value,
        }

    def get_titles(self):
        metadata = self.session.get(
            url=f"https://www.pathe-thuis.nl/api/movies/{self.title}"
        ).json()

        if metadata.get("tickets"):
            self.ticket_id = [
                x["id"] for x in metadata["tickets"] if x["movieId"] == self.title
            ][0]

        cast = [x["name"] for x in metadata["crew"] if x["role"] == "actors"]
        content_details = tmdb.info(
            imdb_id=metadata.get("imdbId"),
            content_name=metadata["originalTitle"],
            content_year=metadata["year"],
            type_="movie",
            cast=cast,
        )

        title = Title(
            id_=self.title,
            type_=Title.Types.MOVIE,
            name=content_details.get("name")
            if metadata.get("imdbId")
            else metadata["originalTitle"],
            year=int(content_details.get("year")[:4])
            if metadata.get("imdbId")
            else metadata["year"],
            synopsis=content_details.get("synopsis") or metadata["intro"],
            original_lang=content_details.get("original_language")
            or metadata["language"],
            tmdb_id=content_details.get("tmdb_id") or None,
            imdb_id=content_details.get("imdb_id") or metadata.get("imdbId"),
            thumbnail=content_details.get("thumbnail")
            or metadata["thumb"].replace("_[format]", "292x414"),
            source=self.ALIASES[0],
            service_data=metadata,
        )

        return title

    def get_tracks(self, title):
        if not self.ticket_id:
            raise NotEntitled

        manifest = self.session.get(
            url=f"https://www.pathe-thuis.nl/api/tickets/{self.ticket_id}",
            params={"drmType": "dash-widevine"},  # Otherwise it will return PlayReady
        ).json()

        self.license_url = manifest["stream"]["rawData"]["licenseserver"]
        self.license_token = manifest["stream"]["rawData"]["token"]

        tracks = Tracks.from_mpd(
            url=manifest["stream"]["url"],
            lang=title.original_lang,
            source=self.ALIASES[0],
            session=self.session,
        )

        for track in tracks:
            if isinstance(track, AudioTrack) and not track.channels:
                if track.codec == "mp4a":
                    track.channels = "2.0"
                else:
                    track.channels = "5.1"
            if isinstance(track, TextTrack):
                if type(track.url) == list and track.url[0].endswith("dash"):
                    track.url = [
                        x["url"]
                        for x in manifest["stream"]["subtitles"]
                        if x["language"] == track.language.language
                    ][0]

        return tracks

    def get_chapters(self, title):
        return []

    def certificate(self, **kwargs):
        # TODO: Hardcode the certificate
        return self.license(**kwargs)

    def license(self, challenge, **_):
        return self.session.post(
            url=self.license_url,
            params={"custom_data": self.license_token},
            data=challenge,  # expects bytes
        ).content
