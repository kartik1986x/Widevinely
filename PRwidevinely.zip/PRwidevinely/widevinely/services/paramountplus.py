from __future__ import annotations

import re
import json
import click
import urllib.parse
import itertools

from datetime import datetime

from widevinely.objects import Title, Tracks, VideoTrack, AudioTrack, TextTrack
from widevinely.services.BaseService import BaseService
from widevinely.utils.xml import load_xml
from widevinely.utils import tmdb, logger
from widevinely.utils.globals import arguments
from widevinely.utils.exceptions import *

log = logger.getLogger("PMTP")


class ParamountPlus(BaseService):
    """
    Service code for Paramount's Paramount+ streaming service (https://paramountplus.com).

    Authorization: Cookies
    Security:
        - L3: >= 2160p

        The library of contents can be viewed without logging in at https://paramountplus.com/shows/
        See the footer for links to movies, news, etc. A US IP is required to view.
    """

    ALIASES = ["PMTP", "paramountplus", "paramount+"]
    TITLE_RE = [
        r"^(?:https?://(?:www\.)?paramountplus\.com/movies/[a-z0-9-]+/)?(?P<id>\w+)",
        r"^(?P<id>\d+)$",
    ]

    @staticmethod
    @click.command(name="ParamountPlus", short_help="paramountplus.com")
    @click.argument("title", type=str)
    @click.option(
        "-m", "--movie", is_flag=True, default=False, help="Title is a Movie."
    )
    @click.pass_context
    def cli(ctx, **kwargs) -> ParamountPlus:
        return ParamountPlus(ctx, **kwargs)

    def __init__(self, ctx, title, movie):
        global args
        args = arguments()

        super().__init__(ctx)

        self.session = BaseService.get_session(self)
        self.movie = (
            movie or "movies" in title or "http" not in title and not title.isdigit()
        )

        self.url = title
        self.parse_title(ctx, title)
        if "shows" in title:
            self.title = self.parse_show_id(title)
            self.movie = False

        self.shorts = False

        self.configure()

    def get_titles(self, seasons=[], episodes=[]):
        if self.movie:
            res = self.session.get(
                self.config["endpoints"]["movie"].format(title_id=self.title),
                params={
                    "includeTrailerInfo": "true",
                    "includeContentInfo": "true",
                    "locale": "en-us",
                    "at": "ABBBye7409f2yP+sJyziMaOLgwl1Q9ZiRsT+hbp3El42FI4dQwcgQ1LPZAJ9nbk21co=",
                },
            ).json()

            if not res["success"]:
                raise MetadataNotAvailable(reason=res["message"])

            title_info = res["movie"]["movieContent"]
            title_year = int(
                title_info["_airDateISO"][:4]
                if title_info.get("_airDateISO")
                else self.parse_movie_year(self.url)
            )

            tmdb_info = tmdb.info(
                content_name=title_info["title"],
                content_year=title_year,
                type_="movie",
            )

            titles = Title(
                id_=title_info["contentId"],
                type_=Title.Types.MOVIE,
                name=tmdb_info.get("name") or title_info["title"],
                year=int(tmdb_info.get("year")[:4]) or title_year,
                synopsis=tmdb_info.get("synopsis") or title_info["description"],
                original_lang=tmdb_info.get("original_language")
                or "en",  # TODO: Check if ParamountPlus has language data in the API.
                tmdb_id=tmdb_info.get("tmdb_id") or None,
                imdb_id=tmdb_info.get("imdb_id") or None,
                thumbnail=tmdb_info.get("thumbnail")
                or sorted(title_info["thumbnailSet"], key=lambda x: x["height"])[0][
                    "url"
                ],
                source=self.ALIASES[0],
                service_data=title_info,
            )
        else:
            show_info = self.session.get(
                self.config["endpoints"]["tv"].format(title_id=self.title),
            ).json()

            if not show_info["success"]:
                raise MetadataNotAvailable(reason=show_info["message"])

            if not show_info["numFound"]:
                res = self.session.get(
                    self.config["endpoints"]["xhr_tv"].format(title_id=self.title),
                ).json()
                show_name = (
                    "shows/" + res["show"]["results"][0]["link"].split("shows/")[-1]
                )

                for page in itertools.count():
                    res = self.session.get(
                        self.config["endpoints"]["xhr_episodes"].format(
                            show_name=show_name, page=page
                        )
                    ).json()
                    if not res.get("success"):
                        return
                    episodes = res["result"]["data"]
                    break

                self.total_titles = (
                    len(set([ep["season_number"] for ep in episodes])),
                    len(episodes),
                )

            if not episodes:
                if any(
                    x["title"] == "Shorts" for x in show_info["videoSectionMetadata"]
                ):
                    self.shorts = True

                section = next(
                    (
                        x["sectionId"]
                        for x in show_info["videoSectionMetadata"]
                        if x["title"] in ["Full Episodes", "Shorts"]
                    ),
                    None,
                )

                seasons = sorted(
                    self.session.get(
                        url=self.config["endpoints"]["seasons"].format(
                            title_id=self.title
                        )
                    ).json()["video_available_season"]["itemList"],
                    key=lambda x: int(x["seasonNum"]),
                )

                episode_count = 0
                for season in seasons:
                    episode_count += season["totalCount"]

                if not seasons:
                    episode_count = len(
                        show_info["results"][0]["sectionItems"]["itemList"]
                    )
                    seasons = [{"seasonNum": 1, "totalCount": episode_count}]

                self.total_titles = (
                    len(seasons),
                    episode_count,
                )

                for season in seasons:
                    if isinstance(season, list):
                        episodes += [
                            show_info["results"][0]["sectionItems"]["itemList"]
                        ]
                        continue

                    if args.dl.wanted and int(season["seasonNum"]) != 1:
                        if any(
                            f"{int(x.split('x')[0]):02d}"
                            == f"{int(season['seasonNum']):02d}"
                            for x in args.dl.wanted
                        ):
                            continue

                    season_info = self.session.get(
                        self.config["endpoints"]["section"].format(id=section),
                        params={
                            "rows": "999",
                            "params": "seasonNum={}".format(season["seasonNum"]),
                            "begin": "0",
                            "seasonNum": season["seasonNum"],
                            "locale": "en-us",
                            "at": "ABAr70Wu/HYgv50oSxE3J6D7xM51jDdrOQGojDf+g9uKxQ9jzg7NffJhL+CEgem/fcY=",
                        },
                    ).json()

                    if not season_info["success"]:
                        raise MetadataNotAvailable(reason=season_info["message"])

                    episodes += season_info["sectionItems"]["itemList"]

            if not episodes:
                raise MetadataNotAvailable(reason="No episodes returned.")

            release_year = (
                datetime.strptime(seasons[0]["seasonPremiereDate"][:8], "%m/%d/%y").year
                if seasons
                and int(seasons[0]["seasonNum"]) == 1
                and seasons[0].get("seasonPremiereDate")
                else datetime.strptime(
                    episodes[0].get("airdate") or episodes[0]["_airDate"][:8],
                    "%m/%d/%y",
                ).year
                if int(
                    episodes[0].get("seasonNum")
                    or episodes[0].get("season_number")
                    or 0
                )
                == 1
                and int(
                    episodes[0].get("episodeNum")
                    or episodes[0].get("episode_number")
                    or 0
                )
                == 1
                else None
            )

            if args.dl.latest_episodes:
                latest_release_date = datetime.strftime(
                    datetime.strptime(episodes[-1]["_airDate"][:8], "%m/%d/%y"),
                    "%Y-%m-%d",
                )
                episodes = [
                    x
                    for x in episodes
                    if datetime.strftime(
                        datetime.strptime(x["_airDate"][:8], "%m/%d/%y"), "%Y-%m-%d"
                    )
                    == latest_release_date
                ]
            elif args.dl.wanted:
                episodes = Tracks.get_wanted(
                    episodes, season="seasonNum", episode="episodeNum"
                )

            tmdb_info = tmdb.info(
                content_name=episodes[0].get("seriesTitle")
                or episodes[0].get("series_title"),
                content_year=release_year,
                type_="tv",
            )

            for episode in episodes:
                titles = [
                    Title(
                        id_=episode.get("contentId") or episode.get("content_id"),
                        type_=Title.Types.TV,
                        name=tmdb_info.get("name")
                        or episode.get("seriesTitle")
                        or episode.get("series_title"),
                        year=int(tmdb_info.get("year")[:4]) or release_year,
                        season=episode.get("seasonNum") or episode.get("season_number"),
                        episode=episode.get("episodeNum")
                        or episode.get("episode_number"),
                        episode_name=episode.get("label"),
                        synopsis=tmdb_info.get("synopsis") or episode["description"],
                        original_lang=tmdb_info.get("original_language")
                        or "en",  # TODO: Check if ParamountPlus has language data in the API.
                        tmdb_id=tmdb_info.get("tmdb_id") or None,
                        imdb_id=tmdb_info.get("imdb_id") or None,
                        tvdb_id=tmdb_info.get("tvdb_id") or None,
                        thumbnail=episode["thumbnail"] or tmdb_info.get("thumbnail"),
                        source=self.ALIASES[0],
                        service_data=episode,
                    )
                    for episode in episodes
                ]

        return titles

    def get_tracks(self, title, assets=[], tracks=Tracks()):
        for device in ("desktop", "androidphone"):
            video_items = self.session.get(
                url=self.config["endpoints"]["video_items"].format(
                    device=device,
                    content_id=title.service_data.get("contentId")
                    or title.service_data.get("content_id"),
                ),
                params={
                    "locale": "en-us",
                    "at": "ABCXgPuoStiPipsK0OHVXIVh68zNys+G4f7nW9R6qH68GDOcneW6Kg89cJXGfiQCsj0=",
                },
            ).json()

            for item in video_items["itemList"]:
                if item.get("pid") and not any(
                    x.get("pid") == item.get("pid") for x in assets
                ):
                    assets += [item]
                elif not any(x["assetType"] == item["assetType"] for x in assets):
                    assets += [item]

        for asset in assets:
            if asset["assetType"].startswith("HLS") or asset["assetType"].endswith(
                "PRECON"
            ):
                continue

            if (
                args.dl.range == "SDR"
                and "HDR" in asset["assetType"]
                and args.dl.list != "ALL"
            ):
                continue

            if asset["assetType"] == "DASH_CENC_HDR":
                # DASH_CENC_HDR has some decryption and general download problems (kid and size mismatch errors).
                # DASH_CENC_HDR10 seems to be the same, even same bitrate and file size, so use that.
                continue

            res = self.session.get(
                url=self.config["endpoints"]["link_platform"].format(
                    content_id=title.id
                ),
                params={
                    "assetTypes": asset["assetType"],
                    "formats": "MPEG-DASH",
                    "format": "SMIL",
                },
            )

            if "Geographic Restriction" in res.text:
                raise VPN_PROXY_DETECTED

            meta = load_xml(res.text).find("body").find("seq")
            meta = meta.findall("switch")
            if not meta:
                continue

            meta = sorted(
                meta, key=lambda t: int(t.find("video").get("system-bitrate"))
            )[-1]

            if meta.find("video").get("src").lower().endswith(".m3u8"):
                continue  # probably a free access clear key protected manifest

            mpd_tracks = Tracks.from_mpd(
                url=meta.find("video").get("src"),
                lang=title.original_lang,
                source=self.ALIASES[0],
                session=self.session,
            )

            if not mpd_tracks:
                continue

            for track in mpd_tracks:
                track.id = track.id + asset["assetType"]
                track.variables["assetType"] = asset["assetType"]
                if isinstance(track, VideoTrack):
                    track.hdr10 = (
                        track.codec[:4] in ("hvc1", "hev1")
                        and track.extra[0].attrib.get("codecs")[5] == "2"
                    )
                    track.hdr10plus = (
                        track.codec[:4] in ("hvc1", "hev1") and "HDR10plus" in track.url
                    )
                    track.dv = track.codec[:4] in ("dvh1", "dvhe")

                if isinstance(track, VideoTrack) or isinstance(track, AudioTrack):
                    if self.shorts:
                        track.encrypted = False

                if isinstance(track, TextTrack):
                    track.codec = "vtt"
                    if track.language.language == "en":
                        track.sdh = True  # TODO: don't assume SDH

            tracks.add(mpd_tracks)

        return tracks

    def get_chapters(self, title):
        return []

    def certificate(self, **_):
        return self.config["certificate"]

    def license(self, challenge, title, **_):
        bearer_path = title.service_data.get("url") or title.service_data.get("href")
        if not bearer_path:
            raise TokenNotObtained(access_token=True)

        r = self.session.post(
            url=self.config["endpoints"]["license"],
            params={
                "CrmId": "cbsi",
                "AccountId": "cbsi",
                "SubContentType": "Default",
                "ContentId": title.service_data.get("contentId")
                or title.service_data.get("content_id"),
            },
            headers={"Authorization": f"Bearer {self.get_auth_bearer(bearer_path)}"},
            data=challenge,  # expects bytes
        )

        if r.headers["Content-Type"].startswith("application/json"):
            res = r.json()
            raise FailedLicensing(reason=res["message"])

        return r.content

    def configure(self):
        self.session.headers.update(
            {
                "Accept-Language": "en-US,en;q=0.5",
                "Origin": "https://www.paramountplus.com",
            }
        )

        self.session.params = {
            "begin": "0",
            "rows": "9999",
            "locale": "en-us",
            "platformType": "apps",
            "at": "ABB8PNPZ6DFZVBGYeQAKF72Ok/Vsy00GFYa0biVKwjJSfZL7gy0kGuQZbLowk3sSE+U=",
        }

        if not self.is_logged_in():
            raise InvalidCookies

        if not self.is_subscribed():
            raise NotEntitled

    # Service specific functions

    def get_prop(self, prop):
        res = self.session.get("https://www.paramountplus.com")
        prop_re = prop.replace(".", r"\.")
        search = re.search(rf"{prop_re} ?= ?[\"']?([^\"';]+)", res.text)
        if not search:
            raise InvalidCookies

        return search.group(1)

    def is_logged_in(self):
        return self.get_prop("CBS.UserAuthStatus") == "true"

    def is_subscribed(self):
        return self.get_prop("CBS.Registry.user.sub_status") == "SUBSCRIBER"

    def get_auth_bearer(self, path) -> str:
        r = self.session.get(
            urllib.parse.urljoin("https://www.paramountplus.com", path)
        )
        match = re.search(r'"Authorization": ?"Bearer ([^\"]+)', r.text)
        if not match:
            if not path.endswith("/*"):
                # Hack to get video player page when the API returns a wrong path
                return self.get_auth_bearer(re.sub(r"/[^/]+$", "/*", path))
            else:
                raise TokenNotObtained(access_token=True)

        return match.group(1)

    def parse_movie_year(self, url):
        html_raw = self.session.get(url)

        if html_raw.status_code != 200:
            return None

        self.year = int(
            re.findall('"movie__air-year">[0-9]+<', html_raw.text)[0]
            .replace('"movie__air-year">', "")
            .replace("<", "")
        )

    def parse_show_id(self, url):
        html_raw = self.session.get(url)

        if html_raw.status_code != 200:
            log.exit("Could not parse Show Id.")

        show = json.loads(
            '{"'
            + re.search('CBS.Registry.Show = {"(.*)"}', html_raw.text).group(1)
            + '"}'
        )

        return str(show["id"])
