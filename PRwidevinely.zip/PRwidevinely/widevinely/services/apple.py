from __future__ import annotations

import base64
import json
import re
import httpx
import click
import m3u8

from enum import Enum
from datetime import datetime
from typing import Any, Optional
from urllib.parse import unquote
from googlesearch import Search as google
from click import Context

from widevinely.objects import (
    AudioTrack,
    MenuTrack,
    TextTrack,
    Title,
    Tracks,
)
from widevinely.services.BaseService import BaseService
from widevinely.utils.collections import as_list
from widevinely.utils.exceptions import *
from widevinely.utils.globals import cdm as cdm_
from widevinely.utils.globals import arguments
from widevinely.utils import tmdb, logger

log = logger.getLogger("APPLE")


class Apple(BaseService):
    """
    Service code for Apple's iTunes and TV Plus streaming services (https://itunes.apple.com, https://tv.apple.com).

    Authorization: Cookies
    Security:
        - L1: >= 720p
        - L3: <= 576p & Audio

    KID format 00000000XXXXYYYY6336202020202020
     -    6330 - SD SDR
     -    6331 - FHD SDR
     -    6332 - UHD SDR
     -    6333 - SD HDR10+DV
     -    6334 - FHD HDR10+DV
     -    6335 - UHD HDR10+DV
     -    6336 - Audio
    """

    ATVP_ALIASES = ["ATVP", "appletvplus", "appletv+", "Apple"]
    iT_ALIASES = ["iT", "itunes"]

    TITLE_RE = [
        r"^(?:https?://tv\.apple\.com(?:/[a-z]{2})?/(?:movie|show|episode)/[a-z0-9-]+/)?(?P<id>umc\.cmc\.[a-z0-9]+)",
        r"https://itunes\.apple\.com/.+/(?P<id>id\d+)(?:/.+?)?",
    ]

    @staticmethod
    @click.command(name="Apple", short_help="itunes.apple.com, tv.apple.com")
    @click.argument("title", type=str)
    @click.option(
        "-sf",
        "--storefront",
        "--override-storefront",
        type=str,
        default=None,
        help="iTunes Storefront to use. 2-letter code languages allowed."
        "Defaults to StorefrontId from provided account.",
    )
    @click.option(
        "-fa",
        "--force-appletv",
        is_flag=True,
        default=False,
        help="If title is available on both AppleTVPlus and iTunes, force AppleTVPlus title.",
    )
    @click.option(
        "-fi",
        "--force-itunes",
        is_flag=True,
        default=False,
        help="If title is available on both AppleTVPlus and iTunes, force iTunes title.",
    )
    @click.pass_context
    def cli(ctx: Context, **kwargs: Any) -> Apple:
        return Apple(ctx, **kwargs)

    def __init__(self, ctx, title, storefront, force_appletv, force_itunes):
        from widevinely.commands.dl import get_cookie_jar

        global args, cdm
        args = arguments(service=ctx.params)
        cdm = cdm_().cdm

        if cdm.security_level == 3 and not args.dl.cache and not args.dl.audio_only:
            log.exit(
                f"{args.dl.quality}p tracks cannot be decrypted with an L3 Cdm."
                "\nUse argument '--cache' if you want to disable the use of the Cdm"
                "\nand only retrieve decryption keys from the provided Key Vaults."
            )

        self.title_url = title
        self.parse_title(ctx, title)

        super().__init__(ctx)

        self.cookies = get_cookie_jar("Apple", "appletvplus")
        if not self.cookies:
            self.cookies = get_cookie_jar("Apple", "apple")
            if not self.cookies:
                self.cookies = get_cookie_jar("Apple", "itunes")
                if not self.cookies:
                    log.exit("Could not find cookies for Apple, AppleTVPlus or iTunes.")

        self.session = BaseService.get_session(self, delay_proxy=True)

        self.assets = None
        self.override_storefront = storefront
        self.force_appletv = force_appletv
        self.force_itunes = force_itunes

        self.configure()

        ctx.parent.obj.profile = self.service

    def get_titles(self):
        title_information = self.title_info["content"]

        cast = title_information["rolesSummary"].get("cast") or []
        if cast:
            cast = [
                x.replace("\xa0", " ")
                for x in title_information["rolesSummary"]["cast"]
            ]

        if title_information["type"] == "Movie":
            tmdb_info = tmdb.info(
                content_name=title_information["title"],
                content_year=datetime.utcfromtimestamp(
                    title_information["releaseDate"] / 1000
                ).year,
                type_="movie",
                cast=cast,
            )

            movie_thumb = (
                title_information["images"]["posterArt"]["url"]
                .replace("{w}", str(title_information["images"]["posterArt"]["width"]))
                .replace("{h}", str(title_information["images"]["posterArt"]["height"]))
                .replace("{f}", "png")
            )

            title_information["assets"] = (
                sorted(self.assets, key=lambda k: k.get("size", 0))
                if self.assets
                else None
            )

            try:
                title_information["adamId"] = self.title_info["playables"][
                    list(self.title_info["playables"].keys())[0]
                ]["assets"]["assetAdamId"]
            except KeyError:
                # Not available if NotEntitled
                pass

            titles = Title(
                id_=self.title,
                type_=Title.Types.MOVIE,
                name=tmdb_info.get("name") or title_information["title"],
                year=int(tmdb_info.get("year")[:4])
                or datetime.utcfromtimestamp(
                    title_information["releaseDate"] / 1000
                ).year,
                synopsis=tmdb_info.get("synopsis") or title_information["description"],
                original_lang=tmdb_info.get("original_language")
                or title_information["originalSpokenLanguages"][0]["locale"],
                tmdb_id=tmdb_info.get("tmdb_id") or None,
                imdb_id=tmdb_info.get("imdb_id") or None,
                thumbnail=tmdb_info.get("thumbnail") or movie_thumb,
                source=self.ALIASES[0],
                service_data=title_information,
            )
        else:
            r = self.session.get(
                url=self.config["endpoints"]["episodes"].format(id=self.title),
                params=dict(
                    **self.config["device"],
                    **{
                        "sf": "143441",
                        "includeSeasonSummary": "false",
                        "selectedSeasonEpisodesOnly": "false",
                    },
                ),
            )
            try:
                episode_titles = r.json()["data"]
            except json.JSONDecodeError:
                ValueError
                log.exit(f"Failed to load episodes list: {r.text}")

            episodes = r.json()["data"]["episodes"]
            for episode in r.json()["data"]["episodes"]:
                playableId = episode_titles["episodesPlayables"][episode["id"]][0][
                    "playableId"
                ]
                if not episode_titles["playables"][playableId]["isEntitledToPlay"]:
                    del episodes[episodes.index(episode)]

            self.total_titles = (
                len(set([x["seasonNumber"] for x in episodes])),
                len(episodes),
            )

            if args.dl.latest_episodes:
                latest_release_date = episodes[-1]["releaseDate"]
                episodes = [
                    x for x in episodes if x["releaseDate"] == latest_release_date
                ]
            elif args.dl.wanted:
                episodes = Tracks.get_wanted(
                    episodes, season="seasonNumber", episode="episodeNumber"
                )

            tmdb_info = tmdb.info(
                content_name=title_information["title"],
                content_year=datetime.utcfromtimestamp(
                    title_information["releaseDate"] / 1000
                ).year,
                type_="tv",
                cast=cast,
            )
            for episode in episodes:
                episode["adamId"] = episode_titles["playables"][
                    episode_titles["episodesPlayables"][episode["id"]][0]["playableId"]
                ]["videoAssetId"]

                episode_thumb = (
                    episode["images"]["contentImage"]["url"]
                    .replace("{w}", str(episode["images"]["contentImage"]["width"]))
                    .replace("{h}", str(episode["images"]["contentImage"]["height"]))
                    .replace("{f}", "png")
                )
                titles = [
                    Title(
                        id_=episode["id"],
                        type_=Title.Types.TV,
                        name=tmdb_info.get("name") or title_information["title"],
                        year=int(tmdb_info.get("year")[:4])
                        or datetime.utcfromtimestamp(
                            title_information["releaseDate"] / 1000
                        ).year,
                        season=episode["seasonNumber"],
                        episode=episode["episodeNumber"],
                        episode_name=episode.get("title"),
                        synopsis=tmdb_info.get("synopsis")
                        or title_information["description"],
                        original_lang=tmdb_info.get("original_language")
                        or title_information["originalSpokenLanguages"][0]["locale"],
                        tmdb_id=tmdb_info.get("tmdb_id") or None,
                        imdb_id=tmdb_info.get("imdb_id") or None,
                        tvdb_id=tmdb_info.get("tvdb_id") or None,
                        thumbnail=episode_thumb or tmdb_info.get("thumbnail"),
                        source=self.ALIASES[0],
                        service_data=episode,
                    )
                    for episode in episodes
                ]

        return titles

    def get_tracks(self, title):
        if self.isItunes:
            if title.service_data["assets"][-1]["kind"] == "preorder":
                raise TitleIsPreorder(region=True)

            r = self.session.get(
                re.sub(
                    r"aec=[A-Z]D", "aec=UHD", title.service_data["assets"][-1]["hlsUrl"]
                )
            )
            res = r.text
        else:
            res = self.session.get(
                url=self.config["endpoints"]["manifest"].format(
                    id=title.service_data["id"]
                ),
                params=dict(
                    **self.config["device"],
                    **{"sf": "143441"},
                ),
            )

            try:
                stream_data = res.json()["data"]["content"]["playables"][0]
            except json.JSONDecodeError:
                ValueError
                log.exit(f"Failed to load stream data: {res.text}")

            r = self.session.get(stream_data["assets"]["hlsUrl"])
            res = r.text

        tracks = Tracks.from_m3u8(
            master=m3u8.loads(res, str(r.url)),
            lang=title.original_lang,
            source=self.ALIASES[0],
        )

        for track in tracks.videos:
            codecs = track.extra.stream_info.codecs.split(",")
            for codec in codecs:
                if codec[0:4] == "avc1":
                    track.codec = codec
                elif codec[0:4] in ("hvc1", "hev1"):
                    track.codec = codec
                elif codec[0:4] == "dvh1":
                    track.codec = codec

            track.hdr10 = (
                track.codec[0:4] in ("hvc1", "hev1")
                and track.codec[5] == "2"
                and track.extra.stream_info.video_range == "PQ"
            )
            track.dv = track.codec[0:4] in ("dvh1", "dvhe")

            if track.codec[0:4] in ("hvc1", "hev1") and not track.hdr10:
                track.codec = track.codec.replace("hvc1", "hevc").replace(
                    "hev1", "hevc"
                )

        for track in tracks:
            if isinstance(track, AudioTrack):
                track.encrypted = True
                if self.isItunes:
                    bitrate = re.search(r"(?:_gr|&g=)(\d+.)", track.extra.uri)[1]
                    bitrate = re.sub(r'[-\/:*@,._%?"<>|]', "", bitrate)
                    track.bitrate = (
                        int((bitrate[1:] if len(bitrate) == 4 else bitrate)) * 1000
                    )
                else:
                    bitrate = re.search(r"&g=(\d+?)&", track.extra.uri)
                    if bitrate:
                        track.bitrate = int(bitrate[1][-3::]) * 1000

                if "stereo" in track.extra.group_id:
                    track.codec = "aac"
                elif "ac3" in track.extra.group_id:
                    track.codec = "ac3"
                elif "ec3" in track.extra.group_id or "atmos" in track.extra.group_id:
                    track.codec = "ec3"
            if isinstance(track, TextTrack):
                track.codec = "vtt"

        tracks.subtitles = [x for x in tracks.subtitles]

        for track in tracks:
            track.codec = track.codec[:4]

        return Tracks(
            [
                # multiple CDNs, only want one unless it's a TextTrack
                x
                for x in tracks
                if (
                    any(
                        cdn in as_list(x.url)[0].split("?")[1].split("&")
                        for cdn in ["cdn=ak", "cdn=vod-ak-aoc.tv.apple.com"]
                    )
                    if "?" in x.url
                    else "ak-amt" in x.url
                )
                or isinstance(x, TextTrack)
            ]
        )

    def get_chapters(self, title: Title) -> list[MenuTrack]:
        return []

    def certificate(self, **_: Any) -> None:
        return self.config["certificate"]

    def license(self, challenge, title, track, **_):
        data = {
            "streaming-request": {
                "version": 1,
                "streaming-keys": [
                    {
                        "id": 1,
                        "uri": f"data:text/plain;base64,{track.pssh_b64}",
                        "challenge": base64.b64encode(challenge).decode(),
                        "key-system": "com.widevine.alpha",
                        "lease-action": "start",
                    }
                ],
            }
        }

        if not self.isItunes:
            data["streaming-request"]["streaming-keys"][0].update(
                {
                    "adamId": title.service_data["adamId"],
                    "isExternal": "true",
                    "svcId": self.serviceId,
                }
            )

        if getattr(self, "rental_id", None):
            data["streaming-request"]["streaming-keys"][0]["rental-id"] = self.rental_id

        r = self.session.post(url=self.config["endpoints"]["license"], json=data)

        if r.is_error:
            log.exit(
                f" - License request failed. HTTP Error {r.status_code}: {r.reason}"
            )

        res = r.json()
        status = res["streaming-response"]["streaming-keys"][0]["status"]
        if status != ResponseCode.OK.value:
            # log.info_(res, debug=True)
            try:
                desc = ResponseCode(status).name
            except ValueError:
                desc = "UNKNOWN"
            if desc == "INSUFFICIENT_SECURITY":
                raise CdmNotCapable(capability="576p")
            log.exit(f" - License request failed. Error: {status} ({desc})")
        return res["streaming-response"]["streaming-keys"][0]["license"]

    # Service specific functions

    def configure(self) -> None:
        self.environment = self.get_environment_config()
        if not self.environment:
            ValueError
            log.exit("Failed to get Apple's WEB TV App Environment Configuration")

        self.update_headers()

        if not self.title.startswith("umc."):
            self.get_atv_url()

        if self.override_storefront:
            self.storefrontId = self.get_storefrontId()

        self.title_info = self.get_info()
        for playable_ in self.title_info["playables"].items():
            if playable_[1]["isItunes"] and not self.force_appletv:
                playable = playable_[1]
                break
            elif (
                "Apple TV Plus" in playable_[1]["serviceName"] and not self.force_itunes
            ):
                playable = playable_[1]
                break

        self.isItunes = playable["isItunes"]
        if not self.isItunes:
            self.serviceId = playable_[1]["vpafMetrics"]["serviceId"]

        self.get_service()

        if not playable["isEntitledToPlay"]:
            self.storefrontId = self.get_storefrontId()
            self.title_info = self.get_info()
            for playable_ in self.title_info["playables"].items():
                if playable_[1]["isItunes"] and not self.force_appletv:
                    playable = playable_[1]
                    break
                elif (
                    "Apple TV Plus" in playable_[1]["serviceName"]
                    and not self.force_itunes
                ):
                    playable = playable_[1]
                    break

            if (
                not playable["isEntitledToPlay"]
                and not args.dl.list
                and not args.dl.cache
                and not args.dl.audio_only
                and not args.dl.subs_only
            ):
                if not any(
                    playable_[1]["isEntitledToPlay"]
                    for playable_ in self.title_info["playables"].items()
                ):
                    raise NotEntitled
                else:
                    playable = [
                        playable_[1]
                        for playable_ in self.title_info["playables"].items()
                        if playable_[1]["isEntitledToPlay"]
                    ][0]

        if self.isItunes:
            personalizedOffers = playable["itunesMediaApiData"].get(
                "personalizedOffers"
            )
            if personalizedOffers:
                self.rental_id = personalizedOffers[0].get("rentalId")

            self.assets = [x for x in playable["itunesMediaApiData"]["offers"]]
            self.title = f'id{playable["itunesMediaApiData"]["id"]}'

    def get_environment_config(self) -> Optional[dict]:
        """Loads environment config data from WEB App's <meta> tag."""
        res = self.session.get("https://tv.apple.com").text
        env = re.search(r'web-tv-app/config/environment"[\s\S]*?content="([^"]+)', res)
        if not env:
            return None
        return json.loads(unquote(env[1]))

    def update_headers(self):
        try:
            media_user_token = self.session.cookies.get("media-user-token")
        except httpx.CookieConflict:
            media_user_token = self.cookies._cookies[".tv.apple.com"]["/"][
                "media-user-token"
            ].value

        self.session.headers.update(
            {
                "User-Agent": self.config["user_agent"],
                "Authorization": f"Bearer {self.environment['MEDIA_API']['token']}",
                "media-user-token": media_user_token,
                "x-apple-music-user-token": media_user_token,
            }
        )

    def get_atv_url(self):
        for search in (
            "appletv" + self.title_url,
            self.title_url,
            "google:" + self.title_url,
        ):
            try:
                self.title_url = (
                    google(
                        re.sub(
                            r"id[0-9]*",
                            "",
                            search.replace("itunes.apple.com", "tv.apple.com"),
                        )
                    )
                    .results[0]
                    .url
                )
            except Exception:
                pass

            if self.title_url.startswith("https://tv.apple.com"):
                break

        if self.title_url.startswith("https://itunes.apple.com"):
            log.exit("Could not find ATV url for this title.")

        self.title = self.title_url.split("/")[-1]

    def get_info(self):
        for i in range(2):
            res = self.session.get(
                url=self.config["endpoints"]["title"].format(
                    type={0: "shows", 1: "movies"}[i], id=self.title
                ),
                params=dict(
                    **self.config["device"],
                    **{
                        "sf": 143441
                        if not getattr(self, "storefrontId", None)
                        else self.storefrontId
                    },
                ),
            )
            if res.status_code != 404:
                return res.json()["data"]
        log.exit(f"Provided contentID {self.title!r} could not be found.")

    def get_service(self):
        from widevinely.commands.dl import get_cookie_jar, set_service_args

        self.cookies = None
        self.session.cookies = None
        self.cookies = get_cookie_jar("Apple", "apple")
        if not self.cookies:
            if self.isItunes:
                self.cookies = get_cookie_jar("Apple", "itunes")
                if not self.cookies:
                    log.exit(
                        "Title is from iTunes but could not find cookies for this service"
                    )
            else:
                self.cookies = get_cookie_jar("Apple", "appletvplus")
                if not self.cookies:
                    log.exit(
                        "Title is from AppleTVPlus but could not find cookies for this service"
                    )

        self.service = "iTunes" if self.isItunes else "AppleTVPlus"
        set_service_args(service=self.service)
        self.session = BaseService.get_session(self)

        self.profile = self.service
        self.ALIASES = self.iT_ALIASES if self.isItunes else self.ATVP_ALIASES
        self.cli.name = self.service
        self.update_headers()

    def get_storefrontId(self):
        if self.override_storefront:
            for mapping in httpx.get(url=self.config["storefrontmappings"]).json():
                if mapping["code"] == self.override_storefront.upper():
                    return mapping["storefrontId"]
            log.exit(f"Could not find StorefrontId for {self.override_storefront!r}.")

        return (
            self.session.get(url=self.config["endpoints"]["account"])
            .json()
            .get("storeFrontId")
            or None
        )


class ResponseCode(Enum):
    OK = 0
    INVALID_PSSH = -1001
    NOT_OWNED = -1002  # Title not owned in the requested quality
    INSUFFICIENT_SECURITY = -1021  # L1 Cdm required or the Cdm used is revoked
