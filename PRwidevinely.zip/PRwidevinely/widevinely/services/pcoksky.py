from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import time
from datetime import datetime
from requests.exceptions import HTTPError

import click

from widevinely.objects import Title, Tracks
from widevinely.services.BaseService import BaseService
from widevinely.utils import tmdb, logger
from widevinely.utils.globals import arguments
from widevinely.utils.exceptions import *

log = logger.getLogger("PcokSky")


class PcokSky(BaseService):
    """
    Service code for NBC's PeacockTV and Sky's SkyShowtime streaming services (https://peacocktv.com, https://skyshowtime.com).

    \b
    Authorization: Cookies
    Security:
        - L3: <= 2160p

    PeacockTV can be accessed with an US IP or from a few European countries.

    SkyShowtime has recently been launched to a few European countries
    and will be expanded in the upcoming months.
    \b
    """

    PCOK_ALIASES = ["PCOK", "peacock", "peacocktv", "PcokSky"]
    SKYS_ALIASES = ["SKYS", "skyshowtime"]

    TITLE_RE = [
        r"(?:https?://(?:www\.)?(?P<service>(peacocktv|skyshowtime))\.com/watch/asset/|/?)(?P<id>(movies|tv)/[a-z0-9/-]+/[a-f0-9-]+)",
    ]

    @staticmethod
    @click.command(name="PcokSky", short_help="peacocktv.com, skyshowtime.com")
    @click.argument("title", type=str, required=False)
    @click.pass_context
    def cli(ctx, **kwargs):
        return PcokSky(ctx, **kwargs)

    def __init__(self, ctx, title):
        from widevinely.commands.dl import get_cookie_jar, set_service_args

        global args
        args = arguments()

        super().__init__(ctx)
        m = self.parse_title(ctx, title)
        self.movie = "movies" in m.get("id")
        self.service = m.get("service")

        self.pcoktv = self.service == "peacocktv"
        ctx.obj.profile = self.service
        self.profile = self.service
        self.cli.name = "PeacockTV" if self.pcoktv else "SkyShowtime"
        set_service_args(service=self.service)

        self.session = BaseService.get_session(self)
        self.cookies = get_cookie_jar(
            "pcoksky",
            "peacocktv"
            if self.pcoktv
            else f"skyshowtime_{self.session.ipinfo['country'].lower()}",
        )
        self.session.cookies.update(cookies=self.cookies)
        self.idsession = self.session.cookies.get(
            domain=f".{self.service}.com", path="/", name="idsession"
        )

        self.client = "pcok_client" if self.pcoktv else "skys_client"

        self.configure()

    def get_titles(self, seasons=[], episodes=[]):
        if not self.title.startswith("/"):
            self.title = f"/{self.title}"

        metadata = self.session.get(
            url=self.config["endpoints"]["node"].format(service=self.service),
            params={"slug": self.title, "represent": "(items(items))"},
            headers=dict(
                **self.sky_headers,
                **{
                    "Accept": "*",
                    "Referer": f"https://www.{self.service}.com/watch/asset{self.title}",
                },
            ),
        ).json()

        if "errorCode" in metadata:
            raise MetadataNotAvailable(
                reason=f"{metadata['description']} [{metadata['errorCode']}]"
            )

        cast = metadata["attributes"].get("cast")

        if self.movie:
            tmdb_info = tmdb.info(
                content_name=metadata["attributes"]["title"],
                content_year=metadata["attributes"]["year"],
                type_="movie",
                cast=cast,
            )

            titles = Title(
                id_=metadata["id"],
                type_=Title.Types.MOVIE,
                name=tmdb_info.get("name") or metadata["attributes"]["title"],
                year=int(tmdb_info.get("year")[:4]) or metadata["attributes"]["year"],
                synopsis=tmdb_info.get("synopsis")
                or metadata["attributes"]["synopsisLong"],
                original_lang=tmdb_info.get("original_language")
                or "en",  # TODO: Check if service has language data in the API.
                tmdb_id=tmdb_info.get("tmdb_id") or None,
                imdb_id=tmdb_info.get("imdb_id") or None,
                thumbnail=tmdb_info.get("thumbnail") or None,
                source=self.PCOK_ALIASES[0] if self.pcoktv else self.SKYS_ALIASES[0],
                service_data=metadata,
            )
        else:
            for season in metadata["relationships"]["items"]["data"]:
                for episode in season["relationships"]["items"]["data"]:
                    episodes.append(episode)

            self.total_titles = (
                len(metadata["relationships"]["items"]["data"]),
                len(episodes),
            )

            if args.dl.latest_episodes:
                episodes = [
                    episodes[-1]
                ]  # TODO: find a way to determine the latest episode(s)
            elif args.dl.wanted:
                for episode in episodes:
                    episode["seasonNumber"] = episode["attributes"]["seasonNumber"]
                    episode["episodeNumber"] = episode["attributes"]["episodeNumber"]

                episodes = Tracks.get_wanted(
                    episodes,
                    season="seasonNumber",
                    episode="episodeNumber",
                )

            tmdb_info = tmdb.info(
                content_name=metadata["attributes"]["title"],
                content_year=0,
                type_="tv",
                cast=cast,
            )

            for episode in episodes:
                titles = [
                    Title(
                        id_=episode["id"],
                        type_=Title.Types.TV,
                        name=tmdb_info.get("name") or metadata["attributes"]["title"],
                        year=int(tmdb_info.get("year")[:4]) or 0,
                        season=episode["attributes"]["seasonNumber"],
                        episode=episode["attributes"]["episodeNumber"],
                        episode_name=episode["attributes"]["episodeName"],
                        synopsis=tmdb_info.get("synopsis")
                        or metadata["attributes"]["synopsisLong"],
                        original_lang=tmdb_info.get("original_language")
                        or "en",  # TODO: Check if service has language data in the API.
                        tmdb_id=tmdb_info.get("tmdb_id") or None,
                        imdb_id=tmdb_info.get("imdb_id") or None,
                        tvdb_id=tmdb_info.get("tvdb_id") or None,
                        thumbnail=episode["attributes"]["images"][0]["url"]
                        or tmdb_info.get("thumbnail"),
                        source=self.PCOK_ALIASES[0]
                        if self.pcoktv
                        else self.SKYS_ALIASES[0],
                        service_data=episode,
                    )
                    for episode in episodes
                ]

        return titles

    def get_tracks(self, title):
        content_id = title.service_data["attributes"]["formats"]["HD"]["contentId"]
        variant_id = title.service_data["attributes"]["providerVariantId"]

        manifest_sky_headers = {
            # order of these matter!
            "X-SkyOTT-PinOverride": "false",
            "X-SkyOTT-Provider": self.config[self.client]["provider"],
            "X-SkyOTT-Territory": self.session.ipinfo["country"].upper(),
            "X-SkyOTT-UserToken": self.tokens["userToken"],
        }

        tracks = []
        for vcodec in ("H264", "H265"):
            body = json.dumps(
                {
                    "device": {
                        # maybe get these from the config endpoint?
                        "capabilities": [
                            {
                                "protection": "WIDEVINE",
                                "container": "ISOBMFF",
                                "transport": "DASH",
                                "acodec": "EAC3",
                                "vcodec": vcodec,
                            },
                            {
                                "protection": "WIDEVINE",
                                "container": "ISOBMFF",
                                "transport": "DASH",
                                "acodec": "AAC",
                                "vcodec": vcodec,
                            },
                        ],
                        "maxVideoFormat": "UHD",
                        "model": self.config["device"]["platform"],
                        "hdcpEnabled": "true",
                    },
                    "client": {"thirdParties": ["FREEWHEEL", "YOSPACE"]},  # CONVIVA
                    "contentId": content_id,
                    "providerVariantId": variant_id,
                    "parentalControlPin": "null",
                    "personaParentalControlRating": "9",
                },
                separators=(",", ":"),
            )

            manifest = self.session.post(
                url=self.config["endpoints"]["vod"].format(service=self.service),
                data=body,
                headers=dict(
                    **manifest_sky_headers,
                    **{
                        "Accept": "application/vnd.playvod.v1+json",
                        "Content-Type": "application/vnd.playvod.v1+json",
                        "X-Sky-Signature": self.create_signature_header(
                            method="POST",
                            path="/video/playouts/vod",
                            sky_headers=manifest_sky_headers,
                            body=body,
                            timestamp=int(time.time()),
                        ),
                    },
                ),
            ).json()

            if "errorCode" in manifest:
                if "No assets found" in manifest["description"]:
                    continue
                raise ManifestNotAvailable(
                    reason=f"{manifest['description']} [{manifest['errorCode']}]"
                )

            mpd_tracks = Tracks.from_mpd(
                url=manifest["asset"]["endpoints"][0]["url"]
                + "&audio=all&subtitle=all&forcedNarrative=true",
                lang=title.original_lang,
                source=self.PCOK_ALIASES[0] if self.pcoktv else self.SKYS_ALIASES[0],
                session=self.session,
            )

            for track in mpd_tracks:
                if track.encrypted:
                    track.license_token = manifest["protection"]["licenceToken"]

            tracks += mpd_tracks

        tracks = Tracks(tracks)

        for track in tracks.videos:
            track.language = title.original_lang

        for track in tracks.audio:
            if track.language.territory == "AD":
                # This is supposed to be Audio Description, not Andorra
                track.language.territory = None

        return tracks

    def get_chapters(self, title):
        return []

    def certificate(self, **_):
        return self.config["pcok_certificate" if self.pcoktv else "skys_certificate"]

    def license(self, challenge, track, **_):
        return self.session.post(
            url=self.config["endpoints"]["license"].format(service=self.service),
            params={"bt": track.license_token},
            headers={
                "Accept": "*",
                "X-Sky-Signature": self.create_signature_header(
                    method="POST",
                    path="/drm/widevine/acquirelicense",
                    sky_headers={},
                    body="",
                    timestamp=int(time.time()),
                ),
            },
            data=challenge,  # expects bytes
        ).content

    # Service specific functions

    def configure(self):
        self.sky_headers = {
            # Order of these matters!
            "X-SkyOTT-Device": self.config["device"]["device"],
            "X-SkyOTT-Language": "en",
            "X-SkyOTT-Platform": self.config["device"]["platform"],
            "X-SkyOTT-Proposition": self.config[self.client]["proposition"],
            "X-SkyOTT-Provider": self.config[self.client]["provider"],
            "X-SkyOTT-Territory": self.session.ipinfo["country"].upper(),
        }

        self.session.headers.update(
            {"Origin": "https://www.{service}.com".format(service=self.service)}
        )
        self.hmac_key = bytes(
            self.config["security"][
                f"{'pcok' if self.pcoktv else 'skys'}_signature_hmac_key_v4"
            ],
            "utf-8",
        )
        self.tokens = self.get_tokens()
        if not self.verify_tokens():
            raise InvalidCookies

        self.sky_headers.update({"X-SkyOTT-Language": self.tokens["displayLanguage"]})

    @staticmethod
    def calculate_sky_header_md5(headers):
        if len(headers.items()) > 0:
            headers_str = (
                "\n".join(f"{x[0].lower()}: {x[1]}" for x in headers.items()) + "\n"
            )
        else:
            headers_str = "{}"
        return str(hashlib.md5(headers_str.encode()).hexdigest())

    @staticmethod
    def calculate_body_md5(body):
        return str(hashlib.md5(body.encode()).hexdigest())

    def calculate_signature(self, msg):
        digest = hmac.new(self.hmac_key, bytes(msg, "utf-8"), hashlib.sha1).digest()
        return str(base64.b64encode(digest), "utf-8")

    def create_signature_header(self, method, path, sky_headers, body, timestamp):
        data = (
            "\n".join(
                [
                    method.upper(),
                    path,
                    "",  # important!
                    self.config[self.client]["client_sdk"],
                    "1.0",
                    self.calculate_sky_header_md5(sky_headers),
                    str(timestamp),
                    self.calculate_body_md5(body),
                ]
            )
            + "\n"
        )

        signature_hmac = self.calculate_signature(data)

        return self.config["security"]["signature_format"].format(
            client=self.config[self.client]["client_sdk"],
            signature=signature_hmac,
            timestamp=timestamp,
        )

    def get_tokens(self):
        # Try to get cached tokens
        tokens_cache_path = self.get_cache(
            "tokens_{profile}_{country}.json".format(
                profile=self.profile, country=self.session.ipinfo["country"].lower()
            )
        )
        if os.path.isfile(tokens_cache_path):
            with open(tokens_cache_path, encoding="utf-8") as fd:
                tokens = json.load(fd)
            tokens_expiration = tokens.get("tokenExpiryTime", None)
            if (
                tokens_expiration
                and datetime.strptime(tokens_expiration, "%Y-%m-%dT%H:%M:%S.%fZ")
                > datetime.now()
            ):
                return tokens

        # Call personas endpoint to get the accounts personaId
        personas = self.session.post(
            url=self.config["endpoints"]["personas"].format(service=self.service),
            cookies={"idsession": self.idsession},
            headers=dict(**self.sky_headers, **self.session.headers),
        ).json()

        try:
            persona = personas["personas"][0]["id"]
            displayLanguage = personas["personas"][0]["displayLanguage"]
        except KeyError:
            raise InvalidCookies

        # Craft the body data that will be sent to the tokens endpoint, being minified and order matters!
        body = json.dumps(
            {
                "auth": {
                    "authScheme": self.config["device"]["auth_scheme"],
                    "authIssuer": self.config["device"]["auth_issuer"],
                    "provider": self.config[self.client]["provider"],
                    "providerTerritory": self.session.ipinfo["country"].upper(),
                    "proposition": self.config[self.client]["proposition"],
                    "personaId": persona,
                },
                "device": {
                    "type": self.config["device"]["device"],
                    "platform": self.config["device"]["platform"],
                    "id": self.config["device"]["id"],
                    "drmDeviceId": self.config["device"]["drm_device_id"],
                },
            },
            separators=(",", ":"),
        )

        # Get the tokens
        tokens = self.session.post(
            url=self.config["endpoints"]["tokens"].format(service=self.service),
            cookies={"idsession": self.idsession},
            headers=dict(
                **self.sky_headers,
                **{
                    "Accept": "application/vnd.tokens.v1+json",
                    "Content-Type": "application/vnd.tokens.v1+json",
                    "X-Sky-Signature": self.create_signature_header(
                        method="POST",
                        path="/auth/tokens",
                        sky_headers=self.sky_headers,
                        body=body,
                        timestamp=int(time.time()),
                    ),
                },
            ),
            data=body,
        ).json()

        if "errorCode" in tokens:
            raise TokenNotObtained(reason=tokens["description"])

        tokens["displayLanguage"] = displayLanguage

        os.makedirs(os.path.dirname(tokens_cache_path), exist_ok=True)
        with open(tokens_cache_path, "w", encoding="utf-8") as fd:
            json.dump(tokens, fd)

        return tokens

    def verify_tokens(self):
        try:
            self.session.get(
                url=self.config["endpoints"]["me"].format(service=self.service),
                headers=dict(
                    **self.sky_headers,
                    **{
                        "Accept": "application/vnd.userinfo.v2+json",
                        "Content-Type": "application/vnd.userinfo.v2+json",
                        "X-Sky-Signature": self.create_signature_header(
                            method="GET",
                            path="/auth/users/me",
                            sky_headers=self.sky_headers,
                            body="",
                            timestamp=int(time.time()),
                        ),
                    },
                ),
            )
        except HTTPError:
            return False
        else:
            return True
