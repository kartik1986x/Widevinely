from __future__ import annotations

import json
import time
import re
import hashlib
from typing import Any
from urllib.parse import urlparse

import click
from click import Context

from widevinely.objects import (
    VideoTrack,
    AudioTrack,
    TextTrack,
    MenuTrack,
    Title,
    Tracks,
)
from widevinely.services.BaseService import BaseService
from widevinely.utils import tmdb, logger
from widevinely.utils.globals import arguments
from widevinely.utils.exceptions import *

log = logger.getLogger("HMAX")


class HBOMax(BaseService):
    """
    Service code for HBO's HBO MAX streaming service (https://hbomax.com).

    \b
    Authorization: Credentials
    Security:
        - L1: >= 1080p
        - L3: <= 720p

    \b
    Tips: The library of contents can be viewed without logging in at https://play.hbomax.com

    """

    ALIASES = ["HMAX", "hbomax"]

    TITLE_RE = r"^(?:https?://(?:www\.|play\.)?hbomax\.com/[a-z]+/)?(?:urn:hbo:[a-z]+:)?(?P<id>[a-zA-Z0-9-_]+)"

    @staticmethod
    @click.command(name="HBOMax", short_help="play.hbomax.com")
    @click.argument("title", type=str)
    @click.option(
        "-m", "--movie", is_flag=True, default=False, help="Title is a Movie."
    )
    @click.pass_context
    def cli(ctx: Context, **kwargs: Any) -> HBOMax:
        return HBOMax(ctx, **kwargs)

    def __init__(self, ctx, title, movie):
        global args
        args = arguments()

        super().__init__(ctx)

        self.session = BaseService.get_session(self)

        self.movie = True if "feature" in title else movie
        self.collection = None
        self.url = title
        self.title_page = urlparse(title).path.split("/")[-1]
        self.parse_title(ctx, title)

        self.license_api: str
        self.auth_grant: dict
        self.client_grant: dict

        self.configure()

    def get_titles(self, episodes=[]):
        res = self.session.get(
            url=self.config["endpoints"]["manifest"].format(title_id=self.title),
            params=self.express_params,
            headers={
                "Authorization": f"{self.auth_grant['token_type']} {self.auth_grant['access_token']}"
            },
        )

        try:
            data = res.json()
        except json.JSONDecodeError:
            raise MetadataNotAvailable

        if "message" in str(data) and len(data) == 1:
            raise MetadataNotAvailable(reason=data["message"])

        if self.movie:
            titles = []
            for movie in self.collection if self.collection else [self.title]:
                self.references = self.get_references(movie.split(":")[-1])
                if movie == self.title or movie == self.collection[0]:
                    title_info = self.movie_reference
                else:
                    title_info = self.get_metadata(id=movie)

                cast = (
                    [x["person"] for x in title_info["credits"]["cast"]]
                    if title_info["credits"].get("cast")
                    else []
                )

                tmdb_info = tmdb.info(
                    content_name=title_info["titles"]["full"],
                    content_year=title_info["releaseYear"],
                    type_="movie",
                    cast=cast,
                )

                movie_thumb = (
                    title_info["images"]["tile"]
                    .replace("{{size}}", "400x600")
                    .replace("{{compression}}", "low")
                    .replace("{{protection}}", "false")
                    .replace("{{scaleDownToFit}}", "false")
                )

                title_info["references"] = self.references["references"]

                titles += [
                    Title(
                        id_=movie,
                        type_=Title.Types.MOVIE,
                        name=tmdb_info.get("name") or title_info["titles"]["full"],
                        year=int(tmdb_info.get("year")[:4])
                        or title_info["releaseYear"],
                        synopsis=tmdb_info.get("synopsis")
                        or title_info["summaries"]["full"],
                        original_lang=self.references["originalAudioLanguage"],
                        tmdb_id=tmdb_info.get("tmdb_id") or None,
                        imdb_id=tmdb_info.get("imdb_id") or None,
                        thumbnail=tmdb_info.get("thumbnail") or movie_thumb,
                        source=self.ALIASES[0],
                        service_data=title_info,
                    )
                ]
        else:
            title_info = [x for x in data if "urn:hbo:series" in x["id"]][0]["body"]
            episodes = [x for x in data if "urn:hbo:episode" in x["id"]]
            for episode in episodes:
                episodes[episodes.index(episode)] = episode["body"]
            
            if len(episodes) == 1 and not episodes[0].get("seasonNumber"):
                episodes[0]["seasonNumber"] = 1

            cast = (
                [x["person"] for x in episodes[0]["credits"]["cast"]]
                if episodes[0]["credits"].get("cast")
                else []
            )

            tmdb_info = tmdb.info(
                content_name=title_info["titles"]["full"],
                content_year=episodes[0]["releaseYear"],
                type_="tv",
                cast=cast,
            )

            self.total_titles = (
                len(set([x["seasonNumber"] for x in episodes])),
                len(episodes),
            )

            if args.dl.latest_episodes:
                latest_release_date = str(episodes[-1]["firstOfferedDate"])[:10]
                episodes = [
                    x
                    for x in episodes
                    if str(x["firstOfferedDate"])[:10] == latest_release_date
                ]
            elif args.dl.wanted:
                episodes = Tracks.get_wanted(
                    episodes,
                    season="seasonNumber",
                    episode="numberInSeason",
                )

            for episode in episodes:
                titles = [
                    Title(
                        id_=f"urn:hbo:episode:{episode['playbackMarkerId']}",
                        type_=Title.Types.TV,
                        name=tmdb_info.get("name") or title_info["titles"]["full"],
                        year=int(tmdb_info.get("year")[:4])
                        or episodes[0]["releaseYear"],
                        season=episode.get("seasonNumber"),
                        episode=episode.get("numberInSeason")
                        or episode.get("numberInSeries"),
                        episode_name=episode["titles"]["full"],
                        synopsis=tmdb_info.get("synopsis")
                        or title_info["summaries"]["full"],
                        original_lang=self.references["originalAudioLanguage"],
                        tmdb_id=tmdb_info.get("tmdb_id") or None,
                        imdb_id=tmdb_info.get("imdb_id") or None,
                        tvdb_id=tmdb_info.get("tvdb_id") or None,
                        thumbnail=episode["images"]["tile"]
                        .replace("{{size}}", "1920x1080")
                        .replace("{{compression}}", "low")
                        .replace("{{protection}}", "false")
                        .replace("{{scaleDownToFit}}", "false")
                        or tmdb_info.get("thumbnail"),
                        source=self.ALIASES[0],
                        service_data=episode,
                    )
                    for episode in episodes
                ]

        return titles

    def get_tracks(self, title):
        self.references = self.get_references(title.id.split(":")[-1])
        self.manifest = self.session.post(
            url=self.config["endpoints"]["content"],
            json=[
                {
                    "id": self.references["references"]["video"],
                    "headers": {
                        "x-hbo-device-model": self.session.headers["User-Agent"],
                        "x-hbo-download-quality": "HIGHEST",
                        "x-hbo-device-code-override": "DESKTOP",
                        "x-hbo-video-encodes": f"{args.dl.video_codec}|DASH|WDV",
                        "x-hbo-video-features": "server-stitched-playlist,mlp",
                    },
                }
            ],
            headers={
                "Authorization": f"{self.auth_grant['token_type']} {self.auth_grant['access_token']}"
            },
        ).json()[0]["body"]

        if "videos" not in self.manifest:
            if "content_brand_restricted" in self.manifest["code"]:
                raise NotEntitled
            else:
                raise ManifestNotAvailable

        self.license_api = self.manifest["drm"]["licenseUrl"]

        tracks = Tracks.from_mpd(
            url=self.manifest["fallbackManifest"].replace("_fallback", ""),
            lang=title.original_lang,
            source=self.ALIASES[0],
            session=self.session,
        )

        # The language from the AudioTracks is considered as original
        # if there's no AudioTrack with the original language provided available
        # and all AudioTracks have the same language
        if (
            not any(a.is_original_lang for a in tracks.audio)
            and len(set([x.language for x in tracks.audio])) == 1
        ):
            for track in tracks:
                if isinstance(track, VideoTrack) or isinstance(track, AudioTrack):
                    track.language = title.original_lang
                    track.is_original_lang = True

        # HMAX sometimes provide the right OriginalLanguage but tracks languages are wrong
        # Assume first track is the right track and will give them the proper language tags
        if not any(a.is_original_lang for a in tracks.audio):
            for track in tracks:
                if isinstance(track, VideoTrack) or isinstance(track, AudioTrack):
                    if track.language == tracks.audio[0].language:
                        track.language = title.original_lang
                        track.is_original_lang = True

        for track in tracks:
            if isinstance(track, VideoTrack):
                codec = track.extra[0].get("codecs")
                track.hdr10 = codec[0:4] in ("hvc1", "hev1") and codec[5] == "2"
                track.dv = codec[0:4] in ("dvh1", "dvhe")
            if isinstance(track, TextTrack):
                if not track.codec:
                    if "vtt" in track.url or "vtt" in track.url[0]:
                        track.codec = "webvtt"
                    else:
                        track.codec = "ttml"
                if type(track.url) == list:
                    track_lang_codec = track.language._str_tag
                    if track.sdh:
                        track_lang_codec += "_sdh"
                    elif track.forced:
                        track_lang_codec += "_forced"
                    else:
                        track_lang_codec += "_sub"
                    track.url = re.sub(
                        r"/t/t[0-9]/[0-9].vtt",
                        f"/t/sub/{track_lang_codec}.vtt",
                        track.url[0],
                    )

        return tracks

    def get_chapters(self, title: Title) -> list[MenuTrack]:
        return []

    def certificate(self, **_: Any):
        return self.config["certificate"]

    def license(self, challenge: bytes, **_: Any) -> bytes:
        return self.session.post(
            url=self.license_api,
            params={"keygen": "playready", "drmKeyVersion": "2"},
            headers={
                "Authorization": f"{self.auth_grant['token_type']} {self.auth_grant['access_token']}"
            },
            data=challenge,  # expects bytes
        ).content

    # Service specific functions

    def configure(self):
        self.session.headers.update(
            {
                "Accept": "application/vnd.hbo.v9.full+json",
                "X-Hbo-Client-Version": self.config["client"]["desktop"]["version"],
                "X-Hbo-Device-Name": self.config["device"]["name"],
                "X-Hbo-Device-Os-Version": self.config["device"]["os_version"],
            }
        )

        if not self.title.startswith("urn:"):
            self.title = f"urn:hbo:{'feature' if self.movie else 'series'}:{self.title}"
        self.title_id = self.title.split(":")[-1]

        self.auth_grant = self.get_auth_grant()
        self.references = self.get_references(self.title_id, main=True)

        self.express_params = {
            "device-code": self.config["device"]["name"],
            "product-code": "hboMax",
            "brand": "HBO MAX",
            "navigation-channels": "HBO MAX SUBSCRIPTION|HBO MAX FREE",
            "upsell-channels": "HBO MAX SUBSCRIPTION|HBO MAX FREE",
            "playback-channels": "HBO MAX SUBSCRIPTION|HBO MAX FREE",
            "api-version": "v9",
            "country-code": self.session.ipinfo["country"].upper(),
            "profile-type": "default",
            "territory": "HBO MAX DOMESTIC"
            if self.session.ipinfo["country"].upper() == "US"
            else self.get_region(),
            "language": self.references["originalAudioLanguage"],
            "client-version": self.config["client"]["desktop"]["client_version"],
            "signed-in": True,
            "content-space": "hboMaxSvodExperience",
        }

    def get_metadata(self, id):
        return self.session.post(
            url=self.config["endpoints"]["content"],
            json=[{"id": id if "id" not in id else id.replace("series", "collection")}],
            headers={
                "Authorization": f"{self.auth_grant['token_type']} {self.auth_grant['access_token']}"
            },
        ).json()[0]["body"]

    def get_references(self, id_, main=False, collection_first_title=False):
        if not self.movie:
            episodes = self.get_metadata(id=self.title)
            if episodes.get("message"):
                raise MetadataNotAvailable(reason=episodes["message"])

            if episodes["references"].get("items"):
                self.movie = True
                self.title = self.title.replace("series", "collection")
                self.collection_title = episodes["titles"]["full"]
                self.collection = [
                    "urn:hbo:feature:" + x.split("urn:hbo:tile:")[1].split(":")[0]
                    for x in episodes["references"]["items"]
                ]
                return self.get_references(id_, main=True, collection_first_title=True)

            episodes = episodes["references"]["episodes"]
            id_ = self.session.post(
                url=self.config["endpoints"]["content"],
                json=[
                    {
                        "id": episodes[0]
                        if main
                        else [episode for episode in episodes if id_ in episode][0]
                    }
                ],
                headers={
                    "Authorization": f"{self.auth_grant['token_type']} {self.auth_grant['access_token']}"
                },
            ).json()[0]["body"]["references"]["edits"][0]
        else:
            title_id = "urn:hbo:feature:" + id_
            if collection_first_title:
                self.movie_reference = self.get_metadata(id=self.title)
                title_id = (
                    "urn:hbo:feature:"
                    + self.movie_reference["references"]["items"][0]
                    .split("urn:hbo:tile:")[1]
                    .split(":")[0]
                )

            self.movie_reference = self.get_metadata(id=title_id)
            if self.movie_reference.get("message"):
                raise MetadataNotAvailable(reason=self.movie_reference["message"])
            id_ = self.movie_reference["references"]["edits"][0]

        return self.session.post(
            url=self.config["endpoints"]["content"],
            json=[{"id": id_}],
            headers={
                "Authorization": f"{self.auth_grant['token_type']} {self.auth_grant['access_token']}"
            },
        ).json()[0]["body"]

    def get_region(self):
        payload = {
            "contract": "hadron:1.1.2.0",
            "preferredLanguages": ["nl-nl", "en-us"],
        }

        try:
            data = self.session.post(
                url=self.config["endpoints"]["session"],
                json=payload,
                headers={
                    "Authorization": f"{self.auth_grant['token_type']} {self.auth_grant['access_token']}"
                },
            ).json()
        except json.JSONDecodeError:
            self.auth_grant = self.refresh(self.auth_grant)

            try:
                data = self.session.post(
                    url=self.config["endpoints"]["session"],
                    json=payload,
                    headers={
                        "Authorization": f"{self.auth_grant['token_type']} {self.auth_grant['access_token']}"
                    },
                ).json()
            except json.JSONDecodeError:
                log.exit(" x Failed to get region")

        if (
            data["features"]["meta"]["config"]["currentRegionTerritory"]
            == "NO ENTITLED CONTENT"
        ):
            raise NotEntitled

        return data["features"]["meta"]["config"]["currentRegionTerritory"]

    def get_auth_grant(self) -> dict:
        if not self.credentials:
            log.exit(" x No credentials provided, unable to log in.")
        tokens_cache_path = self.get_cache(
            hashlib.md5(
                f"{self.credentials.username}:{self.credentials.password}".encode()
            ).hexdigest()
            + ".json"
        )
        if tokens_cache_path.is_file():
            tokens = json.loads(tokens_cache_path.read_text(encoding="utf8"))
            if tokens_cache_path.stat().st_ctime > (time.time() - tokens["expires_in"]):
                return tokens
            # expired, refreshing:
            tokens = self.refresh(tokens)
        else:
            # first time
            client_grant = self.get_client_token()
            r = self.session.post(
                url=self.config["endpoints"]["tokens"],
                json={
                    "scope": "browse video_playback device elevated_account_management",
                    "grant_type": "user_name_password",
                    "username": self.credentials.username,
                    "password": self.credentials.password,
                },
                headers={
                    "Authorization": f"{client_grant['token_type']} {client_grant['access_token']}"
                },
            )
            try:
                res = r.json()
            except json.JSONDecodeError:
                log.exit(
                    f" - Failed to retrieve auth grant token, response was not JSON: {r.text}"
                )
            if "code" in res and res["code"] == "invalid_credentials":
                raise InvalidCredentials
            if "access_token" not in res:
                log.exit(f" - No access_token in auth grant token response: {res}")

            tokens = res

        tokens_cache_path.parent.mkdir(parents=True, exist_ok=True)
        tokens_cache_path.write_text(json.dumps(tokens))
        return tokens

    def get_client_token(self) -> dict:
        res = self.session.post(
            url=self.config["endpoints"]["tokens"],
            json={
                "client_id": self.config["client"]["android"]["id"],
                "client_secret": self.config["client"]["android"]["id"],
                "scope": "browse video_playback_free",
                "grant_type": "client_credentials",
                "deviceSerialNumber": self.config["device"]["serial_number"],
                "clientDeviceData": {"paymentProviderCode": "blackmarket"},
            },
        )
        try:
            data = res.json()
        except json.JSONDecodeError:
            log.exit(
                f" - Failed to retrieve temp client token, response was not JSON: {res.text}"
            )
        if "access_token" not in data:
            if "geo_blocked" in data["code"]:
                raise GeoRestriction
            elif "invalid_credentials" in data["code"]:
                raise InvalidCredentials
            else:
                log.exit(f" - No access_token in temp client token response: {data}")
        return data

    def refresh(self, tokens):
        r = self.session.post(
            url=self.config["endpoints"]["refresh_tokens"],
            json={
                "scope": "browse video_playback device",
                "grant_type": "refresh_token",
                "refresh_token": tokens["refresh_token"],
            },
        )
        try:
            res = r.json()
        except json.JSONDecodeError:
            log.exit(" x Failed to refresh access token")
        if "access_token" not in res:
            log.exit(" x No access_token in refresh response")
        return res
