from __future__ import annotations

from typing import Any, Optional

import click
import locale
import platform
import json
import time
import re
import base64
from click import Context
import subprocess

from datetime import datetime, timedelta, date
from collections import OrderedDict

from widevinely.objects import MenuTrack, Title, Tracks, TextTrack
from widevinely.services.BaseService import BaseService
from widevinely.utils import tmdb, logger, clean_line
from widevinely.utils.globals import arguments

log = logger.getLogger("NLZ")


class NLziet(BaseService):
    """
    Service code for NLziet, a service that provide videos
    from several sources like; NPO, KIJK and RTL. (https://app.nlziet.nl).

    Authorization: Credentials
    Security: UHD@-- FHD@L3, doesn't care about releases.

    Tips: The library of contents can be viewed without logging in at https://app.nlziet.nl/

    """

    ALIASES = ["NLZ", "nlziet"]

    TITLE_RE = [
        r"^(?:https?://app.nlziet\.nl/(?P<type>vod|series)/)?(?P<id>[a-zA-Z0-9-_]+)(?:.+)?"
    ]

    @staticmethod
    @click.command(name="NLziet", short_help="app.nlziet.nl")
    @click.argument("title", type=str)
    @click.option(
        "-m", "--movie", is_flag=True, default=False, help="Title is a Movie."
    )
    @click.pass_context
    def cli(ctx: Context, **kwargs: Any) -> NLziet:
        return NLziet(ctx, **kwargs)

    def __init__(self, ctx, title, movie):
        global args
        args = arguments()

        m = self.parse_title(ctx, title)
        self.movie = movie or m.get("type") == "vod"
        super().__init__(ctx)

        self.session = BaseService.get_session(self)

        self.drm_widevine_config: Optional[str] = None
        self.auth_grant: dict
        self.configure()

    def headers(self):
        return {
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "User-Agent": self.config["client"]["android"]["User-Agent"],
        }

    def get_titles(self):
        headers = self.headers()
        metadata_url = (
            self.config["endpoints"]["content_details"].format(title_id=f"{self.title}")
            if self.movie
            else self.config["endpoints"]["series_content"].format(
                title_id=f"{self.title}"
            )
        )

        headers[
            "Authorization"
        ] = f"{self.auth_grant['token_type']} {self.auth_grant['access_token']}"
        metadata = self.session.get(url=metadata_url, headers=headers).json()
        if "No content item with ID" in metadata:
            log.exit(f"{clean_line} x Could not find the content provided")
        if self.movie:
            tmdb_info = tmdb.info(
                content_name=metadata["title"],
                content_year=int(metadata["assets"]["vod"]["firstAirDate"][:4]),
                type_="movie",
            )

            titles = Title(
                id_=self.title,
                type_=Title.Types.MOVIE,
                name=tmdb_info.get("name")
                or metadata.get("title")
                or tmdb_info.get("name"),
                year=int(tmdb_info.get("year")[:4])
                or int(metadata["assets"]["vod"]["firstAirDate"][:4]),
                synopsis=tmdb_info.get("synopsis") or metadata["description"],
                original_lang="nl",  # TODO: Don't assume
                tmdb_id=tmdb_info.get("tmdb_id") or None,
                imdb_id=tmdb_info.get("imdb_id") or None,
                thumbnail=tmdb_info.get("thumbnail")
                or metadata["image"]["landscapeUrl"],
                source=self.ALIASES[0],
                service_data=metadata,
            )
        else:
            for season in metadata["seasons"]:
                season["seasonNumber"] = (
                    int(re.search(r"\d+", season["title"]).group())
                    if re.search(r"\d+", season["title"])
                    else metadata["seasons"].index(season) + 1
                )

            seasons = {}
            for season in metadata["seasons"]:
                if not seasons.get(season["seasonNumber"]):
                    seasons[season["seasonNumber"]] = season
                else:
                    seasons[season["seasonNumber"]]["id"] = [
                        seasons[season["seasonNumber"]]["id"],
                        season["id"],
                    ]

            seasons = OrderedDict(reversed(list(seasons.items())))

            episodes = []
            for season in [x for i, x in seasons.items()]:
                season["episodes"] = []
                for season_id in (
                    [season["id"]] if isinstance(season["id"], str) else season["id"]
                ):
                    season["episodes"] += self.session.get(
                        url=self.config["endpoints"]["series_content"].format(
                            title_id=f"{self.title}"
                        )
                        + f"/episodes?seasonId={season_id}&limit=999&offset=0",
                        headers=headers,
                    ).json()

                for episode in season["episodes"].copy():
                    episode["episodeNumber"] = (
                        f"{int(episode['formattedEpisodeNumbering'].split(':A')[1]):02d}"
                        if episode["formattedEpisodeNumbering"]
                        else season["episodes"].index(episode) + 1
                    )
                    episode["seasonNumber"] = season["seasonNumber"]

                season["episodes"] = sorted(
                    season["episodes"], key=lambda x: int(x["episodeNumber"])
                )
                for episode in season["episodes"]:
                    episodes.append(episode)

            self.total_titles = (
                len(seasons),
                len(episodes),
            )

            for x in episodes:
                if x["formattedDate"] == "Eergisteren":
                    x["formattedDate"] = datetime.strftime(
                        datetime.now() - timedelta(2), "%Y-%m-%d"
                    )
                elif x["formattedDate"] == "Gisteren":
                    x["formattedDate"] = datetime.strftime(
                        datetime.now() - timedelta(1), "%Y-%m-%d"
                    )
                elif x["formattedDate"] == "Vandaag":
                    x["formattedDate"] = datetime.strftime(datetime.now(), "%Y-%m-%d")
                elif x["formattedDate"] == "Morgen":
                    x["formattedDate"] = datetime.strftime(
                        datetime.now() + timedelta(2), "%Y-%m-%d"
                    )
                elif x["formattedDate"] == "Overmorgen":
                    x["formattedDate"] = datetime.strftime(
                        datetime.now() + timedelta(1), "%Y-%m-%d"
                    )
                else:
                    try:
                        x["formattedDate"] = datetime.strftime(
                            datetime.strptime(x["formattedDate"], "%a %d %b. %Y"),
                            "%Y-%m-%d",
                        )
                    except ValueError:
                        release_date = datetime.strftime(
                            datetime.strptime(
                                x["formattedDate"],
                                "%a %d %b."
                                if "." in x["formattedDate"]
                                else "%a %d %b %Y",
                            ),
                            "-%m-%d",
                        )
                        x["formattedDate"] = date.today().strftime("%Y") + release_date

            locale.setlocale(
                locale.LC_ALL, self.old_locale
            )  # Change the local language setting back

            if args.dl.latest_episodes:
                latest_release_date = episodes[-1]["formattedDate"]
                episodes = [
                    x for x in episodes if x["formattedDate"] == latest_release_date
                ]
            elif args.dl.wanted:
                episodes = Tracks.get_wanted(
                    episodes, season="seasonNumber", episode="episodeNumber"
                )

            tmdb_info = tmdb.info(
                content_name=metadata["title"],
                content_year=metadata["startYear"],
                type_="tv",
            )

            for episode in episodes:
                titles = [
                    Title(
                        id_=episode["id"],
                        type_=Title.Types.TV,
                        name=tmdb_info.get("name") or metadata["title"],
                        year=int(tmdb_info.get("year")[:4]) or metadata["startYear"],
                        season=episode["seasonNumber"],
                        episode=episode["episodeNumber"],
                        synopsis=tmdb_info.get("synopsis")
                        or metadata.get("description"),
                        episode_name=episode.get("subtitle"),
                        original_lang="nl",  # TODO: Don't assume
                        tmdb_id=tmdb_info.get("tmdb_id") or None,
                        imdb_id=tmdb_info.get("imdb_id") or None,
                        tvdb_id=tmdb_info.get("tvdb_id") or None,
                        thumbnail=episode["image"]["landscapeUrl"]
                        or tmdb_info.get("thumbnail"),
                        source=self.ALIASES[0],
                        service_data=metadata,
                    )
                    for episode in episodes
                ]
        return titles

    def get_tracks(self, title):
        headers = self.headers()
        headers[
            "Authorization"
        ] = f"{self.auth_grant['token_type']} {self.auth_grant['access_token']}"

        manifest = self.session.get(
            url=self.config["endpoints"]["manifest"].format(title_id=title.id),
            headers=headers,
            params={
                "playerName": self.config["client"]["android"]["playerName"],
                "maxresolution": self.config["client"]["android"]["maxResolution"],
            },
        ).json()
        if "code" in manifest:
            log.exit(
                f" x Failed to fetch the manifest for \"{title.service_data['id']}\", {manifest['code']}, {manifest['error']}",
                style="error",
            )

        if manifest["drmConfig"]:
            self.drm_widevine_config = manifest["drmConfig"]["widevine"]

        tracks = Tracks.from_mpd(
            url=manifest["uri"], lang="nl", source=self.ALIASES[0], session=self.session
        )
        for video in tracks.videos:
            video.language = title.original_lang
            if video.language._str_tag == "none".lower():
                video.language._str_tag = title.original_lang.language

        for audio in tracks.audio:
            audio.language = title.original_lang
            if audio.language._str_tag == "none".lower():
                audio.language._str_tag = title.original_lang.language
            if audio.codec == "mp4a":
                audio.channels = "2.0"

        subtitle_content = self.session.get(
            url=self.config["endpoints"]["content_details"].format(title_id=title.id),
            headers=headers,
        ).json()
        if subtitle_content["assets"]["vod"]["subtitleUrl"]:
            title.tracks.subtitles.append(
                TextTrack(
                    id_=None,
                    source=self.ALIASES[0],
                    url=subtitle_content["assets"]["vod"]["subtitleUrl"],
                    # metadata
                    codec="vtt",
                    language=title.original_lang.language,
                    # is_original_lang=is_close_match(
                    #     manifest['stream']['subtitle'],
                    #     [title.original_lang]
                    # ),
                    forced=False,
                    # text track options
                    sdh=True,
                )
            )

        return tracks

    def get_chapters(self, title: Title) -> list[MenuTrack]:
        return []

    def certificate(self, **kwargs: Any) -> bytes:
        # TODO: Hardcode the certificate
        return self.license(**kwargs)

    def license(self, challenge: bytes, **_: Any) -> bytes:
        assert self.drm_widevine_config is not None
        headers = {
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "User-Agent": "TFPlayer v2.22.1",
            "Authorization": f"{self.auth_grant['token_type']} {self.auth_grant['access_token']}",
        }

        self.platform_challenge = base64.b64encode(challenge)

        payload = {
            "getRawWidevineLicense": {
                "releasePid": self.drm_widevine_config["contentId"],
                "widevineChallenge": self.platform_challenge.decode("utf-8"),
            }
        }

        if self.drm_widevine_config["customHeaders"]:
            for k, v in self.drm_widevine_config["customHeaders"].items():
                headers[k] = v

        if "theplatform" in self.drm_widevine_config["drmServerUrl"]:
            return self.session.post(
                self.drm_widevine_config["drmServerUrl"],
                json.dumps(payload),
                headers=headers,
            ).content
        else:
            return self.session.post(
                self.drm_widevine_config["drmServerUrl"],
                data=challenge,
                headers=headers,
            ).content

    # Service specific functions

    def configure(self):
        self.auth_grant = self.get_auth_grant()
        self.old_locale = locale.getlocale()
        try:
            locale.setlocale(
                locale.LC_ALL, "nl_NL.utf8"
            )  # Change the local language setting to nl_NL for datetime
        except Exception:
            if platform.system() == "Linux":
                subprocess.Popen(
                    "sudo apt upgrade -y && apt update -y",
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                )
                subprocess.Popen(
                    "sudo apt-get install -y locales locales-all",
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                )
                locale.setlocale(locale.LC_ALL, "nl_NL.utf8")

    def get_auth_grant(self) -> dict:
        if not self.credentials:
            log.exit(" x No credentials provided, unable to log in.")

        tokens_cache_path = self.get_cache(
            f"{self.credentials.username}__{self.credentials.password}.json"
        )
        if tokens_cache_path.is_file():
            tokens = json.loads(tokens_cache_path.read_text(encoding="utf8"))
            if tokens_cache_path.stat().st_ctime > (time.time() - tokens["expires_in"]):
                return tokens
            # expired, refreshing:
            tokens = self.refresh(refresh_token=tokens["refresh_token"])
        else:
            # first time
            headers = self.headers()
            payload = {
                "username": self.credentials.username,
                "password": self.credentials.password,
                "grant_type": "password",
                "scope": "api offline_access",
                "client_id": self.config["client"]["android"]["client_id"],
            }

            login = self.session.post(
                self.config["endpoints"]["tokens"], data=payload, headers=headers
            ).json()

            tokens = {
                "access_token": login["access_token"],
                "token_type": login["token_type"],
                "expires_in": login["expires_in"],
                "refresh_token": login["refresh_token"],
            }
        tokens_cache_path.parent.mkdir(parents=True, exist_ok=True)
        tokens_cache_path.write_text(json.dumps(tokens))
        return tokens

    def refresh(self, refresh_token) -> dict:
        headers = self.headers()
        payload = {
            "grant_type": "refresh_token",
            "scope": "api offline_access",
            "client_id": self.config["client"]["android"]["client_id"],
            "refresh_token": refresh_token,
        }

        refresh = self.session.post(
            self.config["endpoints"]["tokens"], data=payload, headers=headers
        ).json()

        tokens = {
            "access_token": refresh["access_token"],
            "token_type": refresh["token_type"],
            "expires_in": refresh["expires_in"],
            "refresh_token": refresh["refresh_token"],
        }

        return tokens
