from __future__ import annotations

import json
import time
import hashlib
from typing import Any

import click
from click import Context

from widevinely.objects import Title, Tracks
from widevinely.services.BaseService import BaseService
from widevinely.utils.globals import arguments
from widevinely.utils.globals import cdm as cdm_
from widevinely.utils import tmdb, logger
from widevinely.utils.exceptions import *

log = logger.getLogger("ZEE5")


class ZEE5(BaseService):
    """
    Service code for ZEE5 streaming service (https://zee5.com).

    Authorization: Credentials
    Security:
        - L3: <= 2160p

        The library of contents can be viewed without logging in at https://www.zee5.com
    """

    ALIASES = ["ZEE5"]

    TITLE_RE = r"^(?:https?://(?:www\.)?zee5\.com/(?:global/|)?(?P<type>movies|tv-shows)?)?/details/[a-z0-9-]+/(?P<id>[a-zA-Z0-9-]+)"

    @staticmethod
    @click.command(name="ZEE5", short_help="zee5.com")
    @click.argument("title", type=str)
    @click.pass_context
    def cli(ctx: Context, **kwargs: Any) -> ZEE5:
        return ZEE5(ctx, **kwargs)

    def __init__(self, ctx, title):
        global args, cdm
        args = arguments(service=ctx.params)
        cdm = cdm_().cdm

        self.url = title
        self.parse_title(ctx, title)

        super().__init__(ctx)
        self.session = BaseService.get_session(self)
        self.configure()

    def get_titles(self):
        titles_ = []
        title_info = self.session.get(
            url=self.config["endpoints"]["title"].format(contentId=self.title),
        ).json()

        cast = []
        for actor in title_info["actors"]:
            actor = actor.split(":")
            for a in actor:
                if (
                    " " in a
                ):  # The one with space is considered the actor and not their role
                    cast.append(a)

        tmdb_info = tmdb.info(
            content_name=title_info["original_title"],
            content_year=int(title_info["release_date"][:4]),
            type_="movie" if title_info["asset_subtype"] == "movie" else "tv",
            cast=cast,
        )

        if title_info["asset_subtype"] == "movie":
            self.movie = True
            titles_ += [title_info]
        else:
            import itertools

            for season in [title_info["season"]]:
                for num in itertools.count(1):
                    season_info = self.session.get(
                        url=self.config["endpoints"]["season"].format(
                            contentId=season["id"], page=num, limit=100
                        ),
                    ).json()

                    for episode in season_info["episode"]:
                        episode["season_number"] = season["index"]

                    titles_ += season_info["episode"]

                    if not season_info.get("next_episode_api"):
                        break

            titles_ = sorted(titles_, key=lambda x: x["episode_number"])

            self.total_titles = (
                len(title_info["season"]),
                len(titles_),
            )

            if args.dl.latest_episodes:
                latest_release_date = titles_[-1]["release_date"][:10]
                titles_ = [
                    x for x in titles_ if x["release_date"][:10] == latest_release_date
                ]
            elif args.dl.wanted:
                titles_ = Tracks.get_wanted(
                    titles_, season="season_number", episode="episode_number"
                )

        for title in titles_:
            titles = [
                Title(
                    id_=title["id"],
                    type_=Title.Types.MOVIE if self.movie else Title.Types.TV,
                    name=tmdb_info.get("name") or title_info["original_title"],
                    year=int(tmdb_info.get("year")[:4])
                    or int(title_info["release_date"][:4]),
                    season=title.get("season_number"),
                    episode=title.get("episode_number"),
                    synopsis=title_info["description"],
                    episode_name=title.get("original_title"),
                    original_lang=tmdb_info.get("original_language")
                    or title["video_details"]["audiotracks"][0],
                    tmdb_id=tmdb_info.get("tmdb_id") or None,
                    imdb_id=tmdb_info.get("imdb_id") or None,
                    tvdb_id=tmdb_info.get("tvdb_id") or None,
                    thumbnail=tmdb_info.get("thumbnail"),
                    source=self.ALIASES[0],
                    service_data=title,
                )
                for title in titles_
            ]

        return titles

    def get_tracks(self, title):
        res = self.session.post(
            url=self.config["endpoints"]["playback"],
            params={
                "content_id": title.id,
                "device_id": self.deviceId,
                "platform_name": "Linux; Android 7.1.1",
                "translation": "en",
                "user_language": "bn,en,hi,mr,pa,ta,te",
                "country": self.country,
                "app_version": "2.51.26",
                "user_type": "register",
                "check_parental_control": "false",
                "uid": "",
                "ppid": self.deviceId,
                "version": "12",
            },
            json={
                "Authorization": self.access_token,
                "x-access-token": self.session_token,
            },
        )

        try:
            video_info = res.json()
        except json.JSONDecodeError:
            raise ManifestNotAvailable

        self.keyOS = video_info["keyOsDetails"]

        tracks = []
        try:
            for res in ("4k_", ""):
                tracks += Tracks.from_mpd(
                    url=video_info["assetDetails"]["video_url"][f"{res}mpd"],
                    lang=title.original_lang,
                    source=self.ALIASES[0],
                    session=self.session,
                )
        except Exception:
            pass

        tracks = Tracks(tracks)

        for audio in tracks.audio:
            if audio.codec == "mp4a":
                audio.channels = "2.0"
            else:
                audio.channels = "5.1"

        return tracks

    def get_chapters(self, title):
        return []

    def certificate(self, **_: Any) -> str:
        return self.config["certificate"]

    def license(self, challenge, track, **_):
        licensing = self.session.post(
            url=self.config["endpoints"]["license"],
            data=challenge,
            headers={"customdata": self.keyOS["sdrm"], "nl": self.keyOS["nl"]},
        ).content

        return licensing

    # Service specific functions

    def configure(self):
        self.country = self.get_country()

        self.access_token = self.get_token()
        self.session_token = self.session.get(
            self.config["endpoints"]["session_token"]
        ).json()["token"]

        self.session.headers.update(
            {
                "Accept-Language": "en-US,en;q=0.5",
                "Origin": "https://www.zee5.com",
                "X-ACCESS-TOKEN": self.session_token,
            }
        )

        devices = self.session.get(
            url=self.config["endpoints"]["device"],
            headers=dict(
                **self.session.headers,
                **{"Authorization": self.access_token},
            ),
        ).json()

        self.deviceId = devices[-1]["identifier"]

    def get_country(self):
        return self.session.get(self.config["endpoints"]["country"]).json()[
            "country_code"
        ]

    def get_token(self):
        if not self.credentials:
            raise CredentialsNotProvided

        tokens_cache_path = self.get_cache(
            hashlib.md5(
                f"{self.credentials.username}:{self.credentials.password}".encode()
            ).hexdigest()
            + ".json"
        )

        if tokens_cache_path.is_file():
            tokens = json.loads(tokens_cache_path.read_text(encoding="utf8"))
            if tokens_cache_path.stat().st_ctime > (time.time() - tokens["expires_in"]):
                return f"bearer {tokens['access_token']}"

        return f"bearer {self.login(tokens_cache_path)['access_token']}"

    def login(self, tokens_cache_path):
        r = self.session.post(
            url=self.config["endpoints"]["auth_token"],
            data=json.dumps(
                {
                    "email": self.credentials.username,
                    "password": self.credentials.password,
                    "aid": "91955485578",
                    "lotame_cookie_id": "",
                    "guest_token": "RUJT0alkBYwU2gTRd4KB000000000000",
                    "platform": "web",
                    "version": "2.50.71",
                }
            ),
        )

        try:
            tokens = r.json()
        except json.JSONDecodeError:
            raise TokenNotObtained(access_token=True)

        tokens_cache_path.parent.mkdir(parents=True, exist_ok=True)
        tokens_cache_path.write_text(json.dumps(tokens))

        return tokens
