from __future__ import annotations

import json
import re
import xmltodict

import click
from click import Context
from httpx import URL
from requests import JSONDecodeError

from widevinely.objects import MenuTrack, Title, Track, Tracks
from widevinely.services.BaseService import BaseService
from widevinely.utils import tmdb, logger
from widevinely.utils.globals import arguments
from widevinely.utils.globals import cdm as cdm_

log = logger.getLogger("MA")


class MoviesAnywhere(BaseService):
    """
    Service code for US' streaming service MoviesAnywhere (https://moviesanywhere.com).

    \b
    Authorization: Cookies
    Security: SD-HD@L3, FHD SDR@L1 (any active device), FHD-UHD HDR-DV@L1 (whitelisted devices).

    NOTE: Can be accessed from any region, it does not seem to care.
          Accounts can only mount services when its US based though.

    """

    ALIASES = ["MA", "moviesanywhere"]

    TITLE_RE = r"https://moviesanywhere\.com(?P<id>.+)"

    @staticmethod
    @click.command(name="MoviesAnywhere", short_help="moviesanywhere.com")
    @click.argument("title", type=str)
    @click.pass_context
    def cli(ctx: Context, **kwargs) -> MoviesAnywhere:
        return MoviesAnywhere(ctx, **kwargs)

    def __init__(self, ctx: Context, title):
        global args, cdm
        args = arguments()
        cdm = cdm_().cdm

        if (
            args.dl.quality != "SD"
            and args.dl.quality > 720
            and cdm.security_level == 3
            and not args.dl.cache
            and not args.dl.list
            and not args.dl.audio_only
            and not args.dl.subs_only
        ):
            log.exit(f"It's not possible to decrypt {args.dl.quality}p with an L3 Cdm")

        self.title_url = title
        self.parse_title(ctx, title)
        super().__init__(ctx)

        self.session = BaseService.get_session(self)

        self.configure()

    def get_titles(self):
        res = self.session.post(
            url="https://gateway.moviesanywhere.com/graphql",
            json={
                "extensions": json.dumps(
                    {
                        "persistedQuery": {
                            "sha256Hash": "5057499fd6db8e95aa3e8f21850c91412040e53f11ca8d2b66a597d2526df47c",  # ONE_GRAPH_PERSIST_QUERY_TOKEN
                            "version": 1,
                        }
                    }
                ),
                "platform": "web",  # Does not seem to care which platform will be used to give the best tracks available
                "variables": json.dumps({"slug": self.title}),
                "Authorization": f"Bearer {self.access_token}",
                "install-id": self.install_id,
            },
        )

        try:
            self.content = res.json()
        except JSONDecodeError:
            log.exit(" x Not able to return title information")

        if "error" in str(self.content):
            log.exit(
                f" x Not able to return title information: {self.content['errors'][0]['message']!r}"
            )

        title_data = self.content["data"]["page"]

        credits = [
            x["credits"]
            for x in title_data["components"]
            if x["__typename"] == "SynopsisComponent"
        ][0]
        cast = [x["name"] for x in credits if x["creditType"].lower() == "cast"]

        title_info = [
            x
            for x in title_data["components"]
            if x["__typename"] == "MovieMarqueeComponent"
        ][0]

        # Make sure it removes Edition names
        # because TMDb has troubles searching with it
        title_info["title"] = re.sub(r" \(.+?\)", "", title_info["title"])

        tmdb_info = tmdb.info(
            content_name=title_info["title"],
            content_year=title_info["year"],  # expects int
            type_="movie",
            cast=cast,
        )

        titles = Title(
            id_=self.title,
            type_=Title.Types.MOVIE,
            name=tmdb_info.get("name") or title_info["title"],
            year=int(tmdb_info.get("year")[:4]) or title_info["year"],
            synopsis=tmdb_info.get("synopsis")
            or [
                x["text"]
                for x in title_data["components"]
                if x["__typename"] == "SynopsisComponent"
            ][0],
            original_lang=tmdb_info.get("original_language")
            or "en",  # TODO: See if we can find the original language in the API
            tmdb_id=tmdb_info.get("tmdb_id") or None,
            imdb_id=tmdb_info.get("imdb_id") or None,
            thumbnail=tmdb_info.get("thumbnail")
            or f"https:{title_info['boxArtImage']['url']}.png",
            source=self.ALIASES[0],
            service_data=title_data,
        )

        return titles

    def get_tracks(self, title):
        try:
            self.player_data = self.content["data"]["page"]["components"][0][
                "mainAction"
            ]["playerData"]["playable"]
        except KeyError:
            log.exit(" x Account does not seem to own this title")

        player_data = self.player_data

        tracks = Tracks()
        videos = []
        subtitles = []
        for cr in player_data["videoAssets"]["dash"].values():
            if not cr:
                continue
            for manifest in cr:
                cr_tracks = Tracks.from_mpd(
                    url=manifest["url"],
                    lang=title.original_lang,
                    source=self.ALIASES[0],
                    session=self.session,
                )

                mpd = xmltodict.parse(
                    self.session.get(manifest["url"]).text, dict_constructor=dict
                )

                # Make sure we parse the right KID
                for adaption in mpd["MPD"]["Period"]["AdaptationSet"]:
                    if adaption["@mimeType"] == "video/mp4":
                        if "ContentProtection" in adaption:
                            for protection in adaption["ContentProtection"]:
                                if (
                                    protection["@schemeIdUri"]
                                    == "urn:mpeg:dash:mp4protection:2011"
                                ):
                                    kid = protection["@cenc:default_KID"].lower()

                for video in cr_tracks.videos:
                    video.kid = kid
                    video.license_url = manifest["widevineLaUrl"]
                    video.contentId = URL(video.license_url).params._dict["ContentId"][
                        0
                    ]
                    videos += [video]

                for audio in cr_tracks.audio:
                    if (
                        any(audio.id != at.id for at in tracks.audio)
                        or not tracks.audio
                    ):
                        tracks.add(cr_tracks.audio)

                for subtitle in cr_tracks.subtitles:
                    if any(subtitle.id != sub.id for sub in subtitles) or not subtitles:
                        subtitles += [subtitle]

        tracks.add(subtitles)

        corrected_video_list = []
        for res in ("uhd", "hdp", "hd", "sd"):
            for video in videos:
                if f"_{res}_video" not in video.url or not video.url.endswith(
                    f"&r={res}"
                ):
                    continue

                if corrected_video_list and any(
                    video.id == vid.id for vid in corrected_video_list
                ):
                    continue

                if "dash_hevc_hdr" in video.url:
                    video.hdr10 = True
                    video.variables["range"] = "HDR10"
                    video.map = video.map.replace("SDR", "HDR10")
                if "dash_hevc_dolbyvision" in video.url:
                    video.dv = True
                    video.variables["range"] = "DV"
                    video.map = video.map.replace("SDR", "DV")

                corrected_video_list += [video]

        tracks.add(corrected_video_list)

        return tracks

    def get_chapters(self, title: Title) -> list[MenuTrack]:
        return []

    def certificate(self, **_):
        return None  # will use common privacy cert

    def license(self, challenge: bytes, track: Track, **_) -> bytes:
        license_message = self.session.post(
            url=track.license_url,
            data=challenge,  # expects bytes
        )

        if "errorCode" in license_message.text:
            log.exit(f" x Cannot complete license request: {license_message.text}")

        return license_message.content

    # Service specific functions

    def configure(self):
        self.access_token = self.session.cookies.get("secure_access_token")
        self.install_id = self.session.cookies.get("install_id")

        self.session.headers.update(
            {
                "Origin": "https://moviesanywhere.com",
                "Authorization": f"Bearer {self.access_token}",
            }
        )
