from __future__ import annotations

import re
import click
import ssl
import httpx

from abc import ABCMeta, abstractmethod
from pathlib import Path
from typing import Optional, Union

from widevinely.config import config, directories
from widevinely.objects import MenuTrack, Title, Track, Tracks
from widevinely.utils import logger
from widevinely.utils.proxies import get_proxy
from widevinely.utils.globals import arguments
from widevinely.utils.collections import as_list
from widevinely.utils.exceptions import *

log = logger.getLogger("BaseService")


class SSLCiphers:
    """
    Custom HTTP Adapter to change the TLS Cipher set, and therefore it's fingerprint.

    Netflix currently TLS fingerprints Python-request calls and blocks them on MSL
    requests with EMAIL_PASSWORD user authentication data.

    Security Level may optionally be provided. A level above 0 must be used at all times.
    A list of Security Levels and their security is listed below. Usually 2 is set by default.
    Do not set the Security level via @SECLEVEL in the cipher list.

    Level 0:
        Everything is permitted. This retains compatibility with previous versions of OpenSSL.

    Level 1:
        The security level corresponds to a minimum of 80 bits of security. Any parameters
        offering below 80 bits of security are excluded. As a result RSA, DSA and DH keys
        shorter than 1024 bits and ECC keys shorter than 160 bits are prohibited. All export
        cipher suites are prohibited since they all offer less than 80 bits of security. SSL
        version 2 is prohibited. Any cipher suite using MD5 for the MAC is also prohibited.

    Level 2:
        Security level set to 112 bits of security. As a result RSA, DSA and DH keys shorter
        than 2048 bits and ECC keys shorter than 224 bits are prohibited. In addition to the
        level 1 exclusions any cipher suite using RC4 is also prohibited. SSL version 3 is
        also not allowed. Compression is disabled.

    Level 3:
        Security level set to 128 bits of security. As a result RSA, DSA and DH keys shorter
        than 3072 bits and ECC keys shorter than 256 bits are prohibited. In addition to the
        level 2 exclusions cipher suites not offering forward secrecy are prohibited. TLS
        versions below 1.1 are not permitted. Session tickets are disabled.

    Level 4:
        Security level set to 192 bits of security. As a result RSA, DSA and DH keys shorter
        than 7680 bits and ECC keys shorter than 384 bits are prohibited. Cipher suites using
        SHA1 for the MAC are prohibited. TLS versions below 1.2 are not permitted.

    Level 5:
        Security level set to 256 bits of security. As a result RSA, DSA and DH keys shorter
        than 15360 bits and ECC keys shorter than 512 bits are prohibited.
    """

    def __init__(
        self,
        cipher_list: Optional[str] = None,
        security_level: int = 0,
        *args,
        **kwargs,
    ):
        ctx = ssl.create_default_context()
        ctx.check_hostname = (
            False  # For some reason this is needed to avoid a verification error
        )
        self._ssl_context = ctx
        # You can set ciphers but Python's default cipher list should suffice.
        # This cipher list differs to the default Python-requests one.
        if security_level:
            if cipher_list:
                cipher_list += f":@SECLEVEL={security_level}"
            else:
                cipher_list = f"DEFAULT:@SECLEVEL={security_level}"
        if cipher_list:
            self._ssl_context.set_ciphers(cipher_list)
        super().__init__(*args, **kwargs)

    def init_poolmanager(self, *args, **kwargs):
        kwargs["ssl_context"] = self._ssl_context
        return super().init_poolmanager(*args, **kwargs)

    def proxy_manager_for(self, *args, **kwargs):
        kwargs["ssl_context"] = self._ssl_context
        return super().proxy_manager_for(*args, **kwargs)


class BaseService(metaclass=ABCMeta):
    """
    The Service Base Class
    This should not be directly used as a Service file, instead make a new class deriving this one:
    ```
    from widevinely.services.BaseService import BaseService

    ...

    class ServiceName(BaseService):

        ALIASES = ["DSNP", "disneyplus", "disney+"]  # first being the service tag (case-sensitive)

        def __init__(self, title, **kwargs):
            self.title = title

            # make sure the above 3 occur BEFORE the super().__init__() call below.
            super().__init__(**kwargs)  # re-route the Base related init args

            # service specific variables are recommended to be placed after the super().__init__() call

            # instead of flooding up __init__ with logic, initialize the variables as default values
            # here, and then call a new service specific (e.g. "configure()") in which has all the
            # preparation logic. This allows for cleaner looking service code.

        # from here, simply implement all the @abstractmethod functions seen in BaseClass.

        # e.g. def get_titles(...

        # After all the Abstract functions, I recommend putting any service specific functions
        # separated by a comment denoting that.

        # After those, I also recommend putting any service specific classes once again separated
        # by a comment denoting that.
    ```

    This class deals with initializing and preparing of all related code that's common among services.
    """

    # Abstract class variables
    ALIASES: list[
        str
    ] = []  # begin with source tag (case-sensitive) and name aliases (case-insensitive)

    def __init__(self, ctx: click.Context):
        self.config = ctx.obj.config
        self.cookies = ctx.obj.cookies
        self.credentials = ctx.obj.credentials

        assert ctx.parent is not None
        assert ctx.parent.parent is not None

    def get_session(self, delay_proxy: Optional[bool] = False) -> httpx.Client:
        """
        Creates a HTTPX Session, adds common headers
        from widevinely.config, cookies, and a proxy if available.

        :returns: Prepared HTTPX Session

        """
        args = arguments()

        if delay_proxy:
            proxy = None
        else:
            proxy = args.dl.proxy or args.dl.proxy_country
            args.dl.proxy = {
                "metadata": args.dl.metadata_proxy or proxy
                if not args.dl.no_proxy
                else None,
                "download": args.dl.download_proxy or proxy
                if not args.dl.no_proxy
                else None,
            }

            if not args.dl.no_proxy:
                for proxy in args.dl.proxy.items():
                    if (
                        not args.dl.proxy[proxy[0]]
                        or args.dl.proxy[proxy[0]].lower() == "none"
                    ):
                        args.dl.proxy[proxy[0]] = None
                        continue

                    args.dl.proxy[proxy[0]] = (
                        get_proxy(type_=proxy[0], silence=bool(proxy[0] == "download"))
                        if not delay_proxy
                        else None
                    )

        session = httpx.Client(
            http2=True,
            follow_redirects=True,
            verify=bool(self.ALIASES[0] != "NF") if self.ALIASES else True,
            proxies={"all://": args.dl.proxy["metadata"] if not delay_proxy else None},
            timeout=None,
        )

        session.headers.update(config.headers)
        session.cookies.update(getattr(self, "cookies", {}))

        if not delay_proxy:
            try:
                ipinfo = session.get(
                    "https://ipinfo.io/json?token=115e801551c194"
                ).json()
                session.ipinfo = ipinfo
            except Exception:
                raise ProxyConnectionError(
                    type_="metadata", uri=args.dl.proxy["metadata"]
                )

            if args.dl.proxy["metadata"]:
                log.info_(
                    " - [content]NEW IP   [/content]"
                    + f"{ipinfo['ip']} ({ipinfo['country'].upper()})\n"
                )

        return session

    # Abstract functions

    @abstractmethod
    def get_titles(self):
        """
        Get Titles for the provided title ID.

        Return a Title object for every unique piece of content found by the Title ID.
        Each `Title` object should be thought of as one output file/download. E.g. a movie should be one Title,
        and each episode of a TV show would also be one Title, where as a Season would be multiple Title's, one
        per episode.

        Each Title object must contain `title_name` (the Show or Movie name).
        For TV, it also requires `season` and `episode` numbers, with `episode_name` being optional
            but ideally added as well.
        For Movies, it has no further requirements but `year` would ideally be added.

        You can return one Title object, or a List of Title objects.

        For any further data specific to each title that you may need in the later abstract methods,
        add that data to the `service_data` variable which can be of any type or value you wish.

        :return: One of or a List of Title objects.
        """

    @abstractmethod
    def get_tracks(self, title: Title) -> Tracks:
        """
        Get Track objects of the Title.

        Return a Tracks object, which itself can contain Video, Audio, Subtitle or even Chapters.
        Tracks.videos, Tracks.audio, Tracks.subtitles, and Track.chapters should be a List of Track objects.

        Each Track in the Tracks should represent a Video/Audio Stream/Representation/Adaptation or
        a Subtitle file.

        While one Track should only hold information for one stream/downloadable, try to get as many
        unique Track objects per stream type so Stream selection by the root code can give you more
        options in terms of Resolution, Bitrate, Codecs, Language, e.t.c.

        No decision making or filtering of which Tracks get returned should happen here. It can be
        considered an error to filter for e.g. resolution, codec, and such. All filtering based on
        arguments will be done by the root code automatically when needed.

        Make sure you correctly mark which Tracks are encrypted or not via its `encrypted` variable.

        If you are able to obtain the Track's KID (Key ID) as a 32 char (16 bit) HEX string, provide
        it to the Track's `kid` variable as it will speed up the decryption process later on. It may
        or may not be needed, that depends on the service. Generally if you can provide it, without
        downloading any of the Track's stream data, then do.

        :param title: The current `Title` from get_titles that is being executed.
        :return: Tracks object containing Video, Audio, Subtitles, and Chapters, if available.
        """

    @abstractmethod
    def get_chapters(self, title: Title) -> list[MenuTrack]:
        """
        Get MenuTracks chapter objects of the Title.

        Return a list of MenuTracks objects. This will be run after get_tracks. If there's anything
        from the get_tracks that may be needed, e.g. "device_id" or a-like, store it in the class
        via `self` and re-use the value in get_chapters.

        How it's used is generally the same as get_titles. These are only separated as to reduce
        function complexity and keep them focused on simple tasks.

        You do not need to sort or order the chapters in any way. However, you do need to filter
        and alter them as needed by the service. No modification is made after get_chapters is
        ran. So that means ensure that the MenuTracks returned have consistent Chapter Titles
        and Chapter Numbers.

        :param title: The current `Title` from get_titles that is being executed.
        :return: List of MenuTrack objects, if available, empty list otherwise.
        """

    @abstractmethod
    def certificate(
        self, *, challenge: bytes, title: Title, track: Track, session_id: bytes
    ) -> Optional[Union[bytes, str]]:
        """
        Get the Service Privacy Certificate.
        This is supplied to the Widevine CDM for privacy mode operations.

        If the certificate is a common certificate (one shared among various services),
        then return `None` and it will be used instead.

        Once you obtain the certificate, hardcode the certificate here and return it to reduce
        unnecessary HTTP requests.

        :param challenge: The service challenge, providing this to a License endpoint should return the
            privacy certificate that the service uses.
        :param title: The current `Title` from get_titles that is being executed. This is provided in
            case it has data needed to be used, e.g. for a HTTP request.
        :param track: The current `Track` needing decryption. Provided for same reason as `title`.
        :param session_id: This is the session ID bytes blob used for storing Widevine session data.
            It has no real meaning or syntax to its value, but some HTTP requests may ask for one.
        :return: The Service Privacy Certificate as Bytes or a Base64 string. Don't Base64 Encode or
            Decode the data, return as is to reduce unnecessary computations.
        """

    @abstractmethod
    def license(
        self, *, challenge: bytes, title: Title, track: Track, session_id: bytes
    ) -> Optional[Union[bytes, str]]:
        """
        Get the License response for the specified challenge and title data.
        This can be decrypted and read by the Widevine CDM to return various keys
        like Content Keys or HDCP test keys.

        This is a very important request to get correct. A bad, unexpected, or missing value
        in the request can cause your key to be detected and promptly banned, revoked,
        disabled, or downgraded.

        :param challenge: The license challenge from the Widevine CDM.
        :param title: The current `Title` from get_titles that is being executed. This is provided in
            case it has data needed to be used, e.g. for a HTTP request.
        :param track: The current `Track` needing decryption. Provided for same reason as `title`.
        :param session_id: This is the session ID bytes blob used for storing Widevine session data.
            It has no real meaning or syntax to its value, but some HTTP requests may ask for one.
        :return: The License response as Bytes or a Base64 string. Don't Base64 Encode or
            Decode the data, return as is to reduce unnecessary computations.
        """

    # Convenience functions to be used by the inheritor

    def parse_title(self, ctx, title):
        title = title or ctx.parent.params.get("title")
        if not title:
            log.exit(" x No title ID specified")
        if not getattr(self, "TITLE_RE"):
            self.title = title
            return {}
        for regex in as_list(self.TITLE_RE):
            m = re.search(regex, title)
            if m:
                self.title = m.group("id")
                return m.groupdict()
        log.exit(f" x Unable to parse title ID {title!r}, using as-is")

    def get_cache(self, key, service: Optional[str] = None) -> Path:
        """
        Get path object for an item from service Cache. The path object can then be
        used to read or write to the cache under the item's key.

        Parameters:
            key: A string similar to a relative path to an item.
        """
        if service:
            return directories.sessions / service.lower() / key
        else:
            return directories.sessions / self.cli.name.lower() / key
