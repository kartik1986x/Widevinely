import random
import base64
import hashlib
import re
import json
import os
import string
import time
import httpx
from collections import defaultdict
from datetime import datetime

import click
import jsonpickle
from langcodes import Language
from bs4 import BeautifulSoup

from pywidevinely import Device

from widevinely.objects import Title, Tracks
from widevinely.objects.tracks import VideoTrack, AudioTrack, TextTrack, MenuTrack
from widevinely.services.BaseService import BaseService
from widevinely.utils import is_close_match, tmdb, logger
from widevinely.utils.collections import as_list
from widevinely.utils.globals import arguments
from widevinely.utils.globals import cdm as cdm_
from widevinely.utils.exceptions import *

log = logger.getLogger("AMZN")


class Amazon(BaseService):
    """
    Service code for Amazon's VOD and Prime Video (https://amazon.*), https://primevideo.com).

    \b
    Authorization: Cookies
    Security:
        - L1: >= 1080p SDR & 1080p HDR/DV + Atmos Audio (Whitelisted Cdm)
        - L3: <= 1080p SDR (ChromeCdm) & <= 576p (Android)

        Maintains their own license server like Netflix.
        They usually blacklist L1 Cdms really quick, be cautious.

    \b

    Region is chosen automatically when the ASIN matches with a region.
    """

    AMZN_ALIASES = ["AMZN", "amazon"]
    PRIME_ALIASES = ["PV", "primevideo"]

    ZONES = (
        r"^(?:https?://(?:www\.)?(?P<zone>amazon\.(?P<region>com|co\.uk|au|it|de|co\.jp)|primevideo)\.com(?:/.+)?/)?(?P<id>[A-Z0-9]{10,}|amzn1\.dv\.gti\.[a-f0-9-]+)",
        "primevideo",
        None,
    )

    TITLE_RE = r"^(?:https?://(?:www\.)?(?P<domain>amazon\.(?P<region>com|co\.uk|au|it|de|co\.jp)|primevideo\.com)(?:/.+)?/)?(?P<id>[A-Z0-9]{10,}|amzn1\.dv\.gti\.[a-f0-9-]+)"

    @staticmethod
    @click.command(name="Amazon", short_help="amazon.*, primevideo.com")
    @click.argument("title", type=str, required=False)
    @click.option(
        "-b",
        "--bitrate",
        default="VBR+CBR",
        type=click.Choice(
            [
                "VBR",  # Known for lower quality, even with higher bitrates
                "CBR",  # Superior mode, even with lower bitrates
                "VBR+CBR",  # Default in order to see the difference in bitrate
            ],
            case_sensitive=False,
        ),
        help="Video Bitrate Mode to download in."
        "                                            VBR: Variable Bitrate (Lower Quality)"
        "                                            CBR: Constant Bitrate (Superior)",
    )
    # UHD, HD, SD. UHD only returns HEVC, ever, even for <=HD only content
    @click.option(
        "-mq",
        "--manifest-quality",
        default=None,
        type=click.Choice(["SD", "HD", "UHD"], case_sensitive=False),
        help="Manifest quality to request.",
    )
    @click.option(
        "-am",
        "--audio-manifest",
        default=None,
        type=click.Choice(["VBR", "CBR", "H265"], case_sensitive=False),
        help="Manifest to use for audio. Defaults to H265 if the video manifest is missing 640k audio.",
    )
    @click.option(
        "-aq",
        "--audio-quality",
        default=None,
        type=click.Choice(["SD", "HD", "UHD"], case_sensitive=False),
        help="Manifest quality to request for audio. Defaults to the same as --quality.",
    )
    @click.pass_context
    def cli(ctx, **kwargs):
        return Amazon(ctx, **kwargs)

    def __init__(
        self,
        ctx,
        title,
        bitrate,
        manifest_quality,
        audio_manifest,
        audio_quality,
    ):
        global args, cdm
        args = arguments()
        cdm = cdm_().cdm

        super().__init__(ctx)

        m = self.parse_title(ctx, title)
        self.title = m["id"]
        
        self.primevideo = (
            "primevideo" in title or title.startswith("amzn1.dv.gti") or len(title) > 10
        )
        self.bitrate_mode = bitrate
        self.manifest_quality = manifest_quality
        self.audio_manifest = audio_manifest
        self.audio_quality = audio_quality

        self.endpoints = {}
        self.device = {}

        self.device_token = None
        self.device_id = None
        self.customer_id = None
        self.need_separate_audio = False
        self.client_id = "f22dbddb-ef2c-48c5-8876-bed0d47594fd"  # browser client id

        self.session = BaseService.get_session(self)
        self.region = self.get_region(m["id"])
        
        self.configure(ctx)

    # Abstracted functions

    def get_titles(self):
        # Important to get the right releaseDate format
        if self.primevideo:
            self.session.cookies.jar._cookies[".primevideo.com"]["/"][
                "lc-main-av"
            ].value = "en-GB"

        titles_ = []
        asins = self.get_asins(self.title)
        for asin in asins:
            res = self.session.get(
                url=self.endpoints["detail"],
                params={
                    "titleID": asin,
                    "isElcano": "1",
                    "sections": "Btf",
                },
                headers={"Accept": "application/json"},
            ).json()["widgets"]

            if res["productDetails"]["detail"]["entityType"] == "Movie":
                cards = res["productDetails"]
                title_type = Title.Types.MOVIE
            else:
                cards = res["titleContent"][0]["cards"]
                title_type = Title.Types.TV

            product_details = res["productDetails"]["detail"]

            if title_type == Title.Types.TV:
                for card in cards:
                    card["detail"]["seasonNumber"] = product_details.get("seasonNumber")

            # Only add playable titles
            titles_.extend(x for x in as_list(cards))

        cast = [
            x["name"] for x in titles_[0]["detail"]["contributors"]["starringActors"]
        ]

        if title_type == Title.Types.TV:
            if not any(x["action"]["playbackActions"] for x in titles_):
                raise NotEntitled
            titles_ = [x["detail"] for x in titles_ if x["action"]["playbackActions"]]

            self.total_titles = (
                len(set([title["seasonNumber"] for title in titles_])),
                len(titles_),
            )
        else:
            titles_ = [x["detail"] for x in titles_]

        title_name = product_details.get("parentTitle") or product_details.get("title")
        releaseYear = titles_[0].get("releaseYear") or product_details.get("releaseYear") or 0

        tmdb_info = tmdb.info(
            content_name=product_details.get("parentTitle") or product_details["title"],
            content_year=releaseYear,
            type_="movie" if title_type == Title.Types.MOVIE else "tv",
            cast=cast,
        )

        for title in titles_:
            title["thumbnail"] = (
                product_details["images"]["titleshot"]
                if title_type == Title.Types.MOVIE
                else title["images"]["packshot"]
            )
            title["synopsis"] = product_details["synopsis"]

        if title_type == Title.Types.TV:
            if args.dl.latest_episodes:
                latest_release_date = int(
                    str(
                        datetime.timestamp(
                            datetime.strptime(titles_[-1]["releaseDate"], "%B %d, %Y")
                        )
                    )[:10]
                )
                titles_ = [
                    x
                    for x in titles_
                    if int(
                        str(
                            datetime.timestamp(
                                datetime.strptime(x["releaseDate"], "%B %d, %Y")
                            )
                        )[:10]
                    )
                    == latest_release_date
                ]
            elif args.dl.wanted:
                titles_ = Tracks.get_wanted(
                    titles_, season="seasonNumber", episode="episodeNumber"
                )

            for title in titles_:
                if len(str(title["episodeNumber"])) > 2:
                    title["episodeNumber"] = int(
                        f"{int(str(title['episodeNumber'])[-2:]):02d}"
                    )

        original_language = self.get_original_language(
            self.get_manifest(
                titles_[0]["catalogId"],
                video_codec="H264",
                bitrate_mode="VBR+CBR",
                quality="HD",
            )
        )

        for title in titles_:
            if title.get("title"):
                title["title"] = re.sub(r"['“”]", "", title["title"])

            titles = [
                Title(
                    id_=title.get("catalogId"),
                    type_=title_type,
                    name=tmdb_info.get("name") or title_name,
                    year=int(tmdb_info.get("year")[:4]) or releaseYear,
                    season=title.get("seasonNumber"),
                    episode=title.get("episodeNumber"),
                    synopsis=tmdb_info.get("synopsis") or title.get("synopsis"),
                    episode_name=title.get("title"),
                    original_lang=tmdb_info.get("original_language")
                    or original_language
                    if original_language
                    else "en",
                    tmdb_id=tmdb_info.get("tmdb_id") or None,
                    imdb_id=tmdb_info.get("imdb_id") or None,
                    tvdb_id=tmdb_info.get("tvdb_id") or None,
                    thumbnail=title.get("thumbnail") or tmdb_info.get("thumbnail"),
                    source=self.AMZN_ALIASES[0],
                    service_data=title,
                )
                for title in titles_
            ]

        return titles

    def get_tracks(self, title):
        if args.dl.chapters_only:
            return

        tracks = []
        for range_ in self.range_list:
            for bitrate in ("VBR", "CBR"):
                manifest = self.get_manifest(
                    title,
                    video_codec="H265"
                    if range_ in ["Hevc", "Sdr", "Hdr10", "DolbyVision"]
                    else "H264",
                    bitrate_mode=bitrate,
                    quality="UHD"
                    if range_ in ["Hevc", "Sdr", "Hdr10", "DolbyVision"]
                    else "SD"
                    if self.manifest_quality == "SD"
                    else "HD",
                    range=range_ if range_ not in ["Hevc", "Sdr"] else "None",
                )
                self.manifest = manifest

                if (
                    "rightsException"
                    in manifest["returnedTitleRendition"]["selectedEntitlement"]
                ):
                    error_code = manifest["returnedTitleRendition"][
                        "selectedEntitlement"
                    ]["rightsException"]["errorCode"]
                    if error_code == "PRS.NoRights.NotOwned":
                        raise NotEntitled
                    else:
                        log.exit(f" x Amazon returned an error: {error_code!r}")

                self.customer_id = manifest["returnedTitleRendition"][
                    "selectedEntitlement"
                ]["grantedByCustomerId"]

                if not manifest.get("audioVideoUrls"):
                    continue

                for avCdnUrlSets in manifest["audioVideoUrls"]["avCdnUrlSets"]:
                    if int(avCdnUrlSets["cdnWeightsRank"]) == 1:
                        chosen_manifest = avCdnUrlSets
                        break

                if chosen_manifest["drm"] == "PlayReady":
                    continue

                mpd_tracks = Tracks.from_mpd(
                    url=self.clean_mpd_url(chosen_manifest["avUrlInfoList"][0]["url"]),
                    lang=title.original_lang,
                    source=title.source,
                    session=self.session,
                )

                for track in mpd_tracks:
                    if isinstance(track, VideoTrack):
                        track.hdr10 = chosen_manifest["hdrFormat"] == "Hdr10"
                        track.dv = chosen_manifest["hdrFormat"] == "DolbyVision"
                    if isinstance(track, VideoTrack) or isinstance(track, AudioTrack):
                        track.variables["profile"] = bitrate

                tracks += mpd_tracks

        if not tracks:
            raise ManifestNotAvailable

        tracks = Tracks(tracks)

        audios = defaultdict(list)
        for audio in tracks.audio:
            audios[audio.language].append(audio)

        for lang in audios:
            if not any((x.bitrate or 0) >= 640000 for x in audios[lang]):
                self.need_separate_audio = True
                break

        if self.need_separate_audio:
            audio_manifest = self.get_manifest(
                title, "H265", "VBR", self.audio_quality or self.manifest_quality
            )

            if audio_manifest.get("audioVideoUrls"):

                for avCdnUrlSets in audio_manifest["audioVideoUrls"]["avCdnUrlSets"]:
                    if int(avCdnUrlSets["cdnWeightsRank"]) == 1:
                        chosen_manifest = avCdnUrlSets
                        break

            if chosen_manifest["drm"] != "PlayReady":
                try:
                    audio_mpd = Tracks.from_mpd(
                        url=self.clean_mpd_url(
                            audio_manifest["audioVideoUrls"]["avCdnUrlSets"][0][
                                "avUrlInfoList"
                            ][0]["url"]
                        ),
                        lang=title.original_lang,
                        source=self.AMZN_ALIASES[0],
                        session=self.session,
                    )
                except KeyError:
                    pass
                else:
                    for track in audio_mpd.audio:
                        track.variables["profile"] = "VBR"
                    tracks.audio += audio_mpd.audio

        for audio in tracks.audio:
            audio.descriptive = audio.extra[1].get("audioTrackSubtype") == "descriptive"
            # Amazon @lang is just the lang code, no dialect, @audioTrackId has it.
            audio_track_id = audio.extra[1].get("audioTrackId")
            if audio_track_id:
                audio.language = Language.get(
                    audio_track_id.split("_")[0]
                )  # e.g. es-419_ec3_blabla

        subtitle_tracks = []
        for sub in manifest.get("subtitleUrls", []) + manifest.get(
            "forcedNarratives", []
        ):
            if (
                sub["languageCode"] == "filph"
            ):  # Weird language code but seems Filipino (Tagalog)
                sub["languageCode"] = "tgl"

            subtitle_tracks += [
                TextTrack(
                    id_=sub.get(
                        "timedTextTrackId",
                        f"{sub['languageCode']}_{sub['type']}_{sub['subtype']}_{sub['index']}",
                    ),
                    source=title.source,
                    url=os.path.splitext(sub["url"])[0]
                    + ".srt",  # DFXP -> SRT forcefully seems to work fine
                    # metadata
                    codec="srt",  # sub["format"].lower(),
                    language=sub["languageCode"],
                    is_original_lang=title.original_lang
                    and is_close_match(sub["languageCode"], [title.original_lang]),
                    forced="forced" in sub["displayName"],
                    cc="[CC]" in sub["displayName"],
                    sdh=sub["type"].lower() == "sdh"
                    and "[CC]" not in sub["displayName"],
                )
            ]

        tracks.add(subtitle_tracks)

        video_tracks = []
        if not args.dl.list:
            # CBR is the superior bitrate mode
            if self.bitrate_mode != "VBR":
                video_tracks += [
                    x for x in tracks.videos if x.variables["profile"] == "CBR"
                ]

            if self.bitrate_mode == "VBR":
                video_tracks += [
                    x for x in tracks.videos if x.variables["profile"] == "VBR"
                ]
            elif args.dl.video_codec == "H.265":
                video_tracks += [
                    x for x in tracks.videos if x.variables["codec"] == "H.265"
                ]

            tracks.videos = video_tracks

        # The language from the AudioTracks is considered as original
        # if there's no AudioTrack with the original language provided available
        # and all AudioTracks have the same language
        if (
            not any(a.is_original_lang for a in tracks.audio)
            and len(set([x.language for x in tracks.audio])) == 1
        ):
            for track in tracks:
                if isinstance(track, VideoTrack) or isinstance(track, AudioTrack):
                    track.language = title.original_lang
                    track.is_original_lang = True

        return tracks

    def get_chapters(self, title):
        """Get chapters from Amazon's XRay Scenes API."""
        if "xrayMetadata" in self.manifest:
            xray_params = self.manifest["xrayMetadata"]["parameters"]
        elif args.dl.chapters_only:
            xray_params = {
                "pageId": "fullScreen",
                "pageType": "xray",
                "serviceToken": json.dumps(
                    {
                        "consumptionType": "Streaming",
                        "deviceClass": "normal",
                        "playbackMode": "playback",
                        "vcid": self.manifest["returnedTitleRendition"]["contentId"],
                    }
                ),
            }
        else:
            return []

        xray_params.update(
            {
                "deviceID": hashlib.sha224(
                    ("CustomerID" + self.session.headers["User-Agent"]).encode("utf-8")
                ).hexdigest(),
                "deviceTypeID": self.config["devices"]["BROWSER"][
                    "device_type"
                ],  # must be browser device type
                "marketplaceID": self.region["marketplace_id"],
                "gascEnabled": str(self.primevideo).lower(),
                "decorationScheme": "none",
                "version": "inception-v2",
                "uxLocale": "en-US",
                "featureScheme": "XRAY_WEB_2020_V1",
            }
        )

        xray = (
            self.session.get(url=self.endpoints["xray"], params=xray_params)
            .json()
            .get("page")
        )

        if not xray:
            return []

        widgets = xray["sections"]["center"]["widgets"]["widgetList"]

        scenes = next((x for x in widgets if x["tabType"] == "scenesTab"), None)
        if not scenes:
            return []
        scenes = scenes["widgets"]["widgetList"][0]["items"]["itemList"]

        chapters = []

        for scene in scenes:
            chapter_title = scene["textMap"]["PRIMARY"]
            match = re.search(r"(\d+\. |)(.+)", chapter_title)
            if match:
                chapter_title = match.group(2)
            chapters.append(
                MenuTrack(
                    number=int(scene["id"].replace("/xray/scene/", "")),
                    title=chapter_title,
                    timecode=scene["textMap"]["TERTIARY"].replace("Starts at ", ""),
                )
            )

        return chapters

    def certificate(self, **_):
        return self.config["certificate"]

    def license(self, challenge, title, **_):
        lic = self.session.post(
            url=self.endpoints["license"],
            params={
                "asin": title.id,
                "consumptionType": "Streaming",
                "desiredResources": "Widevine2License",
                "deviceTypeID": "AOAGZA014O5RE"
                if cdm.device_type == Device.Types.CHROME
                else self.device["device_type"],
                "deviceID": self.device["device_serial"],
                "firmware": 1,
                "gascEnabled": str(self.primevideo).lower(),
                "marketplaceID": self.region["marketplace_id"],
                "resourceUsage": "ImmediateConsumption",
                "videoMaterialType": "Feature",
                "operatingSystemName": "Linux"
                if self.manifest_quality == "SD"
                else "Windows",
                "operatingSystemVersion": "unknown"
                if self.manifest_quality == "SD"
                else "10.0",
                "customerID": self.customer_id,
                "deviceDrmOverride": "CENC",
                "deviceStreamingTechnologyOverride": "DASH",
                "deviceVideoQualityOverride": self.audio_quality
                or self.manifest_quality,
                "deviceHdrFormatsOverride": "None"
                if _["track"].type == "AudioTrack"
                else "Hdr10"
                if _["track"].hdr10
                else "DolbyVision"
                if _["track"].dv
                else "None",
            },
            headers={
                "Accept": "application/json",
                "Content-Type": "application/x-www-form-urlencoded",
                "Authorization": f"Bearer {self.device_token}",
            },
            data={
                "widevine2Challenge": base64.b64encode(challenge).decode(
                    "utf-8"
                ),  # expects base64
                "includeHdcpTestKeyInLicense": "false",
            },
        ).json()
        if "errorsByResource" in lic:
            error_code = lic["errorsByResource"]["Widevine2License"]
            if "errorCode" in error_code:
                error_code = error_code["errorCode"]
            elif "type" in error_code:
                error_code = error_code["type"]

            if error_code in ["PRS.NoRights.AnonymizerIP", "PRS.NoRights.NotOwned"]:
                raise VPN_PROXY_DETECTED
            elif error_code == "PRS.Dependency.DRM.Widevine.UnsupportedCdmVersion":
                raise CdmBlacklisted
            else:
                log.exit(f"  x Error from Amazon's License Server: [{error_code}]")
        return lic["widevine2License"]["license"]

    # Service specific functions

    def configure(self, ctx):
        if (
            getattr(self, "audio_quality", None) == "UHD"
            and cdm.security_level != 1
            and args.dl.list != "ALL"
        ):
            log.warning_(
                " - Changed Audio Quality to HD since Dolby Atmos can only be decrypted with an L1 Cdm\n"
            )
            self.audio_quality = "HD"

        if (
            (self.manifest_quality == "SD" or args.dl.quality <= 576)
            and not getattr(self, "manifest_quality", None)
            and cdm.security_level == 3
            and cdm.device_type == Device.Types.ANDROID
        ):
            # Setting manifest quality to SD for Android L3
            self.manifest_quality = "SD"

        if args.dl.quality != "SD" and args.dl.quality > 1080:
            # Setting manifest quality to UHD to be able to get 2160p video tracks
            self.manifest_quality = "UHD"

        if args.dl.range in ["HDR10", "DV", "HDR10+DV"] and cdm.security_level == 1:
            # Setting manifest quality to UHD to be able to get HDR10 and DolbyVision video tracks
            self.manifest_quality = "UHD"

        if (
            args.dl.video_codec == "H.265"
            and args.dl.range == "SDR"
            and cdm.security_level == 3
            and cdm.device_type == Device.Types.CHROME
        ):
            # Setting manifest quality to HD to be able to get HEVC video tracks
            self.manifest_quality = "HD"

        if self.manifest_quality is None:
            self.manifest_quality = "HD"

        from widevinely.commands.dl import get_cookie_jar, get_profile

        # Import from here is necessary otherwise it will raise CircularImportError

        if self.primevideo:
            ctx.obj.profile = get_profile(
                ctx=ctx, service="Amazon", zone=None, region="primevideo"
            )
            self.profile = ctx.obj.profile
            self.cookies = get_cookie_jar("Amazon", self.profile)
            self.cli.name = "Prime Video"
        else:
            ctx.obj.profile = get_profile(
                ctx=ctx, service="Amazon", zone=None, region=f"amazon{self.region_code}"
            )
            self.profile = ctx.obj.profile
            self.cookies = get_cookie_jar("Amazon", self.profile)

        if not self.cookies:
            log.exit(f"Could not find cookies with name '{self.profile}.txt'")

        self.endpoints = self.prepare_endpoints(self.config["endpoints"])

        self.session.headers.update({"Origin": f"https://{self.region['base']}"})

        self.device = self.config["devices"]["NVIDIA_SHIELD_TV"]
        device_serial = "".join(random.choices("abcdef" + string.digits, k=16))
        if (
            not self.device
            or cdm.device_type == Device.Types.CHROME
            or self.manifest_quality == "SD"
        ) and args.dl.list != "ALL":
            # Falling back to browser-based device ID
            if not self.device and cdm.device_type != Device.Types.CHROME:
                log.warning_(
                    f"No device information was provided for profile {self.profile!r}, using browser device."
                )
            self.device_id = hashlib.sha224(
                ("CustomerID" + self.session.headers["User-Agent"]).encode("utf-8")
            ).hexdigest()
            self.device = self.config["devices"]["BROWSER"]
            self.device["device_serial"] = device_serial
        else:
            self.device["device_serial"] = device_serial
            self.session.headers.update(
                {
                    "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; SHIELD Android TV Build/PPR1.180610.011)"
                }
            )

            device_cache_path = self.get_cache(
                "{device}_device_tokens_{profile}.json".format(
                    device="nvidia_shield_tv",
                    profile=self.profile,
                ),
                service="amazon",
            )

            self.device_token = DeviceRegistration(
                device=self.device,
                endpoints=self.endpoints,
                cache_path=device_cache_path,
                session=self.session,
                region=self.region,
                primevideo=self.primevideo,
            ).access_token

            if not self.device["device_serial"]:
                log.exit(
                    f"A device serial is required in the config, perhaps use: {os.urandom(8).hex()}"
                )

        self.range_list = ["None"]
        if self.manifest_quality == "UHD" or args.dl.list == "ALL":
            if args.dl.list == "ALL":
                self.range_list += ["Sdr", "Hdr10", "DolbyVision"]
            else:
                if args.dl.video_codec == "H.265" and args.dl.range == "SDR":
                    self.range_list += ["Hevc"]
                if "HDR10" in args.dl.range:
                    self.range_list += ["Hdr10"]
                if "DV" in args.dl.range:
                    self.range_list += ["DolbyVision"]
        else:
            if args.dl.video_codec == "H.265" and args.dl.range == "SDR":
                self.range_list += ["Hevc"]

    def get_asins(self, asin):
        html = self.session.get(url=self.endpoints["video_detail"].format(asin=asin)).text
        regex = re.compile(r'<script type="text\/template">((.*)seasons(.*))<\/script>')
        regex_match = regex.search(html)

        if regex_match:
            json_str = regex_match.group(1)
            json_obj = json.loads(json_str)
            seasons_data = json_obj.get('props', {}).get('state', {}).get('seasons', {})
            seasons = next(iter(seasons_data.values()), None)
            if seasons is None:
                return [json_obj['args']['titleID']]
            
            return [season.get("seasonId", "") for season in seasons]
        else:
            return [asin]

    def get_region(self, title):
        if self.primevideo:
            region = self.config["regions"][".com"]
            
            res = self.session.get("https://www.primevideo.com").text
            match = re.search(
                r'ue_furl *= *([\'"])fls-(na|eu|fe)\.amazon\.[a-z.]+\1', res
            )

            if match:
                pv_region = match.group(2).lower()
            else:
                log.exit("\nFailed to get Amazon Prime region.\n")

            pv_region = {"na": "atv-ps"}.get(pv_region, f"atv-ps-{pv_region}")
            region["base_manifest"] = f"{pv_region}.primevideo.com"
            region["base"] = "www.primevideo.com"
        else:
            for region in self.config["regions"]:
                try:
                    res = self.session.get(
                        url=f"https://www.amazon{region}/dp/{title}",
                        headers={
                            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
                            "accept-encoding": "gzip, deflate, br",
                            "cache-control": "no-cache",
                            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36",
                            "upgrade-insecure-requests": "1",
                        },
                    )
                    if res.status_code == 200:
                        region = self.config["regions"].get(region)
                        break
                except Exception:
                    continue

        return region

    def prepare_endpoint(self, name, uri):
        if name in ("browse", "playback", "license", "xray"):
            return f"https://{(self.region['base_manifest'])}{uri}"
        if name in ("detail", "video_detail", "ontv", "devicelink"):
            return f"https://{self.region['base']}{uri}"
        if name in ("codepair", "register", "token"):
            return f"https://{self.config['regions']['.com']['base_api']}{uri}"
        ValueError
        log.exit(f"Unknown endpoint: {name}")

    def prepare_endpoints(self, endpoints: dict) -> dict:
        return {k: self.prepare_endpoint(k, v) for k, v in endpoints.items()}

    def get_manifest(self, title, video_codec, bitrate_mode, quality, range=None):
        res = self.session.get(
            url=self.endpoints["playback"],
            params={
                "asin": title if type(title) == str else title.id,
                "gascEnabled": str(self.primevideo).lower(),
                "marketplaceID": self.region["marketplace_id"],
                "consumptionType": "Streaming",
                "liveManifestType": "live,accumulating",
                "titleDecorationScheme": "primary-content",
                "desiredResources": ",".join(
                    [
                        "PlaybackUrls",
                        "AudioVideoUrls",
                        "CatalogMetadata",
                        "ForcedNarratives",
                        "SubtitlePresets",
                        "SubtitleUrls",
                        "TransitionTimecodes",
                        "TrickplayUrls",
                        "CuepointPlaylist",
                        "XRayMetadata",
                        "PlaybackSettings",
                    ]
                ),
                "clientId": self.client_id,
                "deviceID": self.device["device_serial"],
                "deviceTypeID": self.device["device_type"],
                "firmware": self.device["firmware"],
                "deviceModel": self.device["device_model"],
                "manufacturer": self.device["manufacturer"],
                "deviceChipset": self.device["device_chipset"],
                "resourceUsage": "CacheResources",
                "softwareVersion": self.device["software_version"],
                "operatingSystemName": "Linux" if quality == "SD" else "Windows",
                "operatingSystemVersion": "unknown" if quality == "SD" else "10.0",
                "format": "json",
                "osLocale": "en_US",
                "uxLocale": "en_US",
                "deviceProtocolOverride": "Https",
                "version": "1",
                "videoMaterialType": "Feature",
                "audioTrackId": "all",
                "deviceBitrateAdaptationsOverride": bitrate_mode.replace(
                    "VBR", "CVBR"
                ).replace("+", ","),
                "deviceVideoQualityOverride": quality,
                "deviceHdrFormatsOverride": range or "None",
                "deviceVideoCodecOverride": video_codec,
                "supportedDRMKeyScheme": "DUAL_KEY",
                "deviceDrmOverride": "CENC",
                "deviceStreamingTechnologyOverride": "DASH",
                "subtitleFormat": "TTMLv2",
                "languageFeature": "MLFv2",
                "playbackSettingsFormatVersion": "1.0.0",
                "playerAttributes": json.dumps({"frameRate": "HFR"}),
                "playerType": "html5",
                "xrayDeviceClass": "normal",
                "xrayPlaybackMode": "playback",
                "xrayToken": "XRAY_WEB_2020_V1",
            },
            headers={"Authorization": f"Bearer {self.device_token}"},
        )

        try:
            manifest = res.json()
        except json.JSONDecodeError:
            raise ManifestNotAvailable(reason=f"{res.status_code} {res.reason_phrase}")
        if "error" in manifest:
            raise ManifestNotAvailable
        return manifest

    @staticmethod
    def get_original_language(manifest):
        """Get a title's original language from manifest data."""
        try:
            return next(
                x["language"].replace("_", "-")
                for x in manifest["catalogMetadata"]["playback"]["audioTracks"]
                if x["isOriginalLanguage"]
            )
        except (KeyError, StopIteration):
            pass

        if "defaultAudioTrackId" in manifest.get("playbackUrls", {}):
            try:
                return manifest["playbackUrls"]["defaultAudioTrackId"].split("_")[0]
            except IndexError:
                pass

        try:
            if len(manifest["playbackUrls"]["audioTracks"]) == 1:
                return manifest["playbackUrls"]["audioTracks"][0]["languageCode"]
        except KeyError:
            raise NotEntitled

        return None

    @staticmethod
    def clean_mpd_url(mpd_url):
        """Clean up an Amazon MPD manifest url."""
        match = re.match(r"(https?://.*/)d.?/.*~/(.*)", mpd_url)
        if match:
            return "".join(match.groups())
        ValueError
        log.exit("Unable to parse MPD URL")

    # Service specific classes


class DeviceRegistration:
    def __init__(self, device, endpoints, cache_path, session, region, primevideo):
        """Registration of Non-Browser Device"""
        self.device = {
            k: str(v) if not isinstance(v, str) else v for k, v in device.items()
        }

        self.endpoints = endpoints
        self.cache_path = cache_path
        self.session = session
        self.region = region
        self.primevideo = primevideo

        if self.cache_path.is_file():
            cache = jsonpickle.decode(self.cache_path.read_text(encoding="utf-8"))
            if not cache.get("cookies"):  # Old v1 token structure
                self.access_token = self.register_token()
            else:
                if cache.get("expires_in", 0) > int(time.time()):
                    self.access_token = cache["access_token"]
                else:
                    # Expired, need to refresh token
                    tokens = self.refresh_token(cache)
                    cache["access_token"] = tokens["access_token"]

                    # expires_in seems to be in minutes, create a unix timestamp and add the minutes in seconds
                    cache["expires_in"] = int(time.time()) + int(tokens["expires_in"])

                    self.cache_path.write_text(json.dumps(cache, indent=4))
                    self.access_token = tokens["access_token"]
        else:
            self.access_token = self.register_token()

    def get_csrfToken(self):
        res = self.session.get(url=self.endpoints["ontv"]).text
        if 'input type="hidden" name="appAction" value="SIGNIN"' in res:
            raise InvalidCookies

        for match in re.finditer(r"<script type=\"text/template\">(.+)</script>", res):
            prop = json.loads(match.group(1))
            csrfToken = prop.get("props", {}).get("codeEntry", {}).get("token")
            if csrfToken:
                return csrfToken

        raise InvalidCookies

    def register_token(self):
        codepair = self.session.post(
            url=self.endpoints["codepair"],
            data=json.dumps({"code_data": self.device}),
            headers={"content-type": "application/json; charset=UTF-8"},
        ).json()

        if not codepair:
            log.exit("Could not get codepair.")

        device_link = self.session.post(
            url=self.endpoints["devicelink"],
            headers={
                "Accept": "*/*",
                "Content-Type": "application/x-www-form-urlencoded",
                "Referer": self.endpoints["ontv"],
            },
            data={
                "publicCode": codepair.get("public_code"),
                "token": self.get_csrfToken(),
                "isPurchaseRow": "1",
            },
        )

        if device_link.status_code != 200:
            log.exit("Could not link device.")

        registration = self.session.post(
            url=self.endpoints["register"],
            data=json.dumps(
                {
                    "auth_data": {
                        "code_pair": {
                            "public_code": codepair.get("public_code"),
                            "private_code": codepair.get("private_code"),
                        }
                    },
                    "cookies": {
                        "domain": f".amazon{self.region['code']}",
                        "website_cookies": [],
                    },
                    "registration_data": self.device,
                    "requested_extensions": ["device_info", "customer_info"],
                    "requested_token_type": [
                        "bearer",
                        "mac_dms",
                        "store_authentication_cookie",
                        "website_cookies",
                    ],
                }
            ),
            headers={"content-type": "application/json; charset=UTF-8"},
        )

        try:
            token_data = registration.json()["response"]["success"]
        except json.JSONDecodeError:
            raise TokenNotObtained(access_token=True, reason=registration.text)

        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        self.cache_path.write_text(
            json.dumps(
                {
                    "refresh_token": token_data["tokens"]["bearer"]["refresh_token"],
                    "access_token": token_data["tokens"]["bearer"]["access_token"],
                    "cookies": "; ".join(
                        [
                            "{}={}".format(cookie["Name"], cookie["Value"])
                            for cookie in token_data["tokens"]["website_cookies"]
                        ]
                    ),
                    "device_serial": token_data["extensions"]["device_info"][
                        "device_serial_number"
                    ],
                    "device_type": token_data["extensions"]["device_info"][
                        "device_type"
                    ],
                    "expires_in": int(time.time())
                    + int(token_data["tokens"]["bearer"]["expires_in"]),
                    "params": {
                        "public_code": codepair.get("public_code"),
                        "private_code": codepair.get("private_code"),
                        "domain": f"https://{self.region['base']}",
                        "region": self.region["code"],
                        "device": self.device,
                    },
                    "registration_response": registration.json(),
                },
                indent=4,
            ),
            encoding="utf8",
        )

        return token_data["tokens"]["bearer"]["access_token"]

    def refresh_token(self, cache):
        try:
            refresh = self.session.post(
                url=self.endpoints["token"],
                json={
                    "domain": self.device["domain"],
                    "app_name": self.device["app_name"],
                    "app_version": self.device["app_version"],
                    "device_model": self.device["device_model"],
                    "os_version": self.device["os_version"],
                    "device_type": self.device["device_type"],
                    "device_serial": self.device["device_serial"],
                    "device_name": self.device["device_name"],
                    "software_version": self.device["software_version"],
                    "requested_token_type": "access_token",
                    "source_token_type": "refresh_token",
                    "source_token": cache["refresh_token"],
                },
                headers={
                    "User-Agent": self.session.headers["User-Agent"],
                    "x-gasc-enabled": str(bool(self.primevideo)),
                },
            ).json()
        except json.JSONDecodeError:
            raise TokenNotObtained(refresh_token=True, reason=refresh.text)

        return refresh
