from __future__ import annotations

from typing import Any, Optional, Union

import click
import random
import json
import os
import re
import uuid
import m3u8
import base64
import string
import shutil
import langcodes
import urllib
from click import Context
from toolz.curried import *
from pathlib import Path
from subprocess import *

from widevinely.config import config
from widevinely.objects import MenuTrack, Title, Tracks, TextTrack
from widevinely.utils import is_close_match
from widevinely.services.BaseService import BaseService
from widevinely.utils import tmdb

from colorama import *

GREEN = Fore.GREEN + Style.BRIGHT
RED = Fore.RED + Style.BRIGHT
YELLOW = Fore.YELLOW
CYAN = Fore.CYAN + Style.BRIGHT
RESET = Style.RESET_ALL


class VTMGO(BaseService):
    """
    Service code for VTMGO. (https://vtm.be/vtmgo).

    Authorization: Cookies
    Security: UHD@-- FHD@L3, doesn't care about releases.

    """

    ALIASES = ["VTMGO", "vtmgo"]

    PROXY_RULES = {"Metadata": "be_res", "Download": "nl_datac"}

    @staticmethod
    @click.command(name="VTMGO", short_help="vtm.be")
    @click.argument("title", type=str)
    @click.option(
        "-m", "--movie", is_flag=True, default=False, help="Title is a Movie."
    )
    @click.pass_context
    def cli(ctx: Context, **kwargs: Any) -> VTMGO:
        return VTMGO(ctx, **kwargs)

    def __init__(self, ctx, title, movie):
        from widevinely.commands.dl import args_

        self.args = args_()

        self.movie = True if "~m" in title else movie
        self.title = title.split("~")[-1][1:]
        super().__init__(ctx)

        if not self.args.no_proxy:
            if config.proxies.get(self.PROXY_RULES["Metadata"]):
                self.session = BaseService.get_session(
                    self,
                    proxy=random.choice(config.proxies[self.PROXY_RULES["Metadata"]]),
                )

        self.headers = {
            "Host": "lfvp-api.dpgmedia.net",
            "User-Agent": "VTMGO/11.2 (be.vmma.vtm.zenderapp; build:13722; iOS 23) okhttp/4.9.0",
            "x-app-version": "11",
            "x-persgroep-mobile-app": "true",
            "x-persgroep-os": "android",
            "x-persgroep-os-version": "23",
        }

        self.license_url: Optional[str] = None
        self.language: Optional[str] = None

    def get_tokens(self):
        html_raw = self.session.get(self.title_url).text
        try:
            access_token = re.search("'token': \"(.*)\"", html_raw).group(1)
            self.access_token = f"Bearer {access_token}"
        except Exception:
            self.access_token = ""
        self.api_key = re.search("'apiKey': \"(.*)\"", html_raw).group(1)

    def get_titles(self):
        metadata = self.session.get(
            f"https://lfvp-api.dpgmedia.net/vtmgo/{'movies' if self.movie else 'programs'}/{self.title}",
            headers=self.headers,
        ).json()
        for info in metadata["movie" if self.movie else "program"]["meta"]:
            if info["label"] == "Taal":
                self.language = info["values"][0]
        self.original_lang = langcodes.find(self.language) if self.language else "nl-BE"

        if "GEO" in [
            metadata["movie"]["blockedFor"]
            if self.movie
            else metadata["program"]["blockedFor"]
        ]:
            print(
                RED
                + " x Title is not available in your region or VTMGO is detecting a VPN..."
                + RESET
            )
            exit()

        cast = [
            x["values"]
            for x in metadata["movie" if self.movie else "program"]["meta"]
            if x["label"] == "Cast"
        ]
        cast = cast[0] if cast else None

        if self.movie:
            content_details = tmdb.info(
                content_name=metadata["movie"]["name"],
                content_year=metadata["movie"]["productionYear"],
                type="movie",
                cast=cast,
            )
            titles = Title(
                id_=self.title,
                type_=Title.Types.MOVIE,
                name=content_details.get("name") or metadata["movie"]["name"],
                year=int(content_details.get("year")[:4])
                or metadata["movie"]["productionYear"],
                synopsis=content_details.get("synopsis")
                or metadata["movie"]["description"],
                original_lang=content_details.get("original_language")
                or self.original_lang
                if self.original_lang
                else "nl-BE",
                tmdb_id=content_details.get("tmdb_id") or None,
                imdb_id=content_details.get("imdb_id") or None,
                thumbnail=content_details.get("thumbnail")
                or metadata["movie"]["portraitTeaserImageUrl"],
                proxy_rules=self.PROXY_RULES,
                source=self.ALIASES[0],
                service_data=metadata["movie"],
            )
        else:
            episodes = []
            for season in metadata["program"]["seasons"]:
                for episode in season["episodes"]:
                    episode["season"] = season["index"]
                    episodes.append(episode)

            if self.args.latest_episodes:
                episodes = [episodes[-1]]  # TODO: Need to find a better way than this
            elif self.args.wanted:
                seasons = []
                for wanted in self.args.wanted:
                    seasons.append(wanted.split("x")[0])

                wanted_seasons = sorted(list(dict.fromkeys(seasons)))

                wanted_episodes = []
                for episode in episodes:
                    if str(episode["season"]) in wanted_seasons:
                        wanted_episodes.append(episode)

                episodes = []
                if len(self.args.wanted) < 100:
                    for episode in wanted_episodes:
                        for wanted in self.args.wanted:
                            if (
                                str(episode["index"]) == wanted.split("x")[1]
                                and str(episode["season"]) == wanted.split("x")[0]
                            ):
                                episodes.extend([episode])
                    if not episodes:
                        print(
                            RED
                            + " x The episode you've requested could not be found..."
                            + RESET
                        )
                        exit()
                else:
                    episodes = wanted_episodes
                    if not episodes:
                        print(
                            RED
                            + " x The season(s) you've requested could not be found..."
                            + RESET
                        )
                        exit()

            content_details = tmdb.info(
                content_name=metadata["program"]["name"],
                content_year=metadata["program"]["productionYear"],
                type="tv",
                cast=cast,
            )

            for episode in episodes:
                titles = [
                    Title(
                        id_=episode.get("id"),
                        type_=Title.Types.TV,
                        name=content_details.get("name") or metadata["program"]["name"],
                        year=int(content_details.get("year")[:4])
                        or metadata["program"]["productionYear"],
                        season=episode.get("season"),
                        episode=episode.get("index"),
                        episode_name=episode.get("name"),
                        synopsis=content_details.get("synopsis")
                        or metadata["program"]["description"],
                        original_lang=content_details.get("original_language")
                        or self.original_lang
                        if self.original_lang
                        else "nl-BE",
                        tmdb_id=content_details.get("tmdb_id") or None,
                        imdb_id=content_details.get("imdb_id") or None,
                        tvdb_id=content_details.get("tvdb_id") or None,
                        thumbnail=episode["bigPhotoUrl"]
                        or content_details.get("thumbnail"),
                        proxy_rules=self.PROXY_RULES,
                        source=self.ALIASES[0],
                        service_data=metadata["program"],
                    )
                    for episode in episodes
                ]
        return titles

    def get_tracks(self, title):
        self.title_url = (
            f"https://vtm.be/vtmgo/afspelen/{'m' if self.movie else 'e'}{title.id}"
        )
        self.get_tokens()

        manifest = self.session.get(
            url=f"https://videoplayer-service.dpgmedia.net/config/{'movies' if self.movie else 'episodes'}/{title.id}",
            headers={
                "popcorn-sdk-version": "5",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36",
                "x-api-key": self.api_key,
            },
        ).json()

        for stream in manifest["video"]["streams"]:
            if stream["type"] == "dash":
                self.dash_stream = stream["url"]
                self.license_url = stream["drm"]["com.widevine.alpha"]["licenseUrl"]

        tracks = Tracks.from_mpd(
            url=self.dash_stream,
            session=self.session,
            lang=title.original_lang,
            source=self.ALIASES[0],
        )

        temp_videos = []
        for video in tracks.videos:
            temp_videos.append(video)

        tracks.videos = []
        for video_track in temp_videos:
            if (
                video_track.height == 1080
            ):  # TODO: Make 1080 not hardcoded but the wanted quality
                tracks.videos.append(video_track)

        for video in tracks.videos[1:]:
            for urls in video.url[1:]:
                if "-init.mp4" not in urls:
                    tracks.videos[0].url.append(urls)
        for videotracks in tracks.videos[1:]:
            tracks.videos.remove(videotracks)

        temp_audio = []
        for audio in tracks.audio:
            temp_audio.append(audio)

        tracks.audio = []
        audio_bitrates = []
        for audio_track in temp_audio:
            audio_bitrates.append(audio_track.bitrate)
        for audio_tracks in temp_audio:
            if audio_tracks.bitrate == max(audio_bitrates):
                tracks.audio.append(audio_tracks)

        for audio in tracks.audio[1:]:
            for urls in audio.url[1:]:
                if "-init.mp4" not in urls:
                    tracks.audio[0].url.append(urls)
        for audiotracks in tracks.audio[1:]:
            tracks.audio.remove(audiotracks)

        if "subtitles" in manifest["video"]:
            if len(manifest["video"]["subtitles"]) == 2:
                manifest["video"]["subtitles"] = [
                    x
                    for x in manifest["video"]["subtitles"]
                    if x["language"] == "nl-tt"
                ]
            for subtitle in manifest["video"]["subtitles"]:
                tracks.subtitles.append(
                    TextTrack(
                        id_=None,
                        source=self.ALIASES[0],
                        url=subtitle["url"],
                        # metadata
                        codec="vtt",
                        language=subtitle["language"].replace("-tt", ""),
                        is_original_lang=is_close_match(
                            subtitle["language"].replace("-tt", ""),
                            [title.original_lang],
                        ),
                        forced=False,
                        # switches/options
                        needs_proxy=False,
                        # text track options
                        sdh=True if "nl-tt" in subtitle["language"] else False,
                    )
                )

        # Extract PSSH
        for video_track in tracks.videos:
            array_of_bytes = bytearray(b"\x00\x00\x002pssh\x00\x00\x00\x00")
            array_of_bytes.extend(bytes.fromhex("edef8ba979d64acea3c827dcd51d21ed"))
            array_of_bytes.extend(b"\x00\x00\x00\x12\x12\x10")
            array_of_bytes.extend(bytes.fromhex(video_track.kid.replace("-", "")))
            video_track.pssh = base64.b64encode(
                bytes.fromhex(array_of_bytes.hex())
            ).decode("utf-8")
        for audio_track in tracks.audio:
            array_of_bytes = bytearray(b"\x00\x00\x002pssh\x00\x00\x00\x00")
            array_of_bytes.extend(bytes.fromhex("edef8ba979d64acea3c827dcd51d21ed"))
            array_of_bytes.extend(b"\x00\x00\x00\x12\x12\x10")
            array_of_bytes.extend(bytes.fromhex(audio_track.kid.replace("-", "")))
            audio_track.pssh = base64.b64encode(
                bytes.fromhex(array_of_bytes.hex())
            ).decode("utf-8")

        for video in tracks.videos:
            video.language = title.original_lang
        for audio in tracks.audio:
            audio.language = title.original_lang

        self.session.headers.clear()
        self.session.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36",
            "Accept": "*/*",
            "Connection": "keep-alive",
            "Accept-Language": "en-US,en;q=0.8",
        }

        return tracks

    def get_chapters(self, title: Title) -> list[MenuTrack]:
        return []

    def certificate(self, **kwargs: Any) -> bytes:
        # TODO: Hardcode the certificate
        return self.license(**kwargs)

    def license(self, challenge: bytes, **_: Any) -> bytes:
        assert self.license_url is not None
        return self.session.post(
            url=self.license_url, data=challenge  # expects bytes
        ).content
