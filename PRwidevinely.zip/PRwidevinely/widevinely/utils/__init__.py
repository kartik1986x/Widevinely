import ast

from pymp4.parser import Box
from typing import Optional, Sequence, Union
from langcodes import Language, closest_match
from rich.console import Console
from rich.theme import Theme

from widevinely.utils import logger
from widevinely.constants import LANGUAGE_MAX_DISTANCE
from pywidevinely import PSSH

clean_line = "\x1b[80D\x1b[1A\x1b[2K"

color_theme = Theme(
    {
        "title": "cyan",
        "bold title": "bold cyan",
        "content": "#FF8C00",
        "bold content": "bold #FF8C00",
        "success": "green",
        "bold success": "bold green",
        "warning": "yellow",
        "bold warning": "bold yellow",
        "error": "red",
        "bold error": "bold red",
    }
)
console = Console(theme=color_theme, highlight=False)

log = logger.getLogger("utils")


class FPS(ast.NodeVisitor):
    def visit_BinOp(self, node: ast.BinOp) -> float:
        if isinstance(node.op, ast.Div):
            return self.visit(node.left) / self.visit(node.right)
        else:
            ValueError
            log.exit(f"Invalid operation: {node.op}")

    def visit_Num(self, node: ast.Num) -> complex:
        return node.n

    def visit_Expr(self, node: ast.Expr) -> float:
        return self.visit(node.value)

    @classmethod
    def parse(cls, expr: str) -> float:
        return cls().visit(ast.parse(expr).body[0])


def get_boxes(data: bytes, box_type: bytes) -> Box:
    """Scan a byte array for a wanted box, then parse and yield each find."""
    # using slicing to get to the wanted box is done because parsing the entire box and recursively
    # scanning through each box and its children often wouldn't scan far enough to reach the wanted box.
    # since it doesnt care what child box the wanted box is from, this works fine.
    if not isinstance(data, (bytes, bytearray)):
        ValueError
        log.exit(" x Data must be bytes in order to create a PSSH Box")
    while True:
        try:
            index = data.index(box_type)
        except ValueError:
            break
        if index < 0:
            break
        if index > 4:
            index -= 4  # size is before box type and is 4 bytes long
        data = data[index:]
        try:
            return PSSH(data)
        except IOError:
            # TODO: Does this miss any data we may need?
            break


def is_close_match(
    language: Union[str, Language],
    languages: Optional[Sequence[Union[str, Language, None]]],
) -> bool:
    if not languages:
        return False
    elif "nl-BE" in languages and language in ["nl", "nl-NL"]:
        return False
    elif language == "nl-BE":
        if "nl" in languages or "nl-NL" in languages:
            return False
    languages = list(map(str, [x for x in languages if x]))
    return closest_match(language, languages)[1] <= LANGUAGE_MAX_DISTANCE


def get_closest_match(
    language: Union[str, Language], languages: Sequence[Union[str, Language]]
) -> Optional[Language]:
    match, distance = closest_match(language, list(map(str, languages)))
    if distance > LANGUAGE_MAX_DISTANCE:
        return None
    return Language.get(match)


def try_get(obj, func):
    try:
        return func(obj)
    except (AttributeError, IndexError, KeyError, TypeError):
        return None
