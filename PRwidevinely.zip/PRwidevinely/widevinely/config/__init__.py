from __future__ import annotations

import os
import tempfile

from types import SimpleNamespace

import yaml
from appdirs import AppDirs
from pathlib import Path
from requests.utils import CaseInsensitiveDict

from widevinely.objects.vaults import Vault
from widevinely.utils import logger

log = logger.getLogger("config")


root_config_dir = Path(AppDirs("widevinely", False).user_config_dir)
root_config_dir.mkdir(exist_ok=True, parents=True)
config_file = root_config_dir / "config.yml"


def config_path() -> None:
    if not os.path.isfile(config_file):
        return Path(""), "set"
    else:
        with open(config_file, "r+") as config_f:
            for line in config_f.readlines():
                if line.endswith(".yml"):
                    return Path(line), ""

    return Path(""), "set"


class Config:
    @staticmethod
    def load_vault(vault):
        return Vault(**{"type_" if k == "type" else k: v for k, v in vault.items()})


class Directories:
    def __init__(self):
        self.app_dirs = AppDirs("widevinely", False)
        self.package_root = Path(
            os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        )
        self.root = self.package_root.parent
        self.parent_package_root = self.package_root.parent
        self.configuration = Path(os.path.dirname(os.path.realpath(__file__)))
        self.user_configs = Path(self.app_dirs.user_config_dir)
        self.service_configs = Path(os.path.join(self.user_configs, "services"))
        self.data = Path(self.app_dirs.user_data_dir)
        self.downloads = Path(
            os.path.join(os.path.expanduser("~"), "Downloads", "widevinely")
        )
        self.temp = Path(
            os.path.join(
                {"/tmp": "/var/tmp"}.get(tempfile.gettempdir(), tempfile.gettempdir()),
                "widevinely",
            )
        )
        self.sessions = Path(self.app_dirs.user_cache_dir.replace("Cache", "sessions"))
        self.cookies = Path(os.path.join(self.data, "cookies"))
        self.logs = Path(os.path.join(self.sessions, "logs"))
        self.devices = Path(os.path.join(self.data, "devices"))
        self.links = self.package_root


class Filenames:
    def __init__(self):
        self.log = os.path.join(directories.logs, "widevinely_{time}.log")
        self.root_config = os.path.join(directories.configuration, "widevinely.yml")
        self.user_root_config = os.path.join(directories.user_configs, "widevinely.yml")
        self.service_config = os.path.join(
            directories.configuration, "services", "{service}.yml"
        )
        self.user_service_config = os.path.join(
            directories.service_configs, "{service}.yml"
        )
        self.subtitles: Path = os.path.join(
            directories.temp, "TextTrack_{id}_{language_code}.srt"
        )
        self.chapters: Path = os.path.join(directories.temp, "{filename}_chapters.txt")


directories = Directories()

config_path_ = config_path()[0]
if config_path_.suffix != ".yml":
    config_path_ = config_path_ / "config.yml"

try:
    with open(config_path_) as fd:
        config = yaml.safe_load(fd)
except FileNotFoundError:
    config = None
    credentials = None
    proxies = None

if config:
    config = SimpleNamespace(**config)
    credentials = config.credentials
    proxies = config.proxies

    # This serves two purposes:
    # - Allow `range` to be used in the arguments section in the config rather than just `range_`
    # - Allow sections like [arguments.Amazon] to work even if an alias (e.g. AMZN or amzn) is used.
    #   CaseInsensitiveDict is used for `arguments` above to achieve case insensitivity.
    # NOTE: The import cannot be moved to the top of the file, it will cause a circular import error.
    from widevinely.services import SERVICES  # noqa: E402

    for service, aliases in SERVICES.items():
        for alias in aliases:
            config.arguments[alias] = config.arguments.get(service)
    config.arguments = CaseInsensitiveDict(config.arguments)

    directories.cookies = config_path_.parent / "cookies"
    directories.devices = config_path_.parent / "devices"
    directories.links = config_path_.parent
    directories.service_configs = config_path_.parent / "service_configs"
    directories.sessions = config_path_.parent / "sessions"
    directories.holavpn_cache = config_path_.parent / "holavpn_cache.json"

    for directory in (
        "downloads",
        "temp",
    ):
        if config.directories.get(directory):
            setattr(
                directories,
                directory,
                Path(os.path.expanduser(config.directories[directory])),
            )

filenames = Filenames()
